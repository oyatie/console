# Legacy family parser prerequisite tests

Additive exact test-only proposal against approved round2 contract (manifest 6fae6fdf6987ac0ef694869324879922912577188dbb34a252c97f682e2a41e0). Root is sole repository/runtime writer; independent review precedes integration, discovery and RED admission.

Seven new tests in existing jwt_verifier target. Existing verifier APIs only; no proposed API reference, Cargo dependency, schema, generated artifact or existing fixture/test edits. All preexisting bytes preserved exactly. Both actual signed-token verification entry points are exercised. The valid binding must survive verified-claims serialization, so silently ignoring the additive claim fails. Duplicates are signed from SerializeMap directly; pre-sign duplicate byte counts are positive machinery controls. Tokens never enter failure messages.

Boundary: strict new-claim decoding, five legal shapes including direct platform, historical absence/defaults and unknown outer-claim compatibility, malformed/null/missing/extra/types/versions/IDs, repeated outer/nested members in both orders, and selected contradictory flags/home/kinds. This does not qualify family liveness, exact issuance/refresh correlation, derived mint/source-policy consumption, complete contradiction matrix, effect locks, or release acceptance. Those remain subsequent independently reviewed dependencies.

Root commands from backend (environment/toolchain per current DELIVERY):
- cargo test -p console-platform-auth --test jwt_verifier legacy_family_binding:: -- --list
- cargo test -p console-platform-auth --test jwt_verifier legacy_family_binding:: --nocapture
- cargo test -p console-platform-auth --test jwt_verifier

Author verification: pinned rustfmt 1.98.1 passed; exact prefix custody passed; seven source test attributes counted. Cargo discovery/execution 0, DB/browser 0. A compiler error is never acceptance RED. Existing owner accepts/ignores new claim by inspection; actual runtime result belongs to root.

Pre-mortem: an ignored field falsely appears compatible, duplicate keys vanish in a Value roundtrip, or a fixture errors before the verifier. Detection: positive signed old control at start of every fixture, retained-field positive checks, raw duplicate serializers, existing APIs only. Blast radius: one additive test module. Rollback: remove only appended module; preserve historical tests. Stop: stale preimage, compilation failure, unexpected oracle ambiguity or unrelated prerequisite failure. Required reviewer: root/security, independent of author /root/integration_tests. No implementation admission until actual named owner probe is RED.
