
// Contract-only parser prerequisites. These exercise the existing cryptographic
// verifiers; family liveness and current policy belong to separate owner tests.
mod legacy_family_binding {
    use super::*;
    use serde::ser::SerializeMap;
    use serde::{Serialize, Serializer};
    use serde_json::{Value, json};

    struct Fixture {
        issuer: JwtIssuer,
        verifier: JwtVerifier,
        key: EncodingKey,
        claims: Value,
    }

    impl Fixture {
        fn new() -> Self {
            let (issuer, verifier, key) = es256_fixture();
            let now = OffsetDateTime::now_utc();
            let claims = json!({
                "iss": "console-platform-auth", "aud": "console-api",
                "sub": UserId::new().to_string(), "org": OrgId::knl().to_string(),
                "iat": now.unix_timestamp(), "nbf": now.unix_timestamp(),
                "exp": (now + Duration::minutes(15)).unix_timestamp(),
                "jti": uuid::Uuid::new_v4().to_string(), "alg": "ES256",
                "roles": ["MEMBER"], "branches": [],
                "platform": false, "view_as": false, "read_only": false
            });
            let fixture = Self {
                issuer,
                verifier,
                key,
                claims,
            };
            fixture.accepted(&fixture.claims, None);
            fixture
        }

        fn sign(&self, claims: &impl Serialize) -> String {
            encode(&Header::new(Algorithm::ES256), claims, &self.key).unwrap()
        }

        fn accepted(&self, claims: &Value, binding: Option<&Value>) {
            let token = self.sign(claims);
            for verified in [
                self.issuer.verify_access_token(&token),
                self.verifier.verify_access_token(&token),
            ] {
                let value =
                    serde_json::to_value(verified.expect("valid signed control rejected")).unwrap();
                assert!(
                    value.get("legacy_session") == binding,
                    "LEGACY_FAMILY_PARSER: binding was lost or absence changed"
                );
            }
        }

        fn refused(&self, claims: &impl Serialize, label: &str) {
            let token = self.sign(claims);
            let issuer = self.issuer.verify_access_token(&token).is_ok();
            let public = self.verifier.verify_access_token(&token).is_ok();
            assert!(
                !issuer && !public,
                "LEGACY_FAMILY_PARSER: {label}; issuer_accepted={issuer}; public_accepted={public}"
            );
        }

        fn bound(&self) -> Value {
            let mut claims = self.claims.clone();
            claims["legacy_session"] = json!({
                "version": 1, "family_id": uuid::Uuid::new_v4().to_string(),
                "home_org": OrgId::knl().to_string(), "kind": "direct"
            });
            claims
        }
    }

    #[test]
    fn absent_binding_keeps_historical_defaults_and_unknown_outer_claims() {
        let fixture = Fixture::new();
        let mut old = fixture.claims.clone();
        for key in ["platform", "view_as", "read_only"] {
            old.as_object_mut().unwrap().remove(key);
        }
        old["future_display_hint"] = json!({"text": "compatibility"});
        fixture.accepted(&old, None);
        let token = fixture.sign(&old);
        let claims = fixture.verifier.verify_access_token(&token).unwrap();
        assert!(!claims.platform && !claims.view_as && !claims.read_only);
        assert_eq!(claims.authz_subject_version, 0);
        assert_eq!(claims.authz_policy_version, 0);
        assert_eq!(claims.session_generation, 0);
    }

    #[test]
    fn valid_binding_is_retained_for_all_four_closed_kinds() {
        let fixture = Fixture::new();
        for kind in [
            "direct",
            "group_admin",
            "platform_view_as",
            "platform_tenant_context",
        ] {
            let mut claims = fixture.bound();
            claims["legacy_session"]["kind"] = json!(kind);
            match kind {
                "group_admin" => {
                    let home = uuid::Uuid::new_v4().to_string();
                    claims["legacy_session"]["home_org"] = json!(home);
                    claims["actor_home_org"] = json!(home);
                    claims["tenant_context"] = json!("group_admin");
                    claims["group_context_id"] = json!(uuid::Uuid::new_v4().to_string());
                    claims["group_roles"] = json!(["GROUP_ADMIN"]);
                    claims["roles"] = json!(["ADMIN"]);
                }
                "platform_view_as" | "platform_tenant_context" => {
                    claims["legacy_session"]["home_org"] = json!(OrgId::platform().to_string());
                    let read_only = kind == "platform_view_as";
                    claims["view_as"] = json!(read_only);
                    claims["read_only"] = json!(read_only);
                    claims["roles"] = if read_only {
                        json!(["ADMIN"])
                    } else {
                        json!(["SUPER_ADMIN"])
                    };
                }
                _ => {}
            }
            fixture.accepted(&claims, claims.get("legacy_session"));
        }
        let mut platform = fixture.bound();
        platform["org"] = json!(OrgId::platform().to_string());
        platform["platform"] = json!(true);
        platform["roles"] = json!(["SUPER_ADMIN"]);
        platform["legacy_session"]["home_org"] = platform["org"].clone();
        fixture.accepted(&platform, platform.get("legacy_session"));
    }

    #[test]
    fn present_null_partial_extra_and_wrong_typed_binding_are_rejected() {
        let fixture = Fixture::new();
        for invalid in [
            Value::Null,
            json!(false),
            json!(1),
            json!("direct"),
            json!([]),
        ] {
            let mut claims = fixture.bound();
            claims["legacy_session"] = invalid;
            fixture.refused(&claims, "binding must be a complete object");
        }
        for field in ["version", "family_id", "home_org", "kind"] {
            let mut claims = fixture.bound();
            claims["legacy_session"]
                .as_object_mut()
                .unwrap()
                .remove(field);
            fixture.refused(&claims, field);
            claims = fixture.bound();
            claims["legacy_session"][field] = Value::Null;
            fixture.refused(&claims, field);
        }
        let mut extra = fixture.bound();
        extra["legacy_session"]["authority"] = json!("SUPER_ADMIN");
        fixture.refused(&extra, "unknown nested member");
    }

    #[test]
    fn unknown_version_kind_and_invalid_or_nil_identifiers_are_rejected() {
        let fixture = Fixture::new();
        for (field, invalid) in [
            ("version", json!(0)),
            ("version", json!(2)),
            ("version", json!("1")),
            ("version", json!(1.5)),
            ("version", json!(true)),
            ("kind", json!("DIRECT")),
            ("kind", json!("account_v1")),
            ("kind", json!(9)),
            ("family_id", json!("")),
            ("family_id", json!("not-a-uuid")),
            ("family_id", json!(uuid::Uuid::nil().to_string())),
            ("family_id", json!(1)),
            ("home_org", json!("")),
            ("home_org", json!("not-a-uuid")),
            ("home_org", json!(uuid::Uuid::nil().to_string())),
            ("home_org", json!(1)),
        ] {
            let mut claims = fixture.bound();
            claims["legacy_session"][field] = invalid;
            fixture.refused(&claims, field);
        }
    }

    // Explicit map serialization preserves duplicate signed keys. No Value
    // parse/roundtrip is allowed between this serializer and JWT signing.
    struct Duplicate<'a> {
        object: &'a Value,
        key: &'a str,
        extra: &'a Value,
        first: bool,
    }
    impl Serialize for Duplicate<'_> {
        fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
            let object = self.object.as_object().unwrap();
            let mut map = serializer.serialize_map(Some(object.len() + 1))?;
            if self.first {
                map.serialize_entry(self.key, self.extra)?;
            }
            for (key, value) in object {
                map.serialize_entry(key, value)?;
            }
            if !self.first {
                map.serialize_entry(self.key, self.extra)?;
            }
            map.end()
        }
    }
    struct NestedDuplicate<'a> {
        claims: &'a Value,
        duplicate: Duplicate<'a>,
    }
    impl Serialize for NestedDuplicate<'_> {
        fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
            let object = self.claims.as_object().unwrap();
            let mut map = serializer.serialize_map(Some(object.len()))?;
            for (key, value) in object {
                if key == "legacy_session" {
                    map.serialize_entry(key, &self.duplicate)?;
                } else {
                    map.serialize_entry(key, value)?;
                }
            }
            map.end()
        }
    }

    #[test]
    fn repeated_outer_binding_is_rejected_in_both_orders_including_identical_values() {
        let fixture = Fixture::new();
        let claims = fixture.bound();
        for extra in [
            claims["legacy_session"].clone(),
            Value::Null,
            fixture.bound()["legacy_session"].clone(),
        ] {
            for first in [false, true] {
                let duplicate = Duplicate {
                    object: &claims,
                    key: "legacy_session",
                    extra: &extra,
                    first,
                };
                let bytes = serde_json::to_string(&duplicate).unwrap();
                assert_eq!(bytes.matches("\"legacy_session\":").count(), 2);
                fixture.refused(&duplicate, "duplicate outer legacy_session");
            }
        }
    }

    #[test]
    fn repeated_nested_members_are_rejected_in_both_orders_including_identical_values() {
        let fixture = Fixture::new();
        let claims = fixture.bound();
        for key in ["version", "family_id", "home_org", "kind"] {
            for extra in [claims["legacy_session"][key].clone(), Value::Null] {
                for first in [false, true] {
                    let duplicate = NestedDuplicate {
                        claims: &claims,
                        duplicate: Duplicate {
                            object: &claims["legacy_session"],
                            key,
                            extra: &extra,
                            first,
                        },
                    };
                    let bytes = serde_json::to_string(&duplicate).unwrap();
                    assert_eq!(bytes.matches(&format!("\"{key}\":")).count(), 2);
                    fixture.refused(&duplicate, "duplicate nested member");
                }
            }
        }
    }

    #[test]
    fn binding_rejects_contradictory_home_tier_and_derived_flags() {
        let fixture = Fixture::new();
        for (path, value) in [
            (
                "/legacy_session/home_org",
                json!(uuid::Uuid::new_v4().to_string()),
            ),
            ("/platform", json!(true)),
            ("/view_as", json!(true)),
            ("/read_only", json!(true)),
            ("/legacy_session/kind", json!("group_admin")),
            ("/legacy_session/kind", json!("platform_view_as")),
            ("/legacy_session/kind", json!("platform_tenant_context")),
        ] {
            let mut claims = fixture.bound();
            *claims.pointer_mut(path).unwrap() = value;
            fixture.refused(&claims, path);
        }
        let mut platform = fixture.bound();
        platform["org"] = json!(OrgId::platform().to_string());
        platform["legacy_session"]["home_org"] = platform["org"].clone();
        fixture.refused(&platform, "platform sentinel requires platform flag");
    }
}
