# Supplemental signed legacy-family parser tests

Private additive test proposal; independent review required before integration. No repository file, DB, build, production source or expectation changed. No test has been compiled or executed for this packet.

Two tests and one private fixture helper are inserted immediately before the existing module terminator. Removing the addition restores the exact 14-test preimage. Both existing signed verifier entry points are exercised by the unchanged accepted/refused helpers.

- Positional coverage: four complete arrays containing valid ordered version/family/home/kind values are refused. Each corresponding direct/Group/view-as/writable object is accepted before and after the negative vector.
- Relationship coverage: start with valid Group, view-as and writable controls and independently mutate one path. Group: 18 negative vectors. View-as: 14. Writable: 15. Positive controls precede and follow each kind. Canonical acting-role vocabulary remains in Authz; only existing supported fixture values occur here.

Expected only for the two supplemental tests: 51 negative signed tokens (102 verifier calls), 16 positive signed tokens (32 verifier calls, including each Fixture::new historical control). Test attributes: prior 14, candidate 16, addition 2. These are source-derived expectations, not runtime results.

Coverage authority: signed wire shape and contract relationships. Not live family lookup, current Cedar policy, minting, refresh, consumer/effect-owner cutover or release acceptance. Source hash custody includes the approved direct OrgId::platform().as_uuid() implementation.

Risk lens conclusions: Cartesian doubt requires full valid arrays because empty arrays can fail for length alone; zero-trust requires independent valid-derived claim mutations with positive controls to prevent blanket-refusal false positives. Blast radius is test-only and rollback removes the exact appended bytes. Stop on changed preimage, source hashes, failed control, or independent-review finding. Root remains repository writer and independent reviewer. No historical tests are removed, edited or weakened.
