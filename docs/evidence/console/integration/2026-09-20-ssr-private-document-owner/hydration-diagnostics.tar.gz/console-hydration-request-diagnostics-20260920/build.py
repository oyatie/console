from pathlib import Path
import hashlib,difflib
p=Path(__file__).parent;old=Path('/private/tmp/console-hydration-browser-tests-20260920-round2');s=(old/'hydration.cjs').read_text();before=s
helper='''// Diagnostics deliberately persist no headers, URL origin/query/fragment or arbitrary error text.
function sanitizedRequest(request,tokens){
 let url=null;try{const raw=request.url();if(secretFreeUrl(raw,tokens))url=new URL(raw);}catch{}
 const paths=new Set(['/payroll','/pkg/console_payroll_ui.js','/pkg/console_payroll_ui_bg.wasm']);
 const method=request.method();const resource=request.resourceType();
 return {path:url&&paths.has(url.pathname)?url.pathname:'[redacted-or-unrecognized]',method:['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS'].includes(method)?method:'OTHER',resource:['document','stylesheet','image','media','font','script','texttrack','xhr','fetch','eventsource','websocket','manifest','other'].includes(resource)?resource:'other'};
}
function sanitizedFailure(request,tokens){
 let text=null;try{text=request.failure()?.errorText;}catch{}
 return typeof text==='string'&&secretFreeUrl(text,tokens)&&/^net::ERR_[A-Z0-9_]{1,80}$/.test(text)?text:'UNCLASSIFIED_FAILURE';
}
'''
assert s.count('// ORACLE_END\n')==1;s=s.replace('// ORACLE_END\n','// ORACLE_END\n'+helper)
s=s.replace("request_failures:0,interception_failures:0,", "request_failures:0,request_diagnostics:[],interception_failures:0,")
anchor="   const requests=[],responses=[],tasks=[];"
replacement=anchor+"\n   let phase='navigation';const inflight=new Map();let requestOrdinal=0;const diagnostic={case:name,failed:[],inflight_at_close:[],inflight_after_close:[]};result.request_diagnostics.push(diagnostic);"
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor="context.on('request',request=>{if(!secretFreeUrl"
replacement="context.on('request',request=>{inflight.set(request,{ordinal:++requestOrdinal,...sanitizedRequest(request,tokens),started_phase:phase});if(!secretFreeUrl"
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
anchor="   context.on('requestfailed',()=>result.request_failures++);"
replacement="""   context.on('requestfinished',request=>inflight.delete(request));
   context.on('requestfailed',request=>{result.request_failures++;diagnostic.failed.push({...(inflight.get(request)??{ordinal:null,started_phase:'unobserved'}),...sanitizedRequest(request,tokens),error:sanitizedFailure(request,tokens),phase});inflight.delete(request);});"""
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
s=s.replace("await Promise.all(tasks);const headers=await response.allHeaders();", "await Promise.all(tasks);phase='inspection';const headers=await response.allHeaders();")
s=s.replace("if(!js){await filter.selectOption", "if(!js){phase='js-off-control';await filter.selectOption")
s=s.replace("     for(const status of [input.runs[0].status", "     phase='filters';\n     for(const status of [input.runs[0].status")
anchor="await context.close();\n  }"
replacement="phase='before-close';diagnostic.inflight_at_close=[...inflight.values()].map(row=>({...row}));phase='closing';await context.close();phase='closed';diagnostic.inflight_after_close=[...inflight.values()].map(row=>({...row}));\n  }"
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
s=s.replace("module.exports={completeEvidence,secretFreeUrl};", "module.exports={completeEvidence,secretFreeUrl,sanitizedRequest,sanitizedFailure};")
assert before.split('// ORACLE_START\n')[1].split('// ORACLE_END')[0]==s.split('// ORACLE_START\n')[1].split('// ORACLE_END')[0]
(p/'hydration.cjs').write_text(s);(p/'controls.cjs').write_bytes((old/'controls.cjs').read_bytes())
(p/'driver.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='accepted/hydration.cjs',tofile='diagnostic/hydration.cjs')))
print('driver_sha256',hashlib.sha256(s.encode()).hexdigest())
