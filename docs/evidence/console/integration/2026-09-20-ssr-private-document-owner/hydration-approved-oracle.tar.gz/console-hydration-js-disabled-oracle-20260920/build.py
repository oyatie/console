from pathlib import Path
import difflib
p=Path(__file__).parent;old=Path('/private/tmp/console-hydration-request-diagnostics-20260920');s=(old/'hydration.cjs').read_text();before=s
helper='''function expectedJsDisabledBlock(result){
 const names=['anonymous','member','foreign-empty','authorized-js-off','authorized'];
 return result.request_failures===1&&Array.isArray(result.request_diagnostics)&&result.request_diagnostics.length===names.length&&result.request_diagnostics.every((entry,index)=>{
  if(!entry||entry.case!==names[index]||!Array.isArray(entry.failed)||!Array.isArray(entry.inflight_at_close)||entry.inflight_at_close.length!==0||!Array.isArray(entry.inflight_after_close)||entry.inflight_after_close.length!==0)return false;
  if(index!==3)return entry.failed.length===0;
  if(entry.failed.length!==1)return false;
  const failed=entry.failed[0];
  return failed&&Number.isSafeInteger(failed.ordinal)&&failed.ordinal>0&&failed.path==='/pkg/console_payroll_ui.js'&&failed.method==='GET'&&failed.resource==='script'&&failed.error==='csp'&&failed.started_phase==='navigation'&&failed.phase==='navigation';
 });
}
'''
anchor='function completeEvidence(result){';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor)
assert s.count('result.request_failures===0')==1;s=s.replace('result.request_failures===0','expectedJsDisabledBlock(result)')
anchor="return typeof text==='string'&&secretFreeUrl(text,tokens)&&/^net::ERR_[A-Z0-9_]{1,80}$/.test(text)?text:'UNCLASSIFIED_FAILURE';";assert s.count(anchor)==1;s=s.replace(anchor,"return typeof text==='string'&&secretFreeUrl(text,tokens)&&(text==='csp'||/^net::ERR_[A-Z0-9_]{1,80}$/.test(text))?text:'UNCLASSIFIED_FAILURE';")
s=s.replace('module.exports={completeEvidence,secretFreeUrl,sanitizedRequest,sanitizedFailure};','module.exports={completeEvidence,expectedJsDisabledBlock,secretFreeUrl,sanitizedRequest,sanitizedFailure};')
(p/'hydration.cjs').write_text(s);(p/'driver.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='diagnostic/hydration.cjs',tofile='reviewed-control/hydration.cjs')))
controls=(old/'controls.cjs').read_text();before_controls=controls
controls=controls.replace('request_failures:0,interception_failures:0,',"request_failures:1,request_diagnostics:['anonymous','member','foreign-empty','authorized-js-off','authorized'].map(name=>({case:name,failed:name==='authorized-js-off'?[{ordinal:3,path:'/pkg/console_payroll_ui.js',method:'GET',resource:'script',error:'csp',started_phase:'navigation',phase:'navigation'}]:[],inflight_at_close:[],inflight_after_close:[]})),interception_failures:0,")
addition='''const blockCorruptions=[
 r=>r.request_failures=0,r=>r.request_failures=2,r=>delete r.request_failures,
 r=>delete r.request_diagnostics,r=>r.request_diagnostics=null,r=>r.request_diagnostics.pop(),r=>r.request_diagnostics.reverse(),
 r=>r.request_diagnostics[3].case='authorized',r=>delete r.request_diagnostics[3].failed,r=>r.request_diagnostics[3].failed=[],
 r=>r.request_diagnostics[3].failed.push(structuredClone(r.request_diagnostics[3].failed[0])),
 r=>{r.request_diagnostics[4].failed=r.request_diagnostics[3].failed;r.request_diagnostics[3].failed=[];},
 r=>r.request_diagnostics[0].failed.push(structuredClone(r.request_diagnostics[3].failed[0])),
 r=>r.request_diagnostics[3].failed[0].path='/pkg/console_payroll_ui_bg.wasm',r=>r.request_diagnostics[3].failed[0].path='/other.js',
 r=>r.request_diagnostics[3].failed[0].method='POST',r=>r.request_diagnostics[3].failed[0].resource='other',
 r=>r.request_diagnostics[3].failed[0].error='net::ERR_ABORTED',r=>r.request_diagnostics[3].failed[0].error='UNCLASSIFIED_FAILURE',
 r=>r.request_diagnostics[3].failed[0].error='CSP',r=>r.request_diagnostics[3].failed[0].phase='closing',
 r=>r.request_diagnostics[3].failed[0].started_phase='inspection',r=>delete r.request_diagnostics[3].failed[0].phase,
 r=>r.request_diagnostics[3].failed[0].ordinal=0,r=>r.request_diagnostics[3].failed[0].ordinal=null,
 r=>r.request_diagnostics[3].inflight_at_close.push({path:'/other.js'}),r=>r.request_diagnostics[3].inflight_after_close.push({path:'/other.js'}),
 r=>delete r.request_diagnostics[3].inflight_at_close,
];
for(const corrupt of blockCorruptions){const r=structuredClone(valid);corrupt(r);assert.equal(completeEvidence(r),false);}
'''
anchor="console.log(JSON.stringify({kind:'hydration-evidence-machinery-only'";assert controls.count(anchor)==1;controls=controls.replace(anchor,addition+anchor).replace('corruptions_detected:corruptions.length+3,','corruptions_detected:corruptions.length+3+blockCorruptions.length,retained_corruptions:corruptions.length+3,expected_control_corruptions:blockCorruptions.length,')
assert before_controls.split('const corruptions=')[1].split('const tokens=')[0]==controls.split('const corruptions=')[1].split('const tokens=')[0]
(p/'controls.cjs').write_text(controls);(p/'controls.diff').write_text(''.join(difflib.unified_diff(before_controls.splitlines(True),controls.splitlines(True),fromfile='diagnostic/controls.cjs',tofile='reviewed-control/controls.cjs')))
d=(old/'diagnostic-controls.cjs').read_text();d=d.replace("let corruptions=0;", "assert.equal(sanitizedFailure({...request(),failure:()=>({errorText:'csp'})},tokens),'csp');\nlet corruptions=0;").replace("['net::ERR_LEAK',", "['csp extra','CSP',' csp','net::ERR_LEAK',").replace('positive:2,','positive:3,');(p/'diagnostic-controls.cjs').write_text(d)
