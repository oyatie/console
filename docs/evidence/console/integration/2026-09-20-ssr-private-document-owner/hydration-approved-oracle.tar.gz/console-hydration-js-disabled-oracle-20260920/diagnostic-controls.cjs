'use strict';
const assert=require('node:assert/strict');const {sanitizedRequest,sanitizedFailure}=require('./hydration.cjs');
const tokens=['sensitive-bearer-fixture','ERR_LEAK'];
const request=(url='http://127.0.0.1:123/pkg/console_payroll_ui_bg.wasm',method='GET',resource='other',errorText='net::ERR_ABORTED')=>({url:()=>url,method:()=>method,resourceType:()=>resource,failure:()=>({errorText})});
assert.deepEqual(sanitizedRequest(request(),tokens),{path:'/pkg/console_payroll_ui_bg.wasm',method:'GET',resource:'other'});
assert.equal(sanitizedFailure(request(),tokens),'net::ERR_ABORTED');
assert.equal(sanitizedFailure({...request(),failure:()=>({errorText:'csp'})},tokens),'csp');
let corruptions=0;
for(const url of ['http://127.0.0.1:123/private/person/sensitive-bearer-fixture','http://sensitive-bearer-fixture.example/payroll','http://127.0.0.1:123/payroll?secret=sensitive-bearer-fixture','http://127.0.0.1:123/payroll#sensitive-bearer-fixture','http://127.0.0.1:123/arbitrary-private-object','not a URL']){
 const value=sanitizedRequest(request(url),tokens);assert.equal(value.path,'[redacted-or-unrecognized]');assert(!JSON.stringify(value).includes('sensitive-bearer-fixture'));corruptions++;
}
assert.deepEqual(sanitizedRequest(request('http://127.0.0.1:123/payroll?private=never-record#never-record','private-method','private-resource'),tokens),{path:'/payroll',method:'OTHER',resource:'other'});corruptions++;
for(const error of ['csp extra','CSP',' csp','net::ERR_LEAK','net::ERR_ABORTED sensitive-bearer-fixture','private internal text','net::ERR_'+ 'A'.repeat(81),undefined]){assert.equal(sanitizedFailure({...request(),failure:()=>({errorText:error})},tokens),'UNCLASSIFIED_FAILURE');corruptions++;}
console.log(JSON.stringify({kind:'hydration-diagnostic-sanitizer-controls-only',positive:3,corruptions_detected:corruptions,browser_runs:0,database_runs:0}));
