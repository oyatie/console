'use strict';
const assert=require('node:assert/strict');const {completeEvidence,secretFreeUrl}=require('./hydration.cjs');
const valid={cases:['anonymous','member','foreign-empty','authorized-js-off','authorized'].map(name=>({name,document_requests:1,document_responses:1,status:200,exact_url:true,envelope:true,credentials_absent:true,expected_rows:true,omission:true})),fixture_statuses:['BLOCKED_LEGAL_GATE','CALCULATED'],filters:['BLOCKED_LEGAL_GATE','CALCULATED',''].map(status=>({status,correct_visibility:true,same_nodes:true,no_requests:true})),js_off_unfiltered:true,assets:{js:true,wasm:true},external_requests:0,unexpected_mutations:0,page_errors:0,console_errors:0,request_failures:1,request_diagnostics:['anonymous','member','foreign-empty','authorized-js-off','authorized'].map(name=>({case:name,failed:name==='authorized-js-off'?[{ordinal:3,path:'/pkg/console_payroll_ui.js',method:'GET',resource:'script',error:'csp',started_phase:'navigation',phase:'navigation'}]:[],inflight_at_close:[],inflight_after_close:[]})),interception_failures:0,url_disclosures:0,redirect_control:{source_302:true,foreign_hop_blocked:true},cleanup:{confirmed:true}};
assert.equal(completeEvidence(valid),true);
const corruptions=[r=>r.cases.pop(),r=>r.cases[0].document_requests=0,r=>r.cases[4].document_responses=0,r=>r.cases[4].status=503,r=>r.cases[4].exact_url=false,r=>r.cases[4].envelope=false,r=>r.cases[4].credentials_absent=false,r=>r.cases[4].expected_rows=false,r=>r.cases[1].omission=false,r=>r.filters.pop(),r=>r.filters[0].correct_visibility=false,r=>r.filters[0].same_nodes=false,r=>r.filters[0].no_requests=false,r=>r.js_off_unfiltered=false,r=>r.assets.js=false,r=>r.assets.wasm=false,r=>r.external_requests++,r=>r.unexpected_mutations++,r=>r.page_errors++,r=>r.console_errors++,r=>r.request_failures++,r=>r.cleanup.confirmed=false,r=>r.filters[1]=structuredClone(r.filters[0]),r=>r.filters[2].status='CALCULATED',r=>r.filters.reverse(),r=>r.fixture_statuses[1]=r.fixture_statuses[0],r=>r.fixture_statuses[0]='UNKNOWN',r=>delete r.fixture_statuses,r=>r.interception_failures++,r=>r.url_disclosures++,r=>r.redirect_control.source_302=false,r=>r.redirect_control.foreign_hop_blocked=false,r=>delete r.redirect_control];
for(const corrupt of corruptions){const r=structuredClone(valid);corrupt(r);assert.equal(completeEvidence(r),false);}
const tokens=['fixture-secret-1','fixture-secret-2'];
assert.equal(secretFreeUrl('http://127.0.0.1:1/pkg/console.js',tokens),true);
for(const url of ['http://127.0.0.1:1/fixture-secret-1','http://127.0.0.1:1/pkg/x?fixture-secret-2','http://fixture-secret-1.example/path'])assert.equal(secretFreeUrl(url,tokens),false);
const blockCorruptions=[
 r=>r.request_failures=0,r=>r.request_failures=2,r=>delete r.request_failures,
 r=>delete r.request_diagnostics,r=>r.request_diagnostics=null,r=>r.request_diagnostics.pop(),r=>r.request_diagnostics.reverse(),
 r=>r.request_diagnostics[3].case='authorized',r=>delete r.request_diagnostics[3].failed,r=>r.request_diagnostics[3].failed=[],
 r=>r.request_diagnostics[3].failed.push(structuredClone(r.request_diagnostics[3].failed[0])),
 r=>{r.request_diagnostics[4].failed=r.request_diagnostics[3].failed;r.request_diagnostics[3].failed=[];},
 r=>r.request_diagnostics[0].failed.push(structuredClone(r.request_diagnostics[3].failed[0])),
 r=>r.request_diagnostics[3].failed[0].path='/pkg/console_payroll_ui_bg.wasm',r=>r.request_diagnostics[3].failed[0].path='/other.js',
 r=>r.request_diagnostics[3].failed[0].method='POST',r=>r.request_diagnostics[3].failed[0].resource='other',
 r=>r.request_diagnostics[3].failed[0].error='net::ERR_ABORTED',r=>r.request_diagnostics[3].failed[0].error='UNCLASSIFIED_FAILURE',
 r=>r.request_diagnostics[3].failed[0].error='CSP',r=>r.request_diagnostics[3].failed[0].phase='closing',
 r=>r.request_diagnostics[3].failed[0].started_phase='inspection',r=>delete r.request_diagnostics[3].failed[0].phase,
 r=>r.request_diagnostics[3].failed[0].ordinal=0,r=>r.request_diagnostics[3].failed[0].ordinal=null,
 r=>r.request_diagnostics[3].inflight_at_close.push({path:'/other.js'}),r=>r.request_diagnostics[3].inflight_after_close.push({path:'/other.js'}),
 r=>delete r.request_diagnostics[3].inflight_at_close,
];
for(const corrupt of blockCorruptions){const r=structuredClone(valid);corrupt(r);assert.equal(completeEvidence(r),false);}
console.log(JSON.stringify({kind:'hydration-evidence-machinery-only',positive:2,corruptions_detected:corruptions.length+3+blockCorruptions.length,retained_corruptions:corruptions.length+3,expected_control_corruptions:blockCorruptions.length,browser_runs:0,database_runs:0}));
