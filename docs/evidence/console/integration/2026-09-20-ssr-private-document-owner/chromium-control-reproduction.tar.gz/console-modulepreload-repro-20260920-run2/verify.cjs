'use strict';
const fs=require('node:fs');const assert=require('node:assert/strict');
const result=JSON.parse(fs.readFileSync(__dirname+'/result.json','utf8'));
assert.equal(result.failure,undefined);assert.equal(result.browser_version,'153.0.8010.12');assert.equal(result.cases.length,6);
assert.deepEqual(result.cases.map(c=>c.name),['on-intercept-preload','off-intercept-preload','on-intercept-plain','off-intercept-plain','on-no-intercept-preload','off-no-intercept-preload']);
for(const row of result.cases){
 assert.equal(row.status,200);assert.equal(row.errors.length,0);assert.equal(row.interception_errors.length,0);assert.equal(row.inflight_at_close.length,0);assert.equal(row.inflight_after_close.length,0);assert.equal(row.module_executed,row.js?'yes':null);
 if(!row.js&&row.preload)assert.deepEqual(row.failed,[{path:'/fixture.js',method:'GET',resource:'script',error:'csp',phase:'navigation'}]);
 else assert.deepEqual(row.failed,[]);
}
assert.equal(result.server_requests.filter(r=>r.path==='/fixture.js').length,3);assert.equal(result.server_requests.filter(r=>r.path==='/preload'||r.path==='/plain').length,6);assert.equal(result.server_requests.length,9);
assert.equal(result.external_requests,0);assert.equal(result.credentials_used,false);assert.equal(result.database_runs,0);assert.equal(result.cleanup.confirmed,true);
console.log(JSON.stringify({kind:'observed-modulepreload-reproduction-verification',cases:6,js_off_preload_browser_refusals:2,error:'csp',js_on_executions:3,js_off_no_preload_failures:0,server_script_deliveries:3,cleanup:true}));
