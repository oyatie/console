# Credential-free Chromium modulepreload reproduction

User/root authorized bounded loopback browser reproduction only. Original product and owner tests are unchanged. Runtime1.63.0and pinned Chromium153.0.8010.12match the hydration owner browser. Browser executable SHA a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282.

Actual six-context browser execution confirms that setting javaScriptEnabled:false while serving a modulepreload link produces Playwright requestfailed errorText exactly "csp", during navigation. This happens both with the owner's CDP Fetch interception pattern (stripping Authorization, with no credential to add) and without any interception. Both contexts finish200and execute no module. The fixture sends no Content-Security-Policy header. When JavaScript is enabled, preload cases execute the module and have no request failures. With modulepreload removed, the JavaScript-disabled context generates no script request or failure. The JavaScript-enabled no-preload control still executes the module without failures.

These controlled contrasts isolate browser handling of modulepreload when script execution is disabled. They do not establish an application CSP failure, transport failure, credential failure, or teardown race. Every failure occurs during navigation, and every context has empty inflight snapshots before/afterclose. All page/interception errors0. The server sees six documents and exactlythree script deliveries, matching only the three JavaScript-enabled cases. No credentials or database were used, no external request occurred, and owned browser/server cleanup is confirmed.

Commands:
- node --check /private/tmp/console-modulepreload-repro-20260920/repro.cjs:PASS.
- node /private/tmp/console-modulepreload-repro-20260920/repro.cjs: prerequisite failure listenEPERM, zero browser cases; historical result preserved there.
- Identical script copied to this fresh output directory; node /private/tmp/console-modulepreload-repro-20260920-run2/repro.cjs with explicitly scoped sandbox escalation: exit0, actual6contexts/onebrowserprocess, confirmed cleanup.
- node verify.cjs: exact observed matrix, browser identity,2cspfailures,3moduleexecutions, server counts and cleanup assertionsPASS. This verifies recorded reproduction, not product acceptance.

Hydration round4 product result already isolates authorized-js-off/script/navigation failure but records UNCLASSIFIED_FAILURE because its diagnostic allowlist only accepts net::ERR_* strings. The reproduction establishes the expected browser-side csp behavior independently. To prove the exact product failure has the same code, a separately reviewed diagnostic successor can allow the literal "csp" value and rerun the unchanged owner. Do not silently reclassify any owner failure or weaken completeEvidence. Any later evidence-oracle adjustment requires explicit review and negative controls distinguishing JS-disabled expected blocking from real JS-on/CSP/network failures.
