'use strict';
const fs=require('node:fs');const http=require('node:http');const crypto=require('node:crypto');const {once}=require('node:events');
const runtime='/private/tmp/console-root-entry-browser-smoke-20260919-round2/runtime/node_modules/playwright';
const executable='/private/tmp/console-preparation-browsers/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const expectedSha='a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282';
const out=__dirname+'/result.json';if(fs.existsSync(out))throw Error('fresh result required');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
if(sha(fs.readFileSync(executable))!==expectedSha)throw Error('browser custody');
if(require(runtime+'/package.json').version!=='1.63.0')throw Error('runtime custody');
const result={kind:'CREDENTIAL_FREE_MODULEPRELOAD_BROWSER_REPRO',browser_sha256:expectedSha,runtime:'1.63.0',cases:[],server_requests:[],external_requests:0,cleanup:{confirmed:false},credentials_used:false,database_runs:0};
const server=http.createServer((req,res)=>{
 result.server_requests.push({path:req.url,method:req.method});
 if(req.method!=='GET'){res.writeHead(405).end();return;}
 if(req.url==='/fixture.js'){res.writeHead(200,{'content-type':'text/javascript','cache-control':'no-store'}).end("document.documentElement.dataset.moduleExecuted='yes';");return;}
 if(req.url==='/preload'||req.url==='/plain'){
  const preload=req.url==='/preload'?'<link rel="modulepreload" href="/fixture.js">':'';
  res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}).end('<!doctype html><html><head>'+preload+'<script type="module" src="/fixture.js"></script></head><body><main>Public fixture only</main></body></html>');return;
 }
 res.writeHead(404).end();
});
let browserServer,browser;
async function main(){
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const origin='http://127.0.0.1:'+server.address().port;
 const {chromium}=require(runtime);browserServer=await chromium.launchServer({headless:true,executablePath:executable,env:{PATH:process.env.PATH},args:['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run']});
 result.browser_pid=browserServer.process().pid;browser=await chromium.connect(browserServer.wsEndpoint());result.browser_version=browser.version();if(result.browser_version!=='153.0.8010.12')throw Error('browser version');
 for(const [name,js,intercept,preload] of [['on-intercept-preload',true,true,true],['off-intercept-preload',false,true,true],['on-intercept-plain',true,true,false],['off-intercept-plain',false,true,false],['on-no-intercept-preload',true,false,true],['off-no-intercept-preload',false,false,true]]){
  const context=await browser.newContext({javaScriptEnabled:js,serviceWorkers:'block'});const page=await context.newPage();
  const row={name,js,intercept,preload,requests:[],finished:[],failed:[],errors:[],interception_errors:[],inflight_at_close:[],inflight_after_close:[]};result.cases.push(row);let phase='navigation';const inflight=new Map();
  if(intercept){const cdp=await context.newCDPSession(page);cdp.on('Fetch.requestPaused',event=>{void(async()=>{
   const url=new URL(event.request.url);if(url.origin!==origin){result.external_requests++;await cdp.send('Fetch.failRequest',{requestId:event.requestId,errorReason:'BlockedByClient'});return;}
   const headers=Object.entries(event.request.headers).filter(([name])=>name.toLowerCase()!=='authorization').map(([name,value])=>({name,value:String(value)}));
   await cdp.send('Fetch.continueRequest',{requestId:event.requestId,headers});
  })().catch(error=>row.interception_errors.push(error.message));});await cdp.send('Fetch.enable',{patterns:[{urlPattern:'*',requestStage:'Request'}]});}
  context.on('request',request=>{const url=new URL(request.url());if(url.origin!==origin)result.external_requests++;const entry={path:url.pathname,method:request.method(),resource:request.resourceType(),phase};row.requests.push(entry);inflight.set(request,entry);});
  context.on('requestfinished',request=>{row.finished.push({path:new URL(request.url()).pathname,phase});inflight.delete(request);});
  context.on('requestfailed',request=>{row.failed.push({path:new URL(request.url()).pathname,method:request.method(),resource:request.resourceType(),error:request.failure()?.errorText,phase});inflight.delete(request);});
  page.on('pageerror',error=>row.errors.push(error.message));
  const response=await page.goto(origin+(preload?'/preload':'/plain'),{waitUntil:'networkidle',timeout:15000});row.status=response.status();row.module_executed=await page.evaluate(()=>document.documentElement.dataset.moduleExecuted??null);phase='before-close';row.inflight_at_close=[...inflight.values()];phase='closing';await context.close();phase='closed';row.inflight_after_close=[...inflight.values()];
 }
}
main().catch(error=>{result.failure=error.message;process.exitCode=1;}).finally(async()=>{
 if(browserServer){const child=browserServer.process();await browserServer.close().catch(()=>{});if(child.exitCode===null&&child.signalCode===null)await browserServer.kill().catch(()=>{});result.cleanup.browser_exited=child.exitCode!==null||child.signalCode!==null;}
 await new Promise(resolve=>server.close(resolve));result.cleanup.server_closed=!server.listening;result.cleanup.confirmed=result.cleanup.browser_exited===true&&result.cleanup.server_closed;
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{mode:0o600,flag:'wx'});console.log(JSON.stringify(result,null,2));
});
