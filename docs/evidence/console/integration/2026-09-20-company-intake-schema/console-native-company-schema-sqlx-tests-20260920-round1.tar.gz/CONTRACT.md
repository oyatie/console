# Empty native Company intake schema prerequisite

Private test-source candidate only. No repository, migration, generator, runtime or custody modification. Root remains sole writer. Reuses approved round4 declaration/oracle packet, manifest SHA430a740e19c840cbb64c15757ed6182ae27ae5d05c504cb80f2fd4c9b33b16af and the parser's isolated SQLx installation method. Executed tests:0. This packet does not claim schema-owner transitions, prepare, effects, workflow or release acceptance.

## Exact bounded next dependency

The empty three-table schema can execute now. Receipt root_assignment_id references real public.user_role_assignments(id), created in backend/crates/platform/db/migrations/0065_create_policy_roles.sql:141. That existing root has NOT NULL user_id and legacy User FKs; it has no native current_revision or account_id. Approved v1 PROPOSAL.md:86 calls for immutable policy_assignment_revisions and tagged native assignment roots. The exact new revision declaration/unique key is not supplied by current migrations or round4 DDL. Receipt root_revision=1 is presently only a CHECK, not a revision FK. No fake assignment, Company, Group, receipt, native revision table or placeholder function is introduced to make this prerequisite pass.

Order: (1) privately install the approved empty request/receipt/event tables with existing FKs, ownership and receipt immutable statement guard; (2) implement and independently test exact request/event guards and authenticated prepare/status/cancel owners against real Accounts/designations; (3) expand the canonical assignment/role owner with native revision keys and compatible legacy guards, then add exact receipt assignment-revision/Company correlation; (4) complete topology/catalog/policy/effect closure and populated contexts before serving enrollment. Parts1–2 can progress before3; no COMMITTED acceptance can.

No new finalizer or classifier is admitted. Required uninstalled generated resource is ops/postgres-company-enrollment-schema.sql, emitted from a single new function in the existing ops/generate-account-custody.py owner, analogous to the parser resource. Root must review exact generator/body/resource diff. Keep all current generated custody/profile files byte-identical, including the now-existing parser output. Never install this partial resource in production initialization. The resource has no BEGIN/COMMIT, public serving participants, seeds or grants to runtime roles. The exact round4 three-table declarations/ACLs remain controlling. This candidate exercises empty physical schema, receipt key-share permissions and receipt statement immutability only; missing request/event transition guards remain explicit and unapproved. Their bodies require the next independently reviewed transition tests, not placeholder success bodies.

Receipt immutable trigger error is concretized here as SQLSTATE P0001, message company_enrollment_receipts.immutable, following existing account_terms_receipts/root guard convention. This is a new test-level refinement for review. It covers zero-row UPDATE refusal under the no-login Account owner. SELECT FOR KEY SHARE succeeds on the empty receipt table, proving statement privilege, not populated FK lock behavior. Future receipt insertion/constraint and lock-contention tests remain required.

## Test and resource integration

Include native_company_intake_schema.rs inside the existing deployment_operator_designation::company_setup module, as with the parser leaf. Register its source, two fixture SQL files, and //ops:postgres-company-enrollment-schema.sql in the existing exact Buck generated-resource ownership mechanism. This packet edits no Buck files and provides no install body. Root serializes and reviews those concrete changes rather than copying a stale before/after from the parser packet.

Exact leaf:

account_browser::deployment_operator_designation::company_setup::intake_schema::company_intake_empty_schema_is_private_and_retains_real_fk_dependencies

The real designated fixture creates Account/passkey/session/designation through existing owners. Both unchanged profiles must first be finalized. Install the real root-generated parser and schema privately as the existing SQLx administrative bootstrap. Both profiles must become account_native.profile_mismatch and remain so. The test never calls an application operation once it has deliberately invalidated that profile.

- company-enrollment-schema-acl.sql contains the exact approved round4 DO oracle. Only psql/client transaction wrappers were removed, so corruption controls can own rollback. SQLx sets bounded statement/lock timeouts.
- company-enrollment-schema-references.sql independently enumerates all12 actual FK column/target tuples, deferred modes, RESTRICT actions, validated state and public target namespace. It rejects missing/extra FKs and any serving participant installation. It does not pretend a native revision FK exists.
- Six actual serving logins each attempt SELECT/INSERT/UPDATE/DELETE/TRUNCATE on all three empty tables:90 required42501 denials. SET ROLE is used only for the nonlogin owner key-share/statement-guard probe, never substituted for real serving identities.
- Two reversible, transaction-local corruptions grant an unexpected Business SELECT and weaken ALWAYS trigger firing to ordinary enabled. The unchanged ACL oracle must fail with the exact expected diagnostic, then pass after rollback.
- Full public-table census after removes precisely the three newly created tables only after requiring each to be empty; every preexisting table and history must be byte-identical. No omissions or fabricated business rows.

## Limits, recovery and review

Pre-mortem: treating empty DDL as safe serving schema, overlooking a missing revision FK, silently granting owner UPDATE without immutable trigger, or resealing a deliberately incomplete profile. Detection: exact catalog ACL/FK checks, actual login denials, zero-row guard execution, corruption controls, unchanged classifiers and complete history census. Blast radius: one disposable SQLx database with three empty tables and private parser/guard. Rollback: SQLx discards database; historical files and serving state never change. Stop on stale fixture/profile, unexpected serving function, changed existing generated output/history, fabricated prerequisite data or unexplained SQLSTATE.

Requested independent reviewers: /root/integration_security and /root/integration_tests. Reviews cover this source candidate only. Root owns all build/test execution and exact head/artifact evidence. Full guard correctness, native revision FK, populated migration, actual prepare/recovery/concurrency, complete effect closure and serving activation remain HOLD.
