# Uninstalled Company schema: preservation and Buck test successor

Private test-source proposal, actual source observed at HEADf6a2cbf602ea20b154ae120a592eae5712f6fb92. source-lock.json binds working preimages. Root is sole repository/generator writer. No tests, builds, SQL, generators, browser or network executed by this author; executed tests0.

Reuse approved empty-schema SQLx candidate /private/tmp/console-native-company-schema-sqlx-tests-20260920-round1 manifestaf58719e367e368d719b7abc2edfbc6dcd57ba67f335932ced96e4d909f52c22 and reviewed round4 DDL. This proposal supplies no schema/guard implementation and no serving activation.

## Preservation test

test_company_enrollment_input_generator.py.patch is the exact successor for existing ops/test_company_enrollment_input_generator.py. Keep the existing one test method/class and every six historical output digest/byte comparison unchanged. The current decoder is an additional frozen predecessor with SHA256cbc685bff861fec809b930e57673cce5426a771a236323471955510de0631290; preserve its output/function/disk equality and CREATE FUNCTION/UNINSTALLED assertions. Add its fixed digest comparison.

The only newly allowed generated output is ops/postgres-company-enrollment-schema.sql, exactly matching GENERATOR.company_enrollment_schema_sql() and the checked-in output. Require its UNINSTALLED marker and three approved CREATE TABLE declarations; these declarations must not appear in the six historical outputs or parser. Output key equality admits exactly8 files: six historical + existing parser + new schema. No wildcard outputs, changed old digest, finalizer hook or profile reseal. The supplied complete test file is a readable projection of the same patch, not another test module to install.

Declaration-marker checks are evidence of generator separation only, not SQL safety or guard correctness. The approved private SQLx schema/ACL/FK/login-denial test provides the actual next implementation boundary. Its deliberate account_native.profile_mismatch must remain; production profiles remain unchanged.

## Narrow Buck regression

test_gen_first_party.py.patch adds one method test_private_company_schema_auth_rest_resources_are_complete. It requires auth_rest's //ops:postgres-company-enrollment-schema.sql external resource mapped to its exact source, both approved SQL fixture resources (company-enrollment-schema-acl.sql and company-enrollment-schema-references.sql), and the integrated native_company_intake_schema.rs source. Existing parser-resource and general literal-fixture coverage remain untouched.

All65 existing test methods are source-byte-identical, including the reviewed retention CI successor and health-readiness resource regression. Expected total becomes66 methods. Runtime gen_first_party.py and ops/BUCK are not edited here; root supplies the reviewed one-export/two-fixture mapping changes and generated Buck projection. No lockfile, migration, runtime or CI change belongs to this packet.

## Review and recovery

Pre-mortem: broadening the generated output set hides changed custody bytes; omitted Buck fixtures produce an unrelated missing-resource failure; tests silently authorize the empty schema as serving. Detection: exact output set, seven predecessor digests/disk equality, exact mappings/file existence and unchanged private SQLx boundary/classifiers. Blast radius: existing generator preservation method plus one new Buck regression. Rollback: revert prospective generator/resource/test additions together before installation; preserve historical bytes and all sealed evidence. Stop on preimage mismatch, any historical/parser digest change, missing real referenced schema key, arbitrary stub or missing independent approval.

Requested reviewers: /root/integration_security and /root/integration_tests. Root executes tests and records RED/GREEN on its exact candidate; this proposal itself has no runtime evidence. Native revision FK, request/event transitions, authenticated prepare/recovery, effect closure and assembled-release qualification remain outstanding.
