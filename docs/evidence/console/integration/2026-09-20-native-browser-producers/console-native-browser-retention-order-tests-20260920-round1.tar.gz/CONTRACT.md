# Retention ordering-test successor

Root actual execution found67pass/1fail; log /private/tmp/console-browser-retention-ci-green-20260920.log. The first ordering mutation called swapNamedSteps with upload first and hydration second although hydration precedes upload. Existing helper correctly requires first.start<second.start. This successor supplies explicit chronological pairs for both original mutants; no helper or gate change and no skipped assertion. It additionally requires each mutated YAML to parse before evaluating its gate failure. Both upload-before-hydration and upload-after-collector violations remain tested.

Private source proposal only; no repository/runtime edits and executed tests0. Existing68test count and every other assertion remain unchanged. Root must reexecute the previously failing suite. Independent tests/security source reviews requested. This correction claims no hosted upload or product qualification.
