# Executable native SQLx decoder test candidate

Parent authorized the exact implementation placement after security review: one `company_enrollment_input_sql()` source in ops/generate-account-custody.py emits separate **UNINSTALLED** ops/postgres-company-enrollment-input.sql. Every existing generated output and fingerprint stays byte-identical. This packet supplies tests, fixtures and resource-source diffs only. No production parser body, stub, generator execution, repository write, SQL or build was performed.

## Existing real fixture and enclosing lane

Include `native_company_input_parser.rs` inside existing `company_setup` (native_company_setup.rs) via `include!("native_company_input_parser.rs");`. One SQLx leaf uses existing `designated(&pool)`: actual current migration/finalizer, native WebAuthn Account enrollment, current startup designation and session. It checks both actual generated serving classifiers positive and asserts helper absent before private installation.

It then installs the new exact generated helper within one bounded test-admin transaction. Both unchanged classifiers must report `account_native.profile_mismatch`. That is the expected correct incomplete-profile state. The helper is invoked with synthetic input as marked real disposable administrator, and every serving login is denied. No browser/application path is created. The test keeps the mismatch afterward and lets SQLx discard the whole database; it does not remove/reseal the helper to present the experiment as a deployment.

Root already executed the enclosing genuine Company POST owner RED (expected201, actual404). This subordinate decoder test needs no manufactured stub or missing-symbol lane. Follow root's admitted path expansion before integration.

## Exact test behavior

One SQLx leaf:
`account_browser::deployment_operator_designation::company_setup::input_parser::company_input_parser_executes_710_cases_only_in_private_mismatched_profile`.

Before and after the helper addition the test executes the existing root and credential classifier SQL, not a duplicate classifier. Exact helper metadata includes one bytea input, the proposed typed eight-column return, IMMUTABLE SECURITY INVOKER CALLED ON NULL INPUT PARALLEL UNSAFE, no leakproof/defaults/overloads, fixed pg_catalog,pg_temp search_path and Account-owner-only EXECUTE ACL. The helper reads no table; unsafe parallel declaration is the existing default and makes no performance claim.

The three reviewed SQL oracles execute on that actual helper:557 golden/prefix/suffix/null calls,24 malformed calls,129 boundary calls (29valid/100invalid), total710. Exceptions remain exact SQLSTATE22023 with sanitized message. Positive/negative row shape, byte and digest semantics are unchanged. New golden rejected-count assertion requires552 rejects; existing valid-count5, malformed24 and boundary29/100 assertions remain. Printed counts appear only after each server-side oracle successfully completes; a parser exception/assertion exits the SQLx leaf.

Real login pools prove42501 for Business/Auth/LeaveCommand/OntologyCommand/PlatformForceCommand plus actual startup login. Session and current user must match the expected nonsuperuser/nonbypass identity. A syntax error, unknown function or22023 from a body is not an ACL pass. Full all_rows before/after proves no business/identity/credential row changes; helper metadata is intentionally new and profile remains mismatched.

## Reviewed psql-to-SQLx adaptation

`sql-adaptation.json` identifies original exact sources and removed lines. Only psql `\set ON_ERROR_STOP on` and `\pset pager off` client directives are removed; SQLx awaited execution propagates errors and has no pager. Each actual SQL transaction remains BEGIN READ ONLY, bounded statement/lock timeouts, fixed search_path and ROLLBACK. Golden adds the precise rejected_count552 check before its existing notice. All three embedded arrays and loop/oracle conditions are otherwise byte-preserved from approved schema round4 parser artifacts. This semantic strengthening requires review and is not silently inherited approval.

## Root-only integration guide

1. Copy the Rust test into backend/app/tests/auth_rest, add its include within company_setup, and copy the three company-enrollment-input-*.sql files into existing fixtures directory. No fixture creates Company success.
2. Add the one new generator function implementing the already approved pure parser contract. This packet intentionally has no implementation. Add exactly `'ops/postgres-company-enrollment-input.sql': company_enrollment_input_sql()` to generated_files(). Neither existing root/credential installer, classifier, native verification nor custody profile receives it. New output must state UNINSTALLED and contain only its helper definition/owner/exact private grant changes, no transaction control, table/row write or finalizer hook.
3. Copy test_company_enrollment_input_generator.py to ops. It checks all six captured generated outputs against independent fixed file SHA256, compares on-disk bytes, allows exactly one new generated path and verifies that no prior output installs the helper. Existing-generated-output-sha256.json is the retained custody reference, not a profile reseal. Future intentional generator changes require separately reviewed expectations; this candidate cannot silently update them.
4. Apply exact ops.BUCK.before→after and gen_first_party.py.before→after only after preimage comparison. These are resource source edits, not regenerated BUCK output. Add test_gen_first_party.py.before→after. Root serializes actual `python3 tools/buck/gen_first_party.py` and any generated BUCK changes. Existing src/**/*.rs discovery includes the new included Rust file; three SQL fixtures and one external authoritative helper require explicit mappings.
5. Root runs generator and `--check`, native target build/discovery, focused SQLx leaf using existing credential-isolated harness, then relevant regression/generator gates. All generated baseline hashes and original migrations must remain exact.

Prospective commands (not executed here):

```sh
python3 ops/test_company_enrollment_input_generator.py
python3 tools/buck/test_gen_first_party.py
python3 ops/generate-account-custody.py --check
python3 tools/buck/gen_first_party.py --check
CONSOLE_BUCK_NEEDS_POSTGRES_TEST_EXACT=account_browser::deployment_operator_designation::company_setup::input_parser::company_input_parser_executes_710_cases_only_in_private_mismatched_profile tools/buck/test_needs_postgres.sh //tools/buck:app-auth-rest-pg
```

The harness command must reuse root's verified existing native/database prerequisites and exact target; never put credentials in argv. Record one discovered/executed SQLx leaf,710 parser calls,6 actual login denials, exact artifact/source hashes and errors. Missing helper resource/build failure/zero tests is a prerequisite failure, not parser acceptance. Current profile mismatch after private install is required, never a reason to reseal it.

## Risks, rollback and review

Pre-mortem: helper accidentally installed into serving; a generated face misses its SQL; psql adaptation suppresses errors; arbitrary private test code substitutes for real generator output; ACL failure hides missing function; fixture classifier is rewritten to bless unknown helper. Detection: exact generated file custody, compile-time authoritative resource, positive/negative classifier pair, exact metadata,710 server-side assertions, real42501 logins and row preservation.

Blast radius: one isolated SQLx disposable database only. Rollback is disposal; no persisted product state/profile is changed. Stop on output/preimage drift, accidental finalizer wiring, malformed metadata or any wrong test counts. Receipt DDL/key-share amendment is independent and not required for this parser test. No schema/prepare/effect/Company journey or serving-profile acceptance is claimed.

Author /root/reference_inventory; reviewers /root/integration_security and /root/integration_tests requested. Selected lenses: Cartesian doubt, Chesterton's Fence, Red Team, Operability, Blast radius, Zero trust. Runtime execution0, repository edits0. Root owns all implementation, generated writes and evidence.
