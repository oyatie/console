# Correct current Cedar SDK bundle identity

Design and exact test candidate only. Root is sole repository writer. Base03463f3c0fd0e08e9e9a7b50fc34058f7044d33f; source-custody.json binds nine unchanged dependencies. Lenses: Cartesian doubt, Essentialism, Red Team, Operability and zero-trust. No application implementation, dependency change, SQL, database execution or historical-record mutation is included.

## Exact defect and chosen fix

platform/authz/Cargo.toml pins cedar-policy=4.12.0 and Cargo.lock resolves cedar-policy/core/formatter4.12.0. engine.rs:35 still declares public CEDAR_SDK_VERSION="4.11.2". compile_bundle_from_sources:299 strictly compiles actual current SDK material then uses that stale constant in CompiledBundleCacheKey at329. Real bundles are therefore mislabeled; matching a saved4.11.2 key can incorrectly appear version-compatible. The current unit test at625 repeats the stale expectation instead of comparing the linked implementation.

The installed dependency already exposes cedar_policy::get_sdk_version(), re-exported at its lib.rs:97 from api.rs:92. Its value derives from Cedar's own env!("CARGO_PKG_VERSION"). Use this API as the independent test oracle, not Console's version env variable or an ad hoc Cargo parser. SDK4.12.0 reports language4.5.0; Console's existing "4.5" language identity is intentionally unchanged in this bounded repair.

Choose the smallest source-compatible fix: keep the public CEDAR_SDK_VERSION constant and existing shared key-construction call, correct its literal and explanatory pin to4.12.0. The new actual-SDK regression makes subsequent dependency/constant drift fail. No new build script, manifest parser, cache, dependency, API removal or generalized version abstraction. Direct runtime API construction would also avoid key drift but would leave the public constant independently stale or require an unnecessary exported API transition; do not make that broader change here.

## All discovered production compiler paths and effects

All real compile paths converge at engine::compile_bundle_from_sources:

- engine::compile_bundle → compile_bundle_inner; identity/rest/src/lib.rs:4535 invokes it for RoleManage shadow.
- engine::compile_bundle_for_feature; app/src/cedar_parity.rs:216 invokes it for per-feature shadow.
- engine::compile_audit_stream_bundle → compile_audit_stream_bundle_inner; compliance/rest/src/lib.rs:1164 invokes it for enforced covert-audit stream access.
- authoring::validate_blocks_with:479 invokes it directly for strict policy-draft validation; this path discards the resulting key after validation.

engine::evaluate returns its actual bundle.key. cedar_pbac::evaluate_cedar_pbac_boundary compares the full CompiledBundleCacheKey against CoexistenceMapEntry.bundle_key; observe_cedar_pbac_decision retains expected and evaluated identities. The inspected runtime callers build map entries from the freshly compiled bundle. Key equality includes SDK version; no comparison weakening is needed. The map loader does not provide a persisted compiled cache. The defect affects identity and stale-material discrimination, not the schema/policy source digest algorithm.

Historical key serde and constructors accept explicit version strings. Preserve that behavior: stored4.11.2 evidence remains4.11.2, current4.12.0 execution must not satisfy a4.11.2 map entry. No read migration, string replacement over artifacts, audit reseal, command codec change or historical fixture update. Manually authored4.11.2 tests in mode_contract.rs, policy.rs, readiness and legacy-only observations remain unchanged; they test supplied historical identity, not current compilation.

## Exact test candidate and admission

Two additive tests in platform/authz/tests/cedar_sdk_identity.rs:

1. compiled_bundle_keys_name_the_actual_linked_cedar_sdk: three real strict compilation entry paths must report cedar_policy::get_sdk_version(); the public constant must agree. Expected current source RED occurs after successful strict compilation at actual bundle identity comparison,4.11.2 versus4.12.0.
2. current_sdk_evaluation_rejects_historical_key_without_relabeling_it: actual RoleManage compilation/evaluation supplies genuine Allow; a map key naming actual SDK must Allow at the real policy boundary. Changing only SDK identity to manually authored historical4.11.2 must return StalePolicyBundle, while observation preserves its serialized expected key bytes and separately records the actual evaluated key. Current source is expected RED at the valid current-map positive control because its evaluated key is mislabeled. No synthetic CedarEvaluation::Allow replaces the engine call.

Exactly one existing current-compile unit assertion changes expected literal4.11.2 to get_sdk_version().to_string(). All its other assertions remain unchanged. assertion-correction.json gives the exact source/candidate hashes and rationale. This is a semantic oracle correction and requires independent review; it is not covered by ordinary test-preservation assumptions. tests.patch contains the new test and this assertion correction only; production constant remains stale in the candidate for real RED.

Root proposed exact commands from backend/ with its owned build environment:

`cargo +1.98.1 test --locked -p console-platform-authz --test cedar_sdk_identity -- --list`

`cargo +1.98.1 test --locked -p console-platform-authz --test cedar_sdk_identity -- --nocapture`

`cargo +1.98.1 test --locked -p console-platform-authz --lib cedar_pbac::engine::tests::matrix_generated_bundle_compiles_and_passes_strict_validation -- --exact --nocapture`

New target expected discovery2, executed2; existing corrected leaf expected executed1. These counts are expectations only: author ran no Cargo commands. Root admits the same failing new-target command after approved tests are integrated on an exact clean candidate. Implementation allowed path engine.rs only; new test frozen. Then rerun identical target and corrected unit leaf, followed by the existing focused cedar_diagnostic_fail_closed target and historical policy/mode evidence as required by reviewer; no unrelated suite expansion.

## Failure and recovery scope

Pre-mortem: changing a string everywhere rewrites historical evidence; testing against the same constant hides dependency drift; fake Allow hides a compiler bypass; cached old map and new engine accidentally match; correcting current test by deleting its assertion weakens evidence. Detection is linked-SDK oracle, real strict compiler/evaluator, positive current map, SDK-only historical mismatch, exact serialized expected/evaluated audit assertions and independent test review.

Blast radius: current compiled bundle SDK identity across the listed shared compiler callers. Preserve schema identity, source digest, language label, policy semantics, current authorization guards, error handling, historical serialized contracts, Cargo/lock/generated/SQL bytes. A current4.12.0 binary should refuse an explicitly pinned4.11.2 map; it must be recompiled/requalified rather than relabeled. Reverting only the fix reintroduces false version provenance; a legitimate software rollback uses the previously qualified full artifact and matching maps, preserving all historical records.

Stop for source drift, non-compilation RED, actual SDK oracle unavailable, unexpected historical key mutation, test failure outside intended identity assertion, mixed source/dependency recipe or unreviewed test edits. No deployment, native Company policy admission or complete Cedar acceptance is claimed. Reviewer /root/integration_security; author /root/reference_inventory; root executes and records actual RED/GREEN counts.
