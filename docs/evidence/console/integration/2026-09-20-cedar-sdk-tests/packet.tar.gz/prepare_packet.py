from pathlib import Path
import subprocess,hashlib,json,difflib
P=Path(__file__).parent; R=Path('/private/tmp/console-client-release-20260919'); BASE='03463f3c0fd0e08e9e9a7b50fc34058f7044d33f'
def sha(b):return hashlib.sha256(b).hexdigest()
engine='backend/crates/platform/authz/src/cedar_pbac/engine.rs'; test='backend/crates/platform/authz/tests/cedar_sdk_identity.rs'
old=subprocess.check_output(['git','show',BASE+':'+engine],cwd=R).decode(); assert(R/engine).read_text()==old
needle='        assert_eq!(bundle.key.cedar_sdk_version, "4.11.2");'
assert old.count(needle)==1
new=old.replace(needle,'        assert_eq!(\n            bundle.key.cedar_sdk_version,\n            cedar_policy::get_sdk_version().to_string()\n        );')
f=P/'candidate'/engine;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(new)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+engine,tofile='b/'+engine))
patch+=''.join(difflib.unified_diff([], (P/'candidate'/test).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+test))
(P/'tests.patch').write_text(patch)
paths=[engine,'backend/crates/platform/authz/Cargo.toml','backend/Cargo.lock','backend/crates/platform/authz/src/cedar_pbac.rs','backend/crates/platform/authz/src/cedar_pbac/authoring.rs','backend/crates/platform/authz/src/cedar_pbac/map.rs','backend/app/src/cedar_parity.rs','backend/crates/identity/rest/src/lib.rs','backend/crates/compliance/rest/src/lib.rs']
source={}
for p in paths:
 b=subprocess.check_output(['git','show',BASE+':'+p],cwd=R); assert (R/p).read_bytes()==b,p
 source[p]=sha(b)
(P/'source-custody.json').write_text(json.dumps({'base_sha':BASE,'source_sha256':source,'candidate_sha256':{p:sha((P/'candidate'/p).read_bytes()) for p in [engine,test]}},indent=2)+'\n')
correction={'kind':'proposed semantic test correction; requires independent review before application','path':engine,'test':'cedar_pbac::engine::tests::matrix_generated_bundle_compiles_and_passes_strict_validation','old_assertion':needle.strip(),'replacement_expected_value':'cedar_policy::get_sdk_version().to_string()','reason':'This test executes current real compilation; its expected4.11.2 is stale against Cargo/lock4.12.0. Replace expectation with linked SDK truth, preserving every other assertion. This strengthens current runtime identity, not historical fixture normalization.','source_sha256':source[engine],'candidate_sha256':sha((P/'candidate'/engine).read_bytes()),'existing_test_count_changed':1,'additive_test_count':2,'historical_test_fixtures_changed':0,'implementation_bytes_changed':0,'independent_review':'pending integration_security'}
(P/'assertion-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
cmd=['rustfmt','+1.98.1','--edition','2024','--config','skip_children=true','--check',str(P/'candidate'/engine),str(P/'candidate'/test)]
r=subprocess.run(cmd,capture_output=True,text=True);(P/'rustfmt.log').write_text(r.stdout+r.stderr);assert r.returncode==0
verification={'kind':'source-only candidate checks, not executed regression evidence','new_tests_authored':2,'existing_test_assertions_semantically_corrected':1,'new_tests_compiled':0,'new_tests_discovered':0,'new_tests_executed':0,'database_commands':0,'browser_commands':0,'source_custody_checks_passed':len(paths),'rustfmt_command':cmd,'rustfmt_exit_code':r.returncode,'runtime_red_required':'Parent root must compile/discover/execute exact approved tests on clean source/test candidate before admission; predicted failure is not executed RED.'}
(P/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({'patch_sha256':sha((P/'tests.patch').read_bytes()),'correction_sha256':sha((P/'assertion-correction.json').read_bytes())}))
