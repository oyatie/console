# JIT test prerequisite successor round3

Root sole repository writer. Apply only candidate Python test delta against integratedround2 preimage; Rusttest4406eff... is unchanged. Do not run historical-author-round2.py: it is retained construction history only. No productionwrapper, timeout, SQL, historicalserializer or other existingcase changed.

Root actual attempt proved JITon administrator but ssl=false before any wrapper call. Preserve that as prerequisitefailure, not ownerRED. New controlcalls explicitly request verify-full with fixedfixtureCA and GSSdisabled; default Suite.psql calls remain byte-equivalent in their emitted environment/argv/SQL. Private runner marks the generated publicservercertificate0644 before Docker copying so PostgreSQL can read it even under runnerumask077; privatekeys/passwords remain0600. Unreadable servercertificate is an identified prerequisite risk, not a measured claim about the previouscluster failure cause.

Actual TLS/JITon positivecontrol still must pass before each wrapper. Exact actual identityrefusal still precedes configoracle. Optional collect_failures=True only in private boundedrunner executes both independent profilecases and retains eachFAIL before raising aggregate; normal fullsuite retains stop-on-failure. Report countsactualwrapperinvocations and labels zero-wrapper failure PREREQUISITE. It cannot make an unrelatedschema/transport failure successful or prove intendedconfigRED.

Invoke after rootreviews/integrates:
`python3 /private/tmp/console-operator-jit-tests-20260920-round3/run-wrapper-jit.py /private/tmp/console-operator-jit-wrapper-red-round2-20260920`

Independentreview required. Author verification46/46machinerytests pass: allprevious44bodies ASTidentical plus2new explicitTLS/environment and dualfailurecollection tests. Pythonparse0. Rustunchanged. AuthoractualDB/wrapper0. Existing production60s/5s/verify-full/identity contract remains immutable; positiveSSL assertion is not weakened. Original PostgreSQL18.6 normal suite still separate from privatequalified18.4 probe. New actualRED/GREEN and retainedfinalizer runtime remain rootowned.
