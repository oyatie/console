#!/usr/bin/env python3
"""Bounded actual-wrapper configuration probe; no schema or finalization claim."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

PACKET = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/console-client-release-20260919')
SOURCE = 'ops/postgres-finalize-account-custody.integration.test.py'
IMAGE = 'postgres:18.4@sha256:65f70a152846cf504dff86e807007e9aeac98c3aeb7b62541b2c55ab9d264e56'

def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: run-wrapper-jit.py /absolute/fresh/output')
    output = Path(sys.argv[1])
    assert output.is_absolute() and not output.exists(), 'fresh owned output required'
    os.umask(0o077)
    output.mkdir(mode=0o700)
    custody = json.loads((PACKET/'source-custody.json').read_text())
    source = ROOT/SOURCE
    assert source.is_file() and not source.is_symlink()
    assert hashlib.sha256(source.read_bytes()).hexdigest() == custody[SOURCE]['candidate_sha256'], 'reviewed integrated test source required'
    spec = importlib.util.spec_from_file_location('real_operator_suite', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.ROOT == ROOT
    # This private probe selects the already-qualified initial substrate only;
    # the existing normal suite and its PostgreSQL18.6 pin remain unchanged.
    module.IMAGE = IMAGE
    report = {'kind':'ACTUAL_PSQL_CHILD_OPERATOR_CONFIGURATION_ONLY', 'image':IMAGE,
        'discovered':2, 'executed':0, 'passed':0, 'failed':0, 'status':'PREREQUISITE',
        'limits':['Wrong expected operator intentionally refuses before schema or installer work.',
                  'Not finalizer runtime/18.6 compatibility or release qualification.']}
    suite = module.Suite(output)
    try:
        paths = [SOURCE, 'ops/postgres-reconcile-topology.sh', *['ops/'+p for p in module.ASSETS]]
        suite.frozen_sources = module.source_snapshot(ROOT, paths)
        report['custody_before'] = suite.frozen_sources
        suite.run(['docker','image','inspect',IMAGE])
        suite.certificate()
        # Public server certificate must be readable by PostgreSQL after Docker
        # copies it as root; umask077 protects secrets but otherwise makes this
        # nonsecret certificate unreadable to the server and SSL reload fails.
        (suite.private/'server.crt').chmod(0o644)
        container = suite.cluster()
        _, version = suite.psql(container, 'postgres', "SELECT current_setting('server_version_num')")
        assert version.strip() == '180004', 'exact PostgreSQL18.4 required'
        suite.operator_jit_configuration_cases(container, collect_failures=True)
        suite.assert_sources_unchanged()
        report['custody_after'] = module.source_snapshot(ROOT, paths)
        report['status'] = 'PASS'
    except Exception as error:
        report['status'] = 'FAIL' if suite.results else 'PREREQUISITE'
        report['error'] = str(error)
        report['location'] = module.safe_failure_location(error)
    finally:
        try:
            failures = suite.cleanup()
            report['cleanup_failed_containers'] = failures
            if failures:
                report['status'] = 'FAIL'
        except Exception as error:
            report['cleanup_error'] = str(error)
            report['status'] = 'FAIL'
        report['cases'] = suite.results
        report['commands'] = suite.commands
        report['actual_wrapper_invocations'] = sum(
            '/wrapper-assets/postgres-finalize-account-custody.sh' in row['argv']
            for row in suite.commands)
        if report['status'] == 'FAIL' and report['actual_wrapper_invocations'] == 0:
            report['status'] = 'PREREQUISITE'
        report['executed'] = len(suite.results)
        report['passed'] = sum(x['status']=='PASS' for x in suite.results)
        report['failed'] = sum(x['status']=='FAIL' for x in suite.results)
        if report['status'] == 'PASS' and (report['executed'] != 2 or report['passed'] != 2 or report['actual_wrapper_invocations'] != 2):
            report['status'] = 'FAIL'
        (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','discovered','executed','passed','failed')}))
    return 0 if report['status']=='PASS' else 77 if report['status']=='PREREQUISITE' else 1

if __name__=='__main__':
    raise SystemExit(main())
