from pathlib import Path
import subprocess,hashlib,json,difflib
P=Path(__file__).parent;R=Path('/private/tmp/console-client-release-20260919');BASE='755271767e3553b12fe822dac740fac0e376ae76'
source_paths=['backend/app/tests/auth_rest/native_entry_ui_cases.rs','backend/app/tests/auth_rest/native_company_setup.rs','backend/crates/platform/request-context/src/lib.rs','backend/app/src/lib.rs','backend/crates/platform/auth-rest/src/account_entry.rs','backend/crates/platform/auth-rest/src/account_browser.rs','backend/crates/payroll/ui/src/native_account.rs','backend/app/tests/auth_rest/native_company_browser.rs','docs/evidence/console/integration/2026-09-20-company-entry-read-owner/browser/company-preview.cjs']
before={p:subprocess.check_output(['git','show',BASE+':'+p],cwd=R) for p in source_paths}
for p,b in before.items():assert (R/p).read_bytes()==b,p
p=source_paths[0];s=before[p].decode();start=s.index('fn native_root_parser_refusal(');end=s.index('\n#[sqlx::test',start)
s=s[:start]+'''fn native_root_parser_refusal(response: &Response, expected: StatusCode) {
    let html = native_entry_html(response, expected);
    if expected == StatusCode::PAYLOAD_TOO_LARGE {
        assert!(html.contains("이 요청을 열 수 없습니다"));
        for forbidden in ["<form", "data-account-state", "data-company-setup", "data-native-action"] {
            assert!(!html.contains(forbidden), "native413 exposed {forbidden}");
        }
    }
}
'''+s[end:];(P/'candidate'/p).write_text(s)
p=source_paths[1];s=before[p].decode();anchor='    #[cfg(feature = "test-browser")]\n    include!("native_company_browser.rs");';assert s.count(anchor)==1;s=s.replace(anchor,(P/'mounted-tests.rs').read_text()+'\n'+anchor);(P/'candidate'/p).write_text(s)
p=source_paths[2];s=before[p].decode();anchor='    #[tokio::test]\n    async fn envelope_rewrites_plain_408_and_413_to_json_error_body()';assert s.count(anchor)==1;s=s.replace(anchor,(P/'marked-tests.rs').read_text()+'\n'+anchor);f=P/'candidate'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
# Browser successor reuses exact accepted fixture, process ownership and database protocol.
s=before[source_paths[-1]].decode();assert hashlib.sha256(s.encode()).hexdigest()=='e14a328f59f263f5a64e86287545779cec8b03ad2b9872f120640e4caa3f10f0'
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:80],s.count(old));s=s.replace(old,new)
replace('// Parent owns DB truth and must acknowledge every checkpoint. No mock routes or cookies.','// Parent owns DB truth and acknowledges every checkpoint. Account cookies are real;\n// six unrelated browser-cookie fixtures exercise the aggregate header limit.')
replace("return ['/','/account/register','/account','/account','/account/companies/new'];", "return ['/','/account/register','/account','/account','/account/companies/new','/account/companies/new','/account/companies/new'];")
replace("row.redirected===false&&row.status===200&&row.url_exact===true", "row.redirected===false&&row.status===(index===5?413:200)&&row.url_exact===true")
replace("if(row.status!==200||row.redirected||!row.url_exact)", "if(row.status!==(row.ordinal===6?413:200)||row.redirected||!row.url_exact)")
replace("'preview_enter_preserved','business_input_not_stored'].every", "'preview_enter_preserved','business_input_not_stored','html413_native_document','html413_wire_cookie_witness','html413_cookies_preserved','html413_recovered'].every")
replace("&&Array.isArray(r.preview_enters)", "&&Number.isSafeInteger(r.html413_cookie_bytes)&&r.html413_cookie_bytes>16384&&r.html413_fixture_count===6&&Array.isArray(r.preview_enters)")
replace("'COMPANY_ENTRY','COMPANY_FORM'", "'HTML413_WIRE','HTML413_DOCUMENT','HTML413_RECOVERY','HTML413_COOKIE','COMPANY_ENTRY','COMPANY_FORM'")
anchor="  await checkpoint('PREVIEW_PRESERVED',account);"
addition='''  stage='html413_cookie_fixture';
  const identityCookies=JSON.stringify((await context.cookies(origin)).sort((a,b)=>a.name.localeCompare(b.name)));
  const fixtureCookies=Array.from({length:6},(_,index)=>({name:`html413_fixture_${index}`,value:`${index}_`+'q'.repeat(3000),url:origin+'/',secure:true,sameSite:'Lax'}));
  await context.addCookies(fixtureCookies);
  stage='html413_document';
  const rejected=await page.goto(origin+'/account/companies/new',{waitUntil:'domcontentloaded'});
  requireFact(rejected?.status()===413,'HTML413_DOCUMENT');
  const wire=(await rejected.request().allHeaders()).cookie??'';
  result.html413_cookie_bytes=Buffer.byteLength(wire,'utf8');result.html413_fixture_count=fixtureCookies.length;
  result.html413_wire_cookie_witness=result.html413_cookie_bytes>16384&&fixtureCookies.every(cookie=>wire.split(';').map(value=>value.trim()).includes(cookie.name+'='+cookie.value));
  requireFact(result.html413_wire_cookie_witness,'HTML413_WIRE');
  const responseHeaders=await rejected.headersArray();
  const requiredHeaders={'content-type':'text/html; charset=utf-8','cache-control':'no-store','pragma':'no-cache','x-content-type-options':'nosniff','referrer-policy':'no-referrer','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"};
  const varyHeaders=responseHeaders.filter(h=>h.name.toLowerCase()==='vary');
  const varyValid=varyHeaders.length===1&&varyHeaders[0].value.split(',').map(value=>value.trim().toLowerCase()).sort().join(',')==='authorization,cookie,origin';
  const privacy=varyValid&&Object.entries(requiredHeaders).every(([name,value])=>{const values=responseHeaders.filter(h=>h.name.toLowerCase()===name);return values.length===1&&values[0].value===value;})&&!responseHeaders.some(h=>h.name.toLowerCase()==='set-cookie');
  const failedBody=await rejected.text();
  result.html413_native_document=privacy&&failedBody.includes('lang="ko"')&&failedBody.includes('<main')&&failedBody.includes('이 요청을 열 수 없습니다')&&!failedBody.includes(account)&&['<form','data-account-state','data-company-setup','data-native-action'].every(value=>!failedBody.includes(value))&&fixtureCookies.every(cookie=>!failedBody.includes(cookie.value));
  requireFact(result.html413_native_document,'HTML413_DOCUMENT');
  requireFact(await page.getByRole('heading',{name:'이 요청을 열 수 없습니다',exact:true}).count()===1,'HTML413_DOCUMENT');
  await secretFree();await capture('05-native-cookie-413.png');
  stage='html413_recovery';
  for(const cookie of fixtureCookies)await context.clearCookies({name:cookie.name});
  result.html413_cookies_preserved=identityCookies===JSON.stringify((await context.cookies(origin)).sort((a,b)=>a.name.localeCompare(b.name)));
  requireFact(result.html413_cookies_preserved,'HTML413_COOKIE');
  const recovered=await page.reload({waitUntil:'domcontentloaded'});
  result.html413_recovered=recovered?.status()===200&&await page.locator('[data-company-setup]').count()===1&&await page.locator('form,[type="submit"],[data-native-action]').count()===0;
  requireFact(result.html413_recovered,'HTML413_RECOVERY');await secretFree();await capture('06-native-cookie-recovered.png');
'''
replace(anchor,addition+anchor)
(P/'company-preview.cjs').write_text(s)
controls=Path('/private/tmp/console-company-preview-owner-label-correction-20260920/preview-controls.cjs').read_text()
controls=controls.replace("'/account/companies/new'];", "'/account/companies/new','/account/companies/new','/account/companies/new'];")
controls=controls.replace("'literal_secret_absent'];", "'literal_secret_absent','html413_native_document','html413_wire_cookie_witness','html413_cookies_preserved','html413_recovered'];")
controls=controls.replace("redirected:false,status:200,url_exact:true", "redirected:false,status:i===5?413:200,url_exact:true")
controls=controls.replace("document_failures:0,", "document_failures:0,html413_cookie_bytes:18090,html413_fixture_count:6,")
controls=controls.replace("r=>r.checkpoints.pop()];", "r=>r.checkpoints.pop(),r=>r.documents[5].status=200,r=>r.documents[6].status=413,r=>r.html413_native_document=false,r=>r.html413_wire_cookie_witness=false,r=>r.html413_cookies_preserved=false,r=>r.html413_recovered=false,r=>delete r.html413_cookie_bytes,r=>r.html413_cookie_bytes=16384,r=>r.html413_fixture_count=5];")
(P/'preview-controls.cjs').write_text(controls)
paths=[source_paths[0],source_paths[1],source_paths[2],'backend/crates/platform/request-context/tests/native_error_envelope.rs']
cmd=['rustfmt','+1.98.1','--edition','2024','--config','skip_children=true']+[str(P/'candidate'/p) for p in paths]
r=subprocess.run(cmd,capture_output=True,text=True);(P/'rustfmt.log').write_text(r.stdout+r.stderr);assert r.returncode==0
patch=''
for p in paths:
 old=before.get(p,b'').decode();new=(P/'candidate'/p).read_text()
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p if p in before else '/dev/null',tofile='b/'+p))
(P/'tests.patch').write_text(patch)
(P/'browser-successor.patch').write_text(''.join(difflib.unified_diff(before[source_paths[-1]].decode().splitlines(True),s.splitlines(True),fromfile='accepted/company-preview.cjs',tofile='successor/company-preview.cjs')))
(P/'source-custody.json').write_text(json.dumps({'base_sha':BASE,'source_sha256':{p:hashlib.sha256(b).hexdigest() for p,b in before.items()},'candidate_sha256':{p:hashlib.sha256((P/'candidate'/p).read_bytes()).hexdigest() for p in paths},'accepted_browser_driver_sha256':'e14a328f59f263f5a64e86287545779cec8b03ad2b9872f120640e4caa3f10f0'},indent=2)+'\n')
print('private Rust test files formatted; no compile/test execution')
