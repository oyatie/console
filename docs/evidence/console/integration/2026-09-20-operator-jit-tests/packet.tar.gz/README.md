# Exact additive operator JIT test proposal

Author: /root/integration_security. Root remains sole repository writer. No product, historical SQL, generator, migration, timeout, TLS or identity contract changes. No runtime tests executed by author.

Two candidate files:
- audit_account_transition.rs: one added SQLx test operator_jit_is_disabled_locally_with_original_timeouts. Sets checked-out session JITon, calls real existing operator in a transaction, captures exactoff/1min/5s/qualifiedsearchpath, rolls back, proves original settings restored, restores original JIT before RED assertion. Existing operator and all tests byte-preserved.
- postgres-finalize-account-custody.integration.test.py: retains all original cases/tests, adds two named real operator child-configuration cases and two machinery tests. Existing actual psql forwarding spy optionally observes only explicit nonsecret PGOPTIONS/TLS/connectbudget. Historical traces never enable this option. New cases use both actual wrapper profiles, deliberately incorrect expectedoperator against disposable postgres database, require exact production identity refusal before schema, inject hostile ambient PGOPTIONS/TLS values and demand the wrapper's fixed scrubbed options. Qualified JIT setting is one-shot; later administrator sessions remain JITon.

Normal suite still pins PostgreSQL18.6. run-wrapper-jit.py privately imports the exact integrated reviewed test candidate and reuses its real TLS cluster/cleanup at existing qualified18.4 pinned digest; no fakepsql, no install or schema claims. Entire production wrapper and composed fileargv execute unchanged up to deliberateidentity refusal. Parent may run this boundedprobe after testintegration; fullfinalizer runtime and mixedversion compatibility remain separate requirements. Runner binds root HEAD and exact assets before/after; only owned container removed.

Suggested actual commands after root integration:
```
python3 /private/tmp/console-operator-jit-tests-20260920-round2/run-wrapper-jit.py /private/tmp/console-operator-jit-wrapper-red-20260920
```
Use the existing cargo_needs_postgres runner/fullmap prerequisites for exact SQLx leaf:
`account_browser::audit_account_transition::operator_jit_is_disabled_locally_with_original_timeouts`
No timeoutincrease or test weakening. The same actual commands must go GREEN after admitted two runtime-setting edits. Retained predecessor4 and eligibility6 transitions remain required.

Author verification: candidate Python AST parses, full Rustfmt passes;44machinerytests pass, including existing42 and new2 (1positive+16malformed environmentcontrols). First private44testattempt failed3 historical siblingfixture prerequisites because packet omitted fixtureassets; those unchanged assets were copied and the same44tests passed. That is not a runtimeRED. All fixturecopies are custody-only and never repository changes. No Cargo compile, actual PostgreSQL or wrapper process execution by author.

Pre-mortem: environment parsed from source instead of actual child, inherited jitoff falsegreen, fixture-only production mismatch, config escaped transaction, unrelatedschemafailure used asRED. Detection: realforwardingchild, forcedJITon, wrongexpectedoperator exactrefusal, fullsettingsrollback, immutable sourcefiles. Rollback: discard privatefixture; rootreverts additive tests only if rejected, never deletes original assertions. Stop on missingrealTLS/identity, changed historicalbytes, decreased/increasedtimeouts, secrets, staleHEAD/source, unownedcleanup or incorrectfailurecause. Design contract: /private/tmp/console-operator-jit-design-20260920.md.

Round2: parent review found configuration assertion could mask an unrelated wrapper failure. Actual wrapper exit/nonzero plus precise operator_identity_mismatch and absence of native_finalized now execute before the environment oracle, while TLS/JITon positive control still precedes the wrapper. Original traced-wrapper calls are unchanged.44machinerytests reexecuted/pass; runtime0.
