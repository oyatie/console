from pathlib import Path
import difflib,json,hashlib,subprocess
root=Path('/private/tmp/console-client-release-20260919');out=Path(__file__).parent
rust_path='backend/app/tests/auth_rest/audit_account_transition.rs';py_path='ops/postgres-finalize-account-custody.integration.test.py'
rust=(root/rust_path).read_text();py=(root/py_path).read_text()
addition='''    // Execution settings belong to the operator transaction, not pooled callers.
    #[sqlx::test(migrations = false)]
    async fn operator_jit_is_disabled_locally_with_original_timeouts(pool: PgPool) {
        let mut connection = pool.acquire().await.unwrap();
        let original_jit: String = sqlx::query_scalar("SELECT current_setting('jit')")
            .fetch_one(&mut *connection).await.unwrap();
        sqlx::raw_sql("SET SESSION jit=on").execute(&mut *connection).await.unwrap();
        let settings = "SELECT current_setting('jit'),current_setting('statement_timeout'),current_setting('lock_timeout'),current_setting('search_path')";
        let before: (String, String, String, String) = sqlx::query_as(settings)
            .fetch_one(&mut *connection).await.unwrap();
        assert_eq!(before.0, "on", "positive control must not inherit jit=off");
        let mut tx = sqlx::Connection::begin(&mut *connection).await.unwrap();
        operator(&mut tx).await;
        let inside: (String, String, String, String) = sqlx::query_as(settings)
            .fetch_one(&mut *tx).await.unwrap();
        tx.rollback().await.unwrap();
        let after: (String, String, String, String) = sqlx::query_as(settings)
            .fetch_one(&mut *connection).await.unwrap();
        // Restore this checked-out connection even when the final assertion is RED.
        sqlx::query("SELECT set_config('jit',$1,false)").bind(original_jit)
            .execute(&mut *connection).await.unwrap();
        assert_eq!(after, before, "operator settings escaped their transaction");
        assert_eq!(inside, ("off".into(), "1min".into(), "5s".into(), "pg_catalog, pg_temp".into()),
            "operator must disable JIT without changing execution budgets or search path");
    }

'''
needle='    // Filled from immutable source bytes before packet publication.';assert rust.count(needle)==1;rust=rust.replace(needle,addition+needle)
fn='''def assert_operator_child_environment(trace):
    """Only explicit nonsecret fields emitted by the actual psql child shim."""
    expected = ['BEGIN_OPERATOR_ENV', 'PGOPTIONS',
                '-c search_path=pg_catalog,pg_temp -c statement_timeout=60000 -c lock_timeout=5000 -c jit=off',
                'PGSSLMODE', 'verify-full', 'PGGSSENCMODE', 'disable',
                'PGCONNECT_TIMEOUT', '10', 'END_OPERATOR_ENV', '']
    assert trace.split('\\0') == expected, 'actual psql child execution settings differ from fixed operator contract'


'''
needle='def complete_case_roster(results):';assert py.count(needle)==1;py=py.replace(needle,fn+needle)
py=py.replace("         'native_extension_late_failure_rolls_back_then_retries')", "         'native_extension_late_failure_rolls_back_then_retries',\n         'operator_jit_default_child_settings', 'operator_jit_observer_child_settings')")
py=py.replace("def traced_wrapper(self, container, database, expected, *, observer=False, assets='/wrapper-assets'):","def traced_wrapper(self, container, database, expected, *, observer=False, assets='/wrapper-assets', execution_settings=False):")
needle="        shim = self.private_file(f'psql-shim-{number}',\n";assert py.count(needle)==1
py=py.replace(needle,"""        environment_path = directory+'/environment'
        environment_trace = (
            "printf '%s\\\\0' BEGIN_OPERATOR_ENV PGOPTIONS \\\"${PGOPTIONS-}\\\" "
            "PGSSLMODE \\\"${PGSSLMODE-}\\\" PGGSSENCMODE \\\"${PGGSSENCMODE-}\\\" "
            "PGCONNECT_TIMEOUT \\\"${PGCONNECT_TIMEOUT-}\\\" END_OPERATOR_ENV > "+environment_path+'\\n'
        ) if execution_settings else ''
"""+needle)
needle="            'exec '+actual_psql+' \"$@\"\\n')";assert py.count(needle)==1;py=py.replace(needle,"            +environment_trace+'exec '+actual_psql+' \"$@\"\\n')")
needle="        result = self.wrapper(container, database, expected, observer=observer, assets=assets,\n            PATH=directory+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin')";assert py.count(needle)==1
py=py.replace(needle,"""        hostile_ambient = {'PGOPTIONS':'-c jit=on -c statement_timeout=0 -c lock_timeout=0',
                           'PGSSLMODE':'disable', 'PGGSSENCMODE':'prefer'} if execution_settings else {}
        result = self.wrapper(container, database, expected, observer=observer, assets=assets,
            PATH=directory+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
            **hostile_ambient)""")
needle="        assert_composed_psql_trace(trace, assets, observer)\n        return result";assert py.count(needle)==1;py=py.replace(needle,"""        assert_composed_psql_trace(trace, assets, observer)
        if execution_settings:
            code, text = result
            assert code != 0 and 'account_custody.operator_identity_mismatch' in text, 'actual production preflight identity refusal required before configuration oracle'
            assert 'account_custody.native_finalized' not in text
            _, environment = self.run(['docker', 'exec', container, 'cat', environment_path])
            assert_operator_child_environment(environment)
        return result""")
method='''    def operator_jit_configuration_cases(self, container):
        # Real TLS psql executes the original production preflight. Deliberately
        # wrong expected identity stops before any schema/installer dependency.
        descriptor = self.descriptor(container, 'postgres')
        descriptor['ACCOUNT_CUSTODY_EXPECTED_OPERATOR'] = 'not_the_actual_operator'
        for observer, name in ((False, 'operator_jit_default_child_settings'),
                               (True, 'operator_jit_observer_child_settings')):
            def observe(observer=observer):
                sql = "SELECT current_setting('jit'),session_user,current_user,current_database(),(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid())"
                _, before = self.psql(container, 'postgres', sql)
                assert before.strip() == 'on|wrapper_admin|wrapper_admin|postgres|t', 'real TLS administrator and default JIT-on positive control required'
                code, text = self.traced_wrapper(container, 'postgres', descriptor,
                    observer=observer, execution_settings=True)
                assert code != 0 and 'account_custody.operator_identity_mismatch' in text, 'actual production preflight identity refusal required'
                assert 'account_custody.native_finalized' not in text
                _, after = self.psql(container, 'postgres', sql)
                assert after == before, 'one-shot options escaped into later sessions'
            self.case(name, observe)

'''
needle='    def certificate(self):';assert py.count(needle)==1;py=py.replace(needle,method+needle)
needle='        first,second=self.cluster(),self.cluster()\n';assert py.count(needle)==1;py=py.replace(needle,needle+'        self.operator_jit_configuration_cases(first)\n')
controls='''        def test_operator_child_execution_settings_positive(self):
            trace = '\\0'.join(['BEGIN_OPERATOR_ENV', 'PGOPTIONS',
                '-c search_path=pg_catalog,pg_temp -c statement_timeout=60000 -c lock_timeout=5000 -c jit=off',
                'PGSSLMODE', 'verify-full', 'PGGSSENCMODE', 'disable',
                'PGCONNECT_TIMEOUT', '10', 'END_OPERATOR_ENV', ''])
            assert_operator_child_environment(trace)

        def test_operator_child_execution_settings_reject_corruption(self):
            trace = '\\0'.join(['BEGIN_OPERATOR_ENV', 'PGOPTIONS',
                '-c search_path=pg_catalog,pg_temp -c statement_timeout=60000 -c lock_timeout=5000 -c jit=off',
                'PGSSLMODE', 'verify-full', 'PGGSSENCMODE', 'disable',
                'PGCONNECT_TIMEOUT', '10', 'END_OPERATOR_ENV', ''])
            corruptions = [trace.replace(' -c jit=off', ''), trace.replace('jit=off', 'jit=on'),
                trace.replace('jit=off', 'jit=off -c jit=on'), trace.replace('jit=off', 'jit=off -c jit=off'),
                trace.replace('60000', '120000'), trace.replace('60000', '1000'),
                trace.replace('5000', '10000'), trace.replace('5000', '100'),
                trace.replace('pg_catalog,pg_temp', 'public'), trace.replace('verify-full', 'require'),
                trace.replace('disable', 'prefer'), trace.replace('\\0'+'10'+'\\0', '\\0'+'0'+'\\0'),
                trace.replace('END_OPERATOR_ENV', ''), trace[:-1], trace+trace,
                trace.replace('BEGIN_OPERATOR_ENV', 'FORGED_OPERATOR_ENV')]
            for malformed in corruptions:
                with self.subTest(trace=malformed), self.assertRaises(AssertionError):
                    assert_operator_child_environment(malformed)

'''
needle='        def test_operator_assets_have_exact_six_without_losing_manifest_index(self):';assert py.count(needle)==1;py=py.replace(needle,controls+needle)
(out/'audit_account_transition.rs').write_text(rust);subprocess.run(['/Users/jasonlee/.cargo/bin/rustfmt','--edition','2024',str(out/'audit_account_transition.rs')],check=True)
(out/'postgres-finalize-account-custody.integration.test.py').write_text(py)
for source,name in [(rust_path,'audit_account_transition.rs'),(py_path,'postgres-finalize-account-custody.integration.test.py')]:
 (out/(name+'.diff')).write_text(''.join(difflib.unified_diff((root/source).read_text().splitlines(True),(out/name).read_text().splitlines(True),fromfile=source,tofile=source)))
(out/'source-custody.json').write_text(json.dumps({source:{'preimage_sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for source,name in [(rust_path,'audit_account_transition.rs'),(py_path,'postgres-finalize-account-custody.integration.test.py')]},indent=2)+'\n')
