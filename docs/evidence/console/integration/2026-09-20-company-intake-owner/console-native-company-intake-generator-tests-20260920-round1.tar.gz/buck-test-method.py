    def test_private_company_intake_auth_rest_resources_are_complete(self) -> None:
        config = GENERATOR.integration_resource_config("console-app", "tests/auth_rest.rs")
        self.assertEqual(
            config["external"].get("//ops:postgres-company-enrollment-intake.sql"),
            "ops/postgres-company-enrollment-intake.sql",
        )
        self.assertTrue((Path(GENERATOR.REPO) / "backend/app/tests/auth_rest/native_company_intake_owner.rs").is_file())

