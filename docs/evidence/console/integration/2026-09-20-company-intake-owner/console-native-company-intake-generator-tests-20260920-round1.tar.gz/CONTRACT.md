# Private Company intake resource: preservation/Buck test successor

Private test source at 66b2e949ba1e80005d50e205d8ecd2f04516254e. Root is sole repository/generated-file writer. No tests, builds, SQL, product runtime or generators executed by author; executed tests0. Source AST comparison establishes66preexisting Buck test methods byte-identical and67prospective methods; this is not test execution.

Reuse /private/tmp/console-native-company-intake-owner-refinement-20260920-round2 manifest353a905291a6d4494c0c9876122816421e7b3af188ea805444353580f3f39df8. That narrow owner-source proposal is still under independent review; this resource packet does not clear its HOLDs or create a stub.

## Exact preservation

Keep existing one generator test method. Freeze all eight predecessor generated files: six historical EXPECTED digests and exact disk equality unchanged; parser fixed digest/output/function/disk and declaration/UNINSTALLED checks retained; schema adds fixed SHA2567e1dbee080cb3f09d0133ac9a30857ee5101a076e1cec171ec06849116e672bb while retaining output/function/disk, three table declarations and exclusion from prior outputs.

Only new allowed output is ops/postgres-company-enrollment-intake.sql, exactly matching GENERATOR.company_enrollment_intake_sql() and disk. Require UNINSTALLED and all four accepted CREATE FUNCTION declarations, absent from every predecessor. Output key equality allows exactly9files. Marker checks establish separation only; SQL correctness is independently reviewed owner-source tests and actual execution. No old byte reseal, migration, finalizer/classifier change or production activation.

## Exact Buck addition

One new method test_private_company_intake_auth_rest_resources_are_complete requires auth_rest external mapping //ops:postgres-company-enrollment-intake.sql to ops/postgres-company-enrollment-intake.sql and integrated native_company_intake_owner.rs. Every66existing method is byte-identical. Root alone adds corresponding runtime mapping/export and regenerates projections; this packet modifies neither. The complete generator test file is a projection of its patch, not a second installed module.

## Failure and recovery

Pre-mortem: predecessor rewrite hidden by output expansion or unrelated missing-resource RED. Detection:8fixed digests, exact9output set, function/disk checks and precise Buck mapping. Blast radius: existing preservation method plus1new resource regression. Rollback prospective additions together before installation; preserve all historical bytes and evidence. Stop on source-lock mismatch, changed predecessor digest, stub owner, missing independent review or passing missing-schema failure as the actual owner RED. Root records exact Buck-native commands/counts on integration. Request reviews from integration_security and integration_tests. Full auth, lock/expiry/cleanup coverage, effect completion and release qualification remain outstanding.
