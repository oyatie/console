# Workload, durability, and recovery readiness

The first implementation needs explicit correctness, durability, migration, and recovery contracts plus independently challenged tests at the boundaries available today. It does not need production capacity certification or every operational drill before code exists. Acceptance of the implemented slice and permission to expose it are separate gates. This recommendation follows from the different guarantees and limitations documented by PostgreSQL and the original concurrency-testing research.

The recent-source check found PostgreSQL 18.6, released August 13, 2026. The PostgreSQL 18 manual pages below are versioned but do not state individual publication dates; they are treated as undated technical baselines, not relabelled as August publications. The original research is explicitly older. All sources were accessed September 13, 2026. Raw documents, response headers, extracted text, fetch outcomes and SHA256 identities accompany this report in `source-inventory.json`.

## Durability and unknown outcomes

PostgreSQL defines `synchronous_commit` in terms of how much WAL processing occurs before the server returns a success indication. With `synchronous_standby_names` empty, even `remote_apply` does not create a remote-durability guarantee. With synchronous standbys configured, `on` waits for remote durable flush, `remote_write` waits for the standby operating system to accept the write, and `remote_apply` also waits for replay and query visibility. The setting in effect at commit determines the transaction's behavior.[^1]

**Exact passages.** Section19.5.1 says: “Specifies how much WAL processing must complete before the database server returns a ‘success’ indication to the client.” It also says remote_write does not ensure preservation if the standby suffers an operating-system-level crash. Section26.2.8 says streaming replication is asynchronous by default and committed transactions can be absent from the standby after primary failure.[^1][^2]

**Implication.** Before implementing a receipt or publication ACK, specify the actual boundary: local flush, selected synchronous durable replica, or replay visibility. Record server minor version, effective per-transaction settings, selected standby state and topology. A primary-only test cannot establish a replicated-ACK contract. A synchronous setting cannot establish independent failure domains, correct promotion selection, or application policy authority.

A cancellation request is not a rollback receipt. PostgreSQL explicitly warns that the cancellation signal “might or might not have any effect” and that the frontend has “no direct way to tell whether a cancel request has succeeded.” On disconnection, open transactions are rolled back, but a non-SELECT query can finish and an implicit transaction can commit before the backend notices the disconnect.[^3]

**Inference.** A client timeout or lost COMMIT response leaves outcome uncertainty when the server may already have committed. Rust future cancellation is not itself a PostgreSQL cancellation acknowledgment. These are different mechanisms and need separate witnesses.

**First-slice tests.** Retain the existing witnessed precommit cancellation tests, but do not call them COMMIT-transport tests. Add an actual transport cut at a declared commit/response boundary when the corresponding owner is implemented. Retain the original intent and command identity, classify the immediate result as unknown, then reconcile from the authoritative complete owner state. Do not create a new command identity or blindly retry a non-idempotent owner. A missing row on a possibly stale replica is not definitive no-effect evidence.

PostgreSQL's retry guidance is narrower than “retry errors”: SQLSTATE40001 and sometimes40P01 require whole-transaction retry, including the logic selecting SQL and values. Unique/exclusion errors may instead be persistent conflicts. The server deliberately supplies no universal automatic retry facility.[^4] Revalidated authority, deadlines and dependencies therefore belong inside the retry contract; a stale preflight must not survive a fresh transaction by accident.

## Failover, fencing, and restoration

PostgreSQL's failover documentation requires a mechanism that prevents the old primary from believing it remains primary after a standby is promoted. It names STONITH and warns that two primaries lead to confusion and data loss. PostgreSQL also states that it does not provide the system software that detects primary failure and notifies the standby.[^5]

**Exact passage.** “If the primary server fails and the standby becomes the new primary, and then the old primary restarts, you must have a mechanism for informing the old primary that it is no longer the primary.”[^5]

**Gate timing.** Define fencing ownership, promotion eligibility, failure assumptions and reconciliation authority before dependent persistence code. Exercise local primary/standby failure, stale-primary return and unknown-command reconciliation before accepting the slice's claimed recovery behavior. Demonstrate actual credential/network isolation, placement and operational ownership before production exposure. A separate process on one workstation is useful local fault evidence; it does not demonstrate independent administrative or failure domains.

PostgreSQL point-in-time recovery deliberately creates a new timeline. The archive records which timeline branched from which and when.[^6] This supports physical recovery mechanics, but does not make restored grants, revoked credentials, retention decisions or external effects current again.

**First-slice tests.** Seed an older backup; record newer command success, credential revocation and protected lifecycle state; restore the older state; then demonstrate that serving remains blocked until the selected current authority sources and fencing conditions are reconciled. Compare complete acknowledged owner effects and receipts at the declared WAL/timeline boundary. Physical row recovery and authorization to resume effects must be distinct assertions. A response-suppression test followed by a healthy-primary read is useful but cannot substitute for this fixture.

## Open-loop workload accounting

Schroeder, Wierman and Harchol-Balter define a closed model as one in which job completions trigger arrivals, and an open model as one in which arrivals occur independently. Their experiments show materially different behavior, including different conclusions about scheduling. They also discuss partly open models and choosing the model appropriate to the workload; the paper does not establish open-loop traffic as universally appropriate.[^7]

PostgreSQL's own `pgbench --rate` provides a concrete accounting reference. Its expected schedule advances from client start, not the previous transaction's end. Under rate control, reported latency includes schedule lag; lag is also reported separately. With a latency limit, transactions already too late are not sent and are reported as skipped.[^8]

**Exact passages.** The pgbench manual says: “The expected start time schedule moves forward based on when the client first started, not when the previous transaction ended.” It also says skipped transactions are “counted separately.”[^8]

**First-slice implications.** Freeze original intended arrivals and record every disposition, including generator rejection or lateness. Separately retain scheduler admission, actual owner invocation and completion times. Owner-call duration includes pool acquisition unless a separately instrumented boundary proves otherwise. Bound queued count, bytes, age, active tasks, retry attempts and history storage. Keep client admission rejection separate from server rejection and expected semantic conflict. A missed forced hot-phase schedule must invalidate that characterization rather than silently becoming an easier workload.

Use disjoint operations as positive controls, then hot-key traffic with independent victims sharing the actual serving resources, and continued arrivals during recovery. A zero-arrival drain is a separate measurement. The current twelve-intent characterization can validate this machinery; it is too small to establish percentiles, a 2,000-person capacity envelope, or backlog stability.

**Scale-trigger experiments.** Vary active arrival rate, hot-key fraction, per-command dependency work, data cardinality, cache state and resource allocation independently. Preserve useful-outcome accounting and identical semantic/failure boundaries across candidate assemblies. Measure pool wait, lock wait, CPU, WAL/replay delay, retained history and victim degradation. Change architecture only when a reproducible failure envelope and a tested alternative justify the migration cost. Employee counts of50,000 or1,000,000 alone do not identify the limiting mechanism or establish that partitioning, MVCC changes or new locking are necessary.

## Independent oracles and fault tests

Herlihy and Wing define linearizability using a legal sequential history that respects real-time precedence. An operation appears to take effect between invocation and response. Their definition explicitly allows some pending invocations to have taken effect even when their responses have not returned.[^9]

**Implication.** Histories need invocation/response intervals and a sequential domain contract; final row counts alone cannot demonstrate the permitted order. A checker accepting one possible completion of an incomplete history establishes a safety property under its model, not that the operational recovery process has resolved unknown commands or met a liveness deadline. Keep those verdicts separate.

The original Elle paper infers dependency graphs from deliberately chosen operations whose returned values reveal version history. Its soundness depends on this observability. The paper expressly says its approach ignores predicates and cannot distinguish repeatable read from serializability.[^10] This is a limitation of the cited2020 paper, not an assessment of all present-day Elle implementations.

**First-slice implications.** Retain complete original-intent histories and independent effect/audit/receipt readback. Challenge the checker using omitted requests, missing effects, wrong attribution, duplicate effects, orphan audits, unknown-to-no-effect relabelling, invalid timestamps and missing fault witnesses. For payroll/attendance, add explicit population, absence and membership-change schedules: a checker operating only on individual-row versions cannot by itself validate the complete eligible roster or a negative predicate. Do not turn checker mutation assertions into additional independently discovered Rust test counts.

FoundationDB's original2021 paper is especially relevant to the machinery boundary. Its simulator runs the real database software with synthetic workloads and injected faults. It uses several oracles, checks recovery after restoring an environment in which recovery should be possible, and measures whether rare conditions actually occurred. The authors warn that excessive fault injection can drive the system into a small state space. They also state simulation cannot reliably detect performance issues or test dependencies outside its modeled runtime.[^11]

**Recommendation.** Reuse the real Console owners and PostgreSQL fixture rather than writing a second fake payroll engine. Prefer deterministic observed barriers for narrow races, then add bounded randomized schedules where they expand coverage. Record boundary reachability and positive controls, not just test counts. A custom FoundationDB-style simulator is not a prerequisite to first implementation: its architecture was designed around that testing model, and its limitations still require live performance and hardware failure tests.[^11][^12]

## Migration and environment compatibility

PostgreSQL logical replication does not replicate schema/DDL or sequence state. The documentation recommends applying additive subscriber changes first in many compatible migrations; otherwise incoming data can stop replication until the schema is updated.[^13] This is relevant if logical replication is selected, not evidence that Console needs it.

`pg_upgrade` documents irreversible differences between modes. In link mode, starting the upgraded cluster makes the old cluster unusable; clone mode avoids that particular consequence. It also recommends deployment tests using a schema-only copy with representative dummy data.[^14]

**Gate timing.** Declare source/target schema, mixed-version readers/writers, stable backfill identity, quarantine accounting, interruption/restart behavior and rollback cut points before dependent implementation. Execute conversion and coexistence tests before slice acceptance. Validate actual backups, restore procedures, operator permissions and deployment-specific rollback before exposure. Rolling back a binary is not restoring data; restoring data is not permission to revive old credentials or overwrite newer acknowledged effects.

The August2026 PostgreSQL18.6 release notes provide a concrete reason to pin and verify the minor release. They document a fix to invalidate role-dependent cached plans after role changes: cached RLS plans could otherwise continue using the old role membership, attributes or database-ownership state. They also state18.5 was never released because of a post-wrap regression.[^15]

**Actionable check.** Record the exact server binary/image and relevant extensions. Include restricted pooled sessions executing prepared queries before and after authority changes. Assess the version-specific fix when interpreting the result; application cache invalidation and the label“PostgreSQL18” alone do not establish this server behavior. This finding supports compatibility verification, not an unreviewed dependency upgrade.

## Implementation gate conclusion

Before implementation: settle only the contracts that constrain the admitted owner, author and independently review its real fixtures/oracles, execute available boundaries, distinguish prerequisite failures from behavioral RED, and bind the lane to exact reviewed source/environment/probe identities.

Before slice acceptance: reach and pass the required domain, policy, persistence, migration, concurrency, recovery and browser assertions; demonstrate positive valid workflows; evaluate the slice's declared workload envelope. A lower prerequisite becoming green triggers deeper execution, not retrospective credit for assertions that never ran.

Before production exposure: verify actual topology, effective durability, fencing, credentials, backups, providers, operating limits and recovery ownership. These conclusions cannot be inferred from local test counts, simulated faults, a version pin, or a mathematical history checker.

## Sources

[^1]: PostgreSQL Global Development Group. [PostgreSQL18 §19.5 Write Ahead Log](https://www.postgresql.org/docs/18/runtime-config-wal.html), especially §19.5.1 synchronous_commit. Undated versioned manual.
[^2]: PostgreSQL Global Development Group. [PostgreSQL18 §26.2 Log-Shipping Standby Servers](https://www.postgresql.org/docs/18/warm-standby.html), especially §26.2.8 Synchronous Replication. Undated versioned manual.
[^3]: PostgreSQL Global Development Group. [PostgreSQL18 §54.2 Message Flow](https://www.postgresql.org/docs/18/protocol-flow.html), §§54.2.8–54.2.9. Undated versioned manual.
[^4]: PostgreSQL Global Development Group. [PostgreSQL18 §13.5 Serialization Failure Handling](https://www.postgresql.org/docs/18/mvcc-serialization-failure-handling.html). Undated versioned manual.
[^5]: PostgreSQL Global Development Group. [PostgreSQL18 §26.3 Failover](https://www.postgresql.org/docs/18/warm-standby-failover.html). Undated versioned manual.
[^6]: PostgreSQL Global Development Group. [PostgreSQL18 §25.3 Continuous Archiving and Point-in-Time Recovery](https://www.postgresql.org/docs/18/continuous-archiving.html), especially §25.3.6 Timelines. Undated versioned manual.
[^7]: Bianca Schroeder, Adam Wierman and Mor Harchol-Balter. [Open Versus Closed: A Cautionary Tale](https://www.usenix.org/legacy/event/nsdi06/tech/full_papers/schroeder/schroeder.pdf). NSDI2006, abstract and workload-model discussion. Older foundational primary research.
[^8]: PostgreSQL Global Development Group. [PostgreSQL18 pgbench](https://www.postgresql.org/docs/18/pgbench.html), --rate, --latency-limit and per-transaction logging. Undated versioned manual.
[^9]: Maurice P. Herlihy and Jeannette M. Wing. [Linearizability: A Correctness Condition for Concurrent Objects](https://cs.brown.edu/~mph/HerlihyW90/p463-herlihy.pdf). ACM TOPLAS12(3), July1990, pp.463–492; definition §2.2, pp.468–469. Older foundational primary research.
[^10]: Kyle Kingsbury and Peter Alvaro. [Elle: Inferring Isolation Anomalies from Experimental Observations](https://arxiv.org/pdf/2003.10554). arXivv1, March23,2020; abstract, §4.3 and §9. [Version metadata](https://arxiv.org/abs/2003.10554). Older original research.
[^11]: Jingyu Zhou et al. [FoundationDB: A Distributed Unbundled Transactional Key Value Store](https://www.foundationdb.org/files/fdb-paper.pdf). SIGMOD2021, June20–25,2021; §4 Simulation Testing, PDFpp.8–9. Older original research.
[^12]: FoundationDB project. [Simulation and Testing](https://apple.github.io/foundationdb/testing.html), documentation7.4.7. Undated versioned baseline; describes separate simulation, live performance and hardware failure testing.
[^13]: PostgreSQL Global Development Group. [PostgreSQL18 §29.8 Restrictions](https://www.postgresql.org/docs/18/logical-replication-restrictions.html). Undated versioned manual.
[^14]: PostgreSQL Global Development Group. [PostgreSQL18 pg_upgrade](https://www.postgresql.org/docs/18/pgupgrade.html), link/clone mode and deployment testing. Undated versioned manual.
[^15]: PostgreSQL Global Development Group. [Release18.6](https://www.postgresql.org/docs/18/release-18-6.html). August13,2026; release note and “Invalidate role-dependent cached plans after role changes” entry. Within the preferred date window.
