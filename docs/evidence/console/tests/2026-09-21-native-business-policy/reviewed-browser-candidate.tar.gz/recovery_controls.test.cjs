'use strict';
// Synthetic oracle corruption controls; no business/browser fixture.
const test=require('node:test');const assert=require('node:assert/strict');
const {recoveryFormsSafe,snapshotRecoveryForms}=require('./recovery_controls.cjs');
const uuid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const expected=()=>({origin:'https://localhost:4443',company:uuid(1),command:uuid(2),operation:'grant',recovery:'accepted'});
const base=e=>`/companies/${e.company}/policy/payroll-read`;
const csrf=()=>({name:'csrf_proof',type:'hidden',disabled:false,proofPresent:true});
const form=e=>({action:`${base(e)}/requests/${e.operation}/${e.command}/retry`,method:'post',enctype:'application/x-www-form-urlencoded',override:false,autosubmit:false,imageSubmitters:0,submitButtons:1,submitNames:[''],submitDisabled:[false],submitLabel:'같은 요청 이어서 처리',controls:[csrf()]});
test('accepted pending and uncertain require sole exact csrf-only retry',()=>{
 for(const state of ['pending','uncertain']){const e=expected();assert.equal(recoveryFormsSafe([form(e)],state,e),true);assert.equal(recoveryFormsSafe([],state,e),false);}
});
test('wrong retry selectors, aliases, queries and origin rejected',()=>{
 const e=expected(),f=form(e);
 for(const action of [f.action.replace(uuid(1),uuid(9)),f.action.replace(uuid(2),uuid(9)),f.action.replace('/grant/','/revoke/'),f.action+'?a=1',f.action+'#a',f.action+'/',f.action.replace('retry','%72etry'),'https://evil.test'+f.action])assert.equal(recoveryFormsSafe([{...f,action}],'pending',e),false);
});
test('replacement fields, duplicate proof, editable controls and proof retention rejected',()=>{
 const e=expected();
 for(const name of ['command_id','company','recipient','expires_at_local','expected_company_epoch','operation','csrf_proof']){
  const f=form(e);f.controls.push({...csrf(),name});assert.equal(recoveryFormsSafe([f],'pending',e),false);
 }
 for(const change of [{type:'text'},{disabled:true},{proofPresent:false},{value:'must-not-retain-token'}]){
  const f=form(e);Object.assign(f.controls[0],change);assert.equal(recoveryFormsSafe([f],'pending',e),false);
 }
});
test('automatic or alternate mutation controls cannot pass retry oracle',()=>{
 const e=expected(),f=form(e);
 for(const [key,value] of [['method','get'],['enctype','multipart/form-data'],['override',true],['autosubmit',true],['submitButtons',2],['submitLabel','새 요청']])assert.equal(recoveryFormsSafe([{...f,[key]:value}],'pending',e),false);
 assert.equal(recoveryFormsSafe([f,f],'pending',e),false);
});
function held(operation){
 const e={...expected(),operation,recovery:'held',assignment:uuid(5),originalFields:{command_id:uuid(2),expected_company_epoch:'7'}};
 if(operation==='grant')Object.assign(e.originalFields,{recipient_account_id:uuid(3),expected_role_revision:'none',assignment_id:'none',expected_assignment_revision:'none',expires_at_local:'2026-09-25T09:00'});
 if(operation==='revoke')Object.assign(e.originalFields,{expected_role_revision:'1',expected_assignment_revision:'2'});
 const f=form(e);f.action=operation==='install'?base(e)+'/catalog':operation==='grant'?base(e)+'/grants':base(e)+'/grants/'+e.assignment+'/revoke';
 f.controls.push(...Object.entries(e.originalFields).map(([name,value])=>({name,value,type:'hidden',disabled:false})));
 return{e,f};
}
test('held replay retains exact typed fields at each original mutation endpoint',()=>{
 for(const operation of ['install','grant','revoke']){
  const{e,f}=held(operation);assert.equal(recoveryFormsSafe([f],'uncertain',e),true);
  for(let i=1;i<f.controls.length;i++){const corrupt=structuredClone(f);corrupt.controls[i].value+='changed';assert.equal(recoveryFormsSafe([corrupt],'uncertain',e),false);}
  assert.equal(recoveryFormsSafe([f],'pending',e),false);
 }
});
test('unknown and expired input has no executable form or invented pending claim',()=>{
 for(const state of ['uncertain','not-visible','expired']){
  const e={...expected(),recovery:'none'};assert.equal(recoveryFormsSafe([],state,e),true);assert.equal(recoveryFormsSafe([form(e)],state,e),false);
 }
 const e={...expected(),recovery:'none'};assert.equal(recoveryFormsSafe([],'pending',e),false);
 for(const state of ['not-visible','expired'])assert.equal(recoveryFormsSafe([form(expected())],state,expected()),false);
});
test('held witness must have closed operation-specific business field roster',()=>{
 const{e,f}=held('grant');
 for(const key of Object.keys(e.originalFields)){const bad=structuredClone(e);delete bad.originalFields[key];assert.equal(recoveryFormsSafe([f],'uncertain',bad),false);}
 const bad=structuredClone(e);bad.originalFields.csrf_proof='bad';assert.equal(recoveryFormsSafe([f],'uncertain',bad),false);
});

test('submitter cannot add named business fields or block explicit recovery',()=>{
 const e=expected(),f=form(e);
 for(const name of ['command_id','csrf_proof','expires_at_local','operation'])assert.equal(recoveryFormsSafe([{...f,submitNames:[name]}],'pending',e),false);
 assert.equal(recoveryFormsSafe([{...f,submitDisabled:[true]}],'pending',e),false);
 const missing={...f};delete missing.submitNames;assert.equal(recoveryFormsSafe([missing],'pending',e),false);
});

// Minimal DOM-shaped oracle inputs only, never business/browser fixtures.
function formWithExternalSubmitter(extra){
 const e=expected();
 const node=attrs=>({matches:selector=>selector===':disabled'&&Object.hasOwn(attrs,'effective-disabled'),attributes:Object.entries(attrs).map(([name,value])=>({name,value})),hasAttribute:name=>Object.hasOwn(attrs,name),getAttribute:name=>attrs[name]??null});
 const proof={...node({}),name:'csrf_proof',type:'hidden',disabled:false,value:'ephemeral-not-retained'};
 const submit={...node(extra),name:'',type:'submit',disabled:false,innerText:'같은 요청 이어서 처리'};
 const f={...node({action:form(e).action,method:'post'}),enctype:'application/x-www-form-urlencoded',elements:[proof,submit],querySelectorAll:()=>[proof],ownerDocument:{querySelectorAll:()=>[]}};
 return snapshotRecoveryForms([f]);
}
test('external form-associated submitter overrides and inline handlers are inspected',()=>{
 const e=expected();assert.equal(recoveryFormsSafe(formWithExternalSubmitter({}),'pending',e),true);
 for(const name of ['formaction','formmethod','formenctype','formtarget']){
  const forms=formWithExternalSubmitter({[name]:'foreign'});assert.equal(forms[0].override,true);assert.equal(recoveryFormsSafe(forms,'pending',e),false);
 }
 const forms=formWithExternalSubmitter({onclick:'submitOther()'});assert.equal(forms[0].autosubmit,true);assert.equal(recoveryFormsSafe(forms,'pending',e),false);
});

test('associated image submitter omitted by form.elements cannot add coordinate fields',()=>{
 const e=expected();const f={
  getAttribute:n=>({action:form(e).action,method:'post'})[n]??null,enctype:'application/x-www-form-urlencoded',attributes:[],hasAttribute:()=>false,
  elements:[{name:'csrf_proof',type:'hidden',value:'ephemeral',matches:()=>false,attributes:[],hasAttribute:()=>false},{name:'',type:'submit',innerText:'같은 요청 이어서 처리',matches:()=>false,attributes:[],hasAttribute:()=>false}],
  querySelectorAll:()=>[],ownerDocument:{querySelectorAll:()=>[]},
 };
 assert.equal(recoveryFormsSafe(snapshotRecoveryForms([f]),'pending',e),true);
 f.ownerDocument.querySelectorAll=()=>[{form:f,type:'image'}];
 const bad=snapshotRecoveryForms([f]);assert.equal(bad[0].imageSubmitters,1);assert.equal(recoveryFormsSafe(bad,'pending',e),false);
 f.ownerDocument.querySelectorAll=()=>[{form:{},type:'image'}];assert.equal(recoveryFormsSafe(snapshotRecoveryForms([f]),'pending',e),true);
});
test('disabled-fieldset ancestry is reflected even when control.disabled is false',()=>{
 const e=expected();const submitDisabled=formWithExternalSubmitter({'effective-disabled':''});
 assert.deepEqual(submitDisabled[0].submitDisabled,[true]);assert.equal(recoveryFormsSafe(submitDisabled,'pending',e),false);
 const f={getAttribute:n=>({action:form(e).action,method:'post'})[n]??null,enctype:'application/x-www-form-urlencoded',attributes:[],hasAttribute:()=>false,
  elements:[{name:'csrf_proof',type:'hidden',value:'ephemeral',disabled:false,matches:()=>true,attributes:[],hasAttribute:()=>false},{name:'',type:'submit',innerText:'같은 요청 이어서 처리',disabled:false,matches:()=>false,attributes:[],hasAttribute:()=>false}],
  querySelectorAll:()=>[],ownerDocument:{querySelectorAll:()=>[]}};
 const bad=snapshotRecoveryForms([f]);assert.equal(bad[0].controls[0].disabled,true);assert.equal(recoveryFormsSafe(bad,'pending',e),false);
});
