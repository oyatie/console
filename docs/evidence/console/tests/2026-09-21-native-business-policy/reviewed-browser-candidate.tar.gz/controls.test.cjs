'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const driver=require('./company.cjs');
const company='11111111-2222-3333-4444-555555555555';const command='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const uuid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
function policyPositive(){
 const e={company:uuid(1),recipient:uuid(2),operator:uuid(3),unexpected_mutations:0,mutation_failures:0,mutations:[],checkpoints:[],install_did_not_grant:true,grant_receipt_reopened:true,revoked_receipt_reopened:true,reflow_320:true,keyboard_submit:true};
 const ops=['InstallPayrollReadCatalogV1','GrantPayrollReadV1','RevokePayrollReadV1'];
 e.mutations=ops.map((operation,i)=>({operation,command_id:uuid(10+i),expected_company_epoch:String(i+1),method:'POST',status:303,same_origin:true,request_count:1,body_sha256:'a'.repeat(64)}));
 e.checkpoints=['CATALOG_INSTALLED','GRANT_COMMITTED','GRANT_REOPENED','REVOKE_COMMITTED','REVOKE_REOPENED'].map((phase,i)=>({phase,company:e.company,recipient:e.recipient,actor_account_id:e.operator,command_id:uuid(i===0?10:i>=3?12:11),receipt_id:uuid(i===0?20:i>=3?22:21),company_epoch:String(i===0?2:i>=3?4:3),owner_effects_verified:true,unrelated_bytes_preserved:true,original_discovery_preserved:true,...(i?{assignment_id:uuid(30),assignment_revision:i>=3?'2':'1',state:i>=3?'REVOKED':'ACTIVE'}:{})}));
 e.checkpoints[4].current_state='REVOKED';e.checkpoints[4].reload_had_no_effects=true;
 return e;
}

function valid(policy=false){
 const paths=['/api/v2/auth/registration/start','/api/v2/auth/registration/finish','/api/v2/companies/enroll'];
 const saved=`/account/companies/requests/${command}`;
 const docs=['/','/account/register','/account','/account','/account/companies/new',saved,saved,`/companies/${company}`,saved];
 const phases=['ENROLLED','COMPANY_COMMITTED','COMPANY_REOPENED'];
 if(policy){docs.push('/account',`/companies/${company}`,`/companies/${company}/policy/payroll-read/install`);phases.push('POLICY_ENTRY_READY','POLICY_PREFLIGHT');}
 const r={policy_entry:policy,command_id:command,org_id:company,document_failures:0,documents:docs.map((p,i)=>({ordinal:i+1,method:'GET',path:p,redirected:false,status:200,url_exact:true})),mutations:paths.map((p,i)=>({ordinal:i+1,method:'POST',path:p})),posts:Object.fromEntries(paths.map(p=>[p,1])),checkpoints:phases,browser_version:'153.0.8010.12',unexpected_mutations:0,root_status:200,external_requests:0,cleanup:{confirmed:true}};
 for(const key of ['administration_reopened','full_policy_journey','payroll_ssr','payroll_reopened','payroll_json','payroll_denied','payroll_json_denied','registration_wire','resident','cookie_security','literal_secret_absent','reflow_root_320','reflow_register_320','reflow_account_320','reflow_setup_320','reflow_result_320','reflow_company_320','keyboard_skip','keyboard_registration','keyboard_terms','keyboard_registration_submit','keyboard_company_entry','keyboard_company_submit','company_wire','company_result','company_reopen','company_workspace','company_back','invalid_input_preserved','recipient_consequence','business_input_not_stored','current_context','policy_entry_link','policy_preflight','reflow_policy_320','keyboard_policy_entry','keyboard_policy_submit'])r[key]=true;
 if(policy){
  r.policy=policyPositive();r.policy.company=company;
  for(const c of r.policy.checkpoints)c.company=company;
  const b=`/companies/${company}/policy/payroll-read`;
  r.policy_expected_mutations=[b+'/catalog',b+'/grants',b+'/grants/'+r.policy.checkpoints[1].assignment_id+'/revoke'];
  r.policy_documents=[];const add=(method,path,status,redirected=false)=>r.policy_documents.push({method,path,status,redirected});
  const receipt=(i,name)=>b+'/requests/'+name+'/'+r.policy.mutations[i].command_id;
  add('POST',r.policy_expected_mutations[0],303);add('GET',receipt(0,'install'),200,true);add('GET',b+'/grant',200);
  add('POST',r.policy_expected_mutations[1],303);add('GET',receipt(1,'grant'),200,true);add('GET',receipt(1,'grant'),200);
  add('GET',`/companies/${company}/payroll`,200);add('GET',`/companies/${company}/payroll`,200);add('GET',receipt(1,'grant'),200);add('GET',b+'/revoke',200);
  add('POST',r.policy_expected_mutations[2],303);add('GET',receipt(2,'revoke'),200,true);add('GET',receipt(2,'revoke'),200);
  add('GET',`/companies/${company}/payroll`,404);add('GET','/account',200);add('GET',`/companies/${company}`,200);
  for(const d of r.policy_documents)r.documents.push({ordinal:r.documents.length+1,...d,url_exact:true});
  for(const path of r.policy_expected_mutations){r.mutations.push({ordinal:r.mutations.length+1,method:'POST',path});r.posts[path]=1;}
  r.checkpoints.push('CATALOG_INSTALLED','GRANT_COMMITTED','GRANT_REOPENED','PAYROLL_READ','PAYROLL_REOPENED','PAYROLL_JSON','REVOKE_COMMITTED','REVOKE_REOPENED','PAYROLL_DENIED','PAYROLL_JSON_DENIED','ADMIN_REOPENED');
 }
 return r;
}
test('existing Company complete observations remain valid',()=>assert.equal(driver.leafStatus(valid()),'BROWSER_LEAF_PASSED'));
test('policy entry requires complete real route and owner checkpoint sequence',()=>{const r=valid(true);assert.equal(driver.leafStatus(r),'BROWSER_LEAF_PASSED');for(let i=0;i<r.documents.length;i++){const c=structuredClone(r);c.documents.splice(i,1);assert.equal(driver.completeObservations(c),false);}for(let i=0;i<r.checkpoints.length;i++){const c=structuredClone(r);c.checkpoints.splice(i,1);assert.equal(driver.completeObservations(c),false);}});
test('dead or redirected install destination cannot pass',()=>{for(const change of [{status:404},{status:501},{redirected:true},{url_exact:false},{path:`/companies/${company}/policy/payroll-read/grant`}]){const r=valid(true);Object.assign(r.documents.at(-1),change);assert.equal(driver.completeObservations(r),false);}});
test('missing current context or usable policy preflight observation fails',()=>{for(const key of ['current_context','policy_entry_link','policy_preflight','reflow_policy_320','keyboard_policy_entry','keyboard_policy_submit']){const r=valid(true);delete r[key];assert.equal(driver.completeObservations(r),false);}});
test('extra policy mutation or missing original mutation fails',()=>{let r=valid(true);r.mutations.push({ordinal:4,method:'POST',path:`/companies/${company}/policy/payroll-read/catalog`});assert.equal(driver.completeObservations(r),false);r=valid(true);r.mutations.pop();assert.equal(driver.completeObservations(r),false);});
test('all original result and teardown code stays present',()=>{const old=fs.readFileSync(path.join(__dirname,'company.cjs.before'),'utf8'),now=fs.readFileSync(path.join(__dirname,'company.cjs'),'utf8');for(const line of old.split('\n').filter(x=>x.includes('committedCompanyResult()')||x.includes('result.company_workspace=')||x.includes('result.company_back=')||x.startsWith('function completeMutations(')||x.startsWith('function leafStatus(')))assert.ok(now.includes(line.replace('function completeMutations(','function completeMutationsOriginal(')));const oldRust=fs.readFileSync(path.join(__dirname,'native_company_browser.rs.before'),'utf8'),newRust=fs.readFileSync(path.join(__dirname,'native_company_browser.rs'),'utf8');const marker='// Stable protected leaf name retained;';assert.ok(newRust.includes(oldRust.slice(oldRust.indexOf(marker))));});

test('install form permits structural fieldsets but keeps exact successful controls',()=>{
 const node=(tagName,type,name='',disabled=false)=>({tagName,type,name,matches:selector=>{assert.equal(selector,':disabled');return disabled;},hasAttribute:()=>false});
 const inputs=()=>['command_id','expected_company_epoch','csrf_proof'].map(name=>node('INPUT','hidden',name));
 const form=elements=>({elements,enctype:'application/x-www-form-urlencoded',target:'',ownerDocument:{querySelectorAll:selector=>{assert.equal(selector,'input[type="image" i]');return [];}}});
 const positive=[...inputs(),node('BUTTON','submit')];
 assert.equal(driver.installFormControlsSafe(form(positive)),true);
 assert.equal(driver.installFormControlsSafe(form([node('FIELDSET','fieldset'),...positive,node('FIELDSET','fieldset')])),true);
 assert.equal(driver.installFormControlsSafe(form([...inputs(),node('FIELDSET','fieldset'),node('BUTTON','submit','',true)])),false);
 for(const extra of [node('INPUT','hidden','extra'),node('SELECT','select-one','extra'),node('TEXTAREA','textarea','extra'),node('BUTTON','submit')])assert.equal(driver.installFormControlsSafe(form([...positive,extra])),false);
});

test('partial entry and prepared-only results cannot pass full policy leaf',()=>{const r=valid(true);r.full_policy_journey=false;assert.equal(driver.leafStatus(r),'BROWSER_LEAF_FAILED');for(const key of ['administration_reopened','policy','payroll_ssr','payroll_reopened','payroll_json','payroll_denied','payroll_json_denied']){const x=valid(true);delete x[key];assert.equal(driver.leafStatus(x),'BROWSER_LEAF_FAILED');}});
test('unexpected duplicate and missing policy submissions fail',()=>{for(let i=3;i<6;i++){const r=valid(true);r.mutations.splice(i,1);assert.equal(driver.completeMutations(r),false);}const r=valid(true);r.mutations.push({...r.mutations.at(-1),ordinal:7});assert.equal(driver.completeMutations(r),false);});
test('every protected original mutation still requires exact unchanged proof',()=>{const r=valid();for(let i=0;i<3;i++){const x=structuredClone(r);x.mutations[i].path='/unexpected';assert.equal(driver.completeMutations(x),false);}});
test('native POST redirect status and method are mandatory',()=>{const r=valid(true),i=r.documents.findIndex(d=>d.method==='POST');for(const changed of [{status:200},{method:'GET'},{redirected:true}]){const x=structuredClone(r);Object.assign(x.documents[i],changed);assert.equal(driver.completeDocuments(x),false);}const x=structuredClone(r);x.documents[i+1].redirected=false;assert.equal(driver.completeDocuments(x),false);});

test('planned route evidence cannot omit a read or use a different Company',()=>{const r=valid(true);assert.equal(driver.completePolicyPlan(r),true);for(let i=0;i<r.policy_documents.length;i++){const x=structuredClone(r);x.policy_documents.splice(i,1);assert.equal(driver.completePolicyPlan(x),false);}const x=structuredClone(r);x.policy_expected_mutations[2]=x.policy_expected_mutations[1];assert.equal(driver.completePolicyPlan(x),false);});
