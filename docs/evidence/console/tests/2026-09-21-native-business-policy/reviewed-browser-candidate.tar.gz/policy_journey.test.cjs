'use strict';
// Evidence-validator controls only. Synthetic observations below are never
// registered as product state or passed to a browser/DB acceptance fixture.
const test=require('node:test');const assert=require('node:assert/strict');
const {validEvidence,exactRecoveryHref,deniedMaterialSafe}=require('./policy_journey.cjs');
const uuid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
function positive(){
 const e={company:uuid(1),recipient:uuid(2),operator:uuid(3),unexpected_mutations:0,mutation_failures:0,mutations:[],checkpoints:[],install_did_not_grant:true,grant_receipt_reopened:true,revoked_receipt_reopened:true,reflow_320:true,keyboard_submit:true};
 const ops=['InstallPayrollReadCatalogV1','GrantPayrollReadV1','RevokePayrollReadV1'];
 e.mutations=ops.map((operation,i)=>({operation,command_id:uuid(10+i),expected_company_epoch:String(i+1),method:'POST',status:303,same_origin:true,request_count:1,body_sha256:'a'.repeat(64)}));
 e.checkpoints=['CATALOG_INSTALLED','GRANT_COMMITTED','GRANT_REOPENED','REVOKE_COMMITTED','REVOKE_REOPENED'].map((phase,i)=>({phase,company:e.company,recipient:e.recipient,actor_account_id:e.operator,command_id:uuid(i===0?10:i>=3?12:11),receipt_id:uuid(i===0?20:i>=3?22:21),company_epoch:String(i===0?2:i>=3?4:3),owner_effects_verified:true,unrelated_bytes_preserved:true,original_discovery_preserved:true,...(i?{assignment_id:uuid(30),assignment_revision:i>=3?'2':'1',state:i>=3?'REVOKED':'ACTIVE'}:{})}));
 e.checkpoints[4].current_state='REVOKED';e.checkpoints[4].reload_had_no_effects=true;
 return e;
}
test('positive complete observation accepted',()=>assert.equal(validEvidence(positive()),true));
test('every missing request and checkpoint rejected',()=>{
 for(let i=0;i<3;i++){const e=positive();e.mutations.splice(i,1);assert.equal(validEvidence(e),false);}
 for(let i=0;i<5;i++){const e=positive();e.checkpoints.splice(i,1);assert.equal(validEvidence(e),false);}
});
test('unproven effects and changed discovery/unrelated history rejected',()=>{
 for(let i=0;i<5;i++)for(const k of ['owner_effects_verified','unrelated_bytes_preserved','original_discovery_preserved']){
  const e=positive();e.checkpoints[i][k]=false;assert.equal(validEvidence(e),false);
 }
});
test('stale artifact identity and receipt replacement rejected',()=>{
 for(let i=0;i<5;i++)for(const k of ['company','recipient','command_id','actor_account_id']){
  const e=positive();e.checkpoints[i][k]=uuid(99);assert.equal(validEvidence(e),false);
 }
 const e=positive();e.checkpoints[2].receipt_id=uuid(99);assert.equal(validEvidence(e),false);
});
test('duplicate and extra mutation or failed transport rejected',()=>{
 for(const k of ['unexpected_mutations','mutation_failures']){const e=positive();e[k]=1;assert.equal(validEvidence(e),false);}
 const e=positive();e.mutations.push({...e.mutations[0]});assert.equal(validEvidence(e),false);
 for(const [k,v]of [['status',500],['request_count',2],['same_origin',false],['method','GET'],['body_sha256','stale']]){
  const e=positive();e.mutations[1][k]=v;assert.equal(validEvidence(e),false);
 }
});
test('discontinuous revision and false active state rejected',()=>{
 for(let i=0;i<5;i++){const e=positive();e.checkpoints[i].company_epoch='99';assert.equal(validEvidence(e),false);}
 const e=positive();e.checkpoints[3].state='ACTIVE';assert.equal(validEvidence(e),false);
 for(const i of [1,2,3,4]){const e=positive();e.checkpoints[i].assignment_revision='99';assert.equal(validEvidence(e),false);}
});
test('unproven no-grant, reopen and accessible interaction rejected',()=>{
 for(const k of ['install_did_not_grant','grant_receipt_reopened','revoked_receipt_reopened','reflow_320','keyboard_submit']){
  const e=positive();e[k]=false;assert.equal(validEvidence(e),false);
 }
});

test('exact original Company, operation and command recovery only',()=>{
 const expected={origin:'https://localhost:4443',company:uuid(1),operation:'grant',command:uuid(10)};
 const path=`/companies/${expected.company}/policy/payroll-read/requests/grant/${expected.command}`;
 assert.equal(exactRecoveryHref(path,expected),true);
 for(const href of [path.replace(uuid(1),uuid(99)),path.replace(uuid(10),uuid(99)),path.replace('/grant/','/revoke/'),path+'?x=1',path+'#other',path+'/',path.replace('/grant/','/Grant/'),'https://evil.test'+path,'//evil.test'+path,path.replace('requests','%72equests')]) assert.equal(exactRecoveryHref(href,expected),false);
});
test('revoked reopen must retain receipt and freshly proven no-effect state',()=>{
 for(const [key,value] of [['receipt_id',uuid(99)],['current_state','ACTIVE'],['reload_had_no_effects',false],['assignment_id',uuid(99)],['company_epoch','99']]){
  const e=positive();e.checkpoints[4][key]=value;assert.equal(validEvidence(e),false);
 }
 const missing=positive();missing.checkpoints.pop();assert.equal(validEvidence(missing),false);
});
const forbidden={company:[uuid(1),'권한 없는 회사'],recipient:[uuid(2)],operator:[uuid(3)],receipt:[uuid(20)],epoch:['17']};
function safeMaterial(){return{responseText:'<h1>접근할 수 없습니다</h1>',domHtml:'<h1>접근할 수 없습니다</h1>',visibleText:'접근할 수 없습니다',scriptText:'',attributeValues:[]};}
test('complete source forbidden roster required, not empty marker proof',()=>{
 assert.equal(deniedMaterialSafe(safeMaterial(),forbidden),true);
 for(const key of Object.keys(forbidden)){
  const omitted=structuredClone(forbidden);delete omitted[key];assert.equal(deniedMaterialSafe(safeMaterial(),omitted),false);
  const empty=structuredClone(forbidden);empty[key]=[];assert.equal(deniedMaterialSafe(safeMaterial(),empty),false);
 }
 assert.equal(deniedMaterialSafe(safeMaterial(),{}),false);
});
test('plain response, DOM, hidden inputs and serialized disclosure rejected',()=>{
 for(const key of ['company','recipient','operator','receipt'])for(const value of forbidden[key]){
  for(const where of ['responseText','domHtml','visibleText','scriptText']){
   const m=safeMaterial();m[where]=`<script>{"secret":"${value}"}</script>`;assert.equal(deniedMaterialSafe(m,forbidden),false);
  }
  const hidden=safeMaterial();hidden.attributeValues=[value];assert.equal(deniedMaterialSafe(hidden,forbidden),false);
 }
 for(const [where,value] of [['visibleText','권한 버전 17'],['responseText','{"company_epoch":"17"}'],['scriptText','state={epoch:17}'],['domHtml','<input type="hidden" value="17">']]){
  const m=safeMaterial();m[where]=value;if(where==='domHtml')m.attributeValues=['hidden','17'];assert.equal(deniedMaterialSafe(m,forbidden),false);
 }
 const escaped=safeMaterial();escaped.scriptText='{"recipient":"'+uuid(2).replace('0','\\u0030')+'"}';assert.equal(deniedMaterialSafe(escaped,forbidden),false);
});
