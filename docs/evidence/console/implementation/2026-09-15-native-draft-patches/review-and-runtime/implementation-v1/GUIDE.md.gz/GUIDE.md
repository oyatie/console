# Pure draft owner V1 mechanical guide

Owner: /root/fast_gate_review private candidate; /root sole integration writer and runtime operator.
Exact source/test base: 0b8ec4c1b4c767cf607001b811a61bf799a6cf58.
Root currently eef737cf0739784795a718e99e5d72bc85999c3f; admitted preimages unchanged.

Only the six source paths in manifest.json are part of this candidate. Compare each existing source to its exact preimage SHA; require each new source path absent. Require approved V3 tests and probe hashes unchanged. Run git apply --check against implementation.patch, then root alone mechanically integrates exact postimages or applies the patch. Do not edit tests, schema JSON, dependencies, lockfile, BUCK, DB, generated files, OpenAPI, CI or authority records.

Implementation uses fixed normalized owner28 schema resources and the existing bounded duplicate-key/NUL/nonnumeric JSON parser. It introduces an internal draft snapshot/value/address API, a fixed-schema structural index, and ordered atomic edits that preserve schema/basis/hidden cells/provenance. Scope is plain caller data, not an authenticated capability. Required-at-submit minima and unbound required siblings may remain unfinished; declared values and structural maxima are checked. All7 patch operations are supported, including same-address ordered operations. Existing owner submission/apply_edits behavior is preserved.

Pre-mortem: partial view replaces full state; duplicate schema rules drift; parent REMOVE erases protected children; MOVE loses source provenance; raw content reaches diagnostics; excessive typed input clones before rejection; compile success is mistaken for runtime evidence.
Blast radius: pure application source plus narrow owner28 parser/canonical/schema reuse. No DB, capability construction, current-authority/ref resolution, persistence contract, public API, generated UUIDs, clock or external effects.
Detection: independent source review and unchanged exact12 probe, then root-owned existing application compatibility and lint/format gates.
Rollback: root-owned source correction; retain previous candidate and runtime evidence; no destructive shared Git operations.
Stop: mismatched hashes/preimages; tests or runtime probe changed; unapproved broader source changes; blocked infrastructure mistaken for semantic RED; public/persistent authority expansion.
Review identities: author /root/fast_gate_review; independent /root/inventory_repair; integrator/runtime /root.

Exact runtime probe (root only): python3 /private/tmp/native-draft12-probe.py
Underlying command: RUSTUP_TOOLCHAIN=1.98.1 cargo test --locked --manifest-path backend/Cargo.toml -p console-ontology-application --lib draft_patch_snapshot_tests:: -- --test-threads=1
Expected approved tests:12. Candidate runtime tests executed:0. Cargo not run by author. Compiler/runtime outcomes remain HOLD until root returns actual evidence.

Static checks: rustfmt +1.98.1 --edition 2024 --config skip_children=true on five authored/modified modules; exit0. Final rustfmt --check will include all six explicit source files with skip_children=true. git apply --check is read-only and must pass before root integration.

Known boundaries: 65536-byte patch array bound includes array punctuation. Snapshot65,536 ordinary /8,388,608 payroll-release accounting is a conservative in-memory work/allocation limit, not certification of a canonical persistent snapshot size. Current-authority/ref validation, durable save/CAS/history/SSR workflow, production/payment/legal authority all remain HOLD.
