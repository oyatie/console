import os, pathlib, subprocess, json, sys, hashlib, tempfile
root=pathlib.Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if subprocess.check_output(['git','status','--porcelain']):sys.exit(126)
run=pathlib.Path(tempfile.mkdtemp(prefix='native-draft-hardening-',dir='/private/tmp'))
paths=subprocess.check_output(['git','ls-files','-z','--','backend/crates/ontology/application','backend/Cargo.toml','backend/Cargo.lock'],text=True).rstrip('\0').split('\0')
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
overrides={'RUSTUP_TOOLCHAIN':'1.98.1','CARGO_TARGET_DIR':'/private/tmp/console-account30-cargo','SQLX_OFFLINE':'true'}
checks=[('application',['cargo','test','--locked','--offline','--manifest-path','backend/Cargo.toml','-p','console-ontology-application','--lib','--','--test-threads=1']),('clippy',['cargo','clippy','--locked','--offline','--manifest-path','backend/Cargo.toml','-p','console-ontology-application','--all-targets','--','-D','warnings'])]
results=[]
for name,argv in checks:
    log=run/(name+'.log')
    with log.open('wb') as f:code=subprocess.run(argv,env=dict(os.environ,**overrides),stdout=f,stderr=subprocess.STDOUT).returncode
    results.append({'name':name,'argv':argv,'exit_code':code,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
after=snapshot()
unchanged=before==after and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'])
(run/'receipt.json').write_text(json.dumps({'head':head,'cwd':str(root),'environment':overrides,'checks':results,'unchanged':unchanged,'source_before':before,'source_after':after},indent=2)+'\n')
print(run)
sys.exit(126 if not unchanged else (1 if any(r['exit_code'] for r in results) else 0))
