#!/usr/bin/env python3
"""Private synthetic parser/receipt controls and fake-Docker wrapper controls only."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import types
import uuid

sys.dont_write_bytecode = True
candidate = pathlib.Path(__file__).resolve().parent
evidence = pathlib.Path(tempfile.mkdtemp(prefix="account-credential-custody4-controls-", dir="/private/tmp"))
spec = importlib.util.spec_from_file_location("reviewed_probe", candidate / "probe.py")
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
names = sorted(probe.EXPECTED)
results = []
sha = lambda path: hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def log(failures=0):
    rows = ["cargo-postgres: === app-auth-rest-pg ===", f"cargo-postgres: {probe.COMMAND}", "running 4 tests"]
    rows += [f"test {name} ... " + ("FAILED" if i < failures else "ok") for i, name in enumerate(names)]
    if failures:
        rows += ['failures:', '']
        for name in names[:failures]:
            boundary = probe.FAILURE_BOUNDARIES['cases'][name]
            rows += [f'---- {name} stdout ----', '', f"thread '{name}' (12345) panicked at {boundary['panic_path']}:{boundary['line']}:{boundary['column']}:", boundary['diagnostic'], '']
        rows += ['failures:', *['    ' + name for name in names[:failures]], '']
    rows += [
        "test result: " + ("FAILED" if failures else "ok") + f". {4-failures} passed; {failures} failed; 0 ignored; 0 measured; 212 filtered out; finished in 1.00s",
        "cargo-postgres-timing: " + json.dumps(dict(name="app-auth-rest-pg", package="console-app", status="fail" if failures else "pass", seconds=1.0, shard="")),
        "  " + ("FAIL" if failures else "PASS") + "  app-auth-rest-pg",
        f"cargo-postgres: {0 if failures else 1} passed, {1 if failures else 0} failed",
    ]
    return "\n".join(rows) + "\n"


green, red = log(), log(4)
parser_cases = {
    "green": (green, 0, True), "red": (red, 1, True), "partial_red": (log(1), 1, True),
    "green_red_exit": (green, 1, False), "red_green_exit": (red, 0, False), "empty": ("", 0, False),
    "missing_case": (green.replace(f"test {names[0]} ... ok\n", ""), 0, False),
    "duplicate_case": (green + f"test {names[0]} ... ok\n", 0, False),
    "foreign_case": (green.replace(names[0], "foreign_case"), 0, False),
    "ignored": (green.replace(f"test {names[0]} ... ok", f"test {names[0]} ... ignored"), 0, False),
    "wrong_discovery": (green.replace("running 4 tests", "running 2 tests"), 0, False),
    "negative_filter": (green.replace("212 filtered", "-1 filtered"), 0, False),
    "additional_filtered_inventory": (green.replace("212 filtered", "213 filtered"), 0, False),
    "lower_filtered_inventory": (green.replace("212 filtered", "211 filtered"), 0, False),
    "malformed_filter": (green.replace("212 filtered", "UNKNOWN filtered"), 0, False),
    "unexpected_unfiltered_suite": (green.replace("212 filtered", "0 filtered"), 0, False),
    "wrong_measured": (green.replace("0 measured", "1 measured"), 0, False),
    "duplicate_replaces_missing": (green.replace(names[0], names[1]), 0, False),
    "selector_argv": (green.replace("--exact", "--skip"), 0, False),
    "old_full206_discovery": (green.replace("running 4 tests", "running 206 tests"), 0, False),
    "wrong_argv": (green.replace("--test-threads=1", "--test-threads=2"), 0, False),
    "duplicate_invocation": (green + "cargo-postgres: === app-auth-rest-pg ===\n", 0, False),
    "duplicate_argv": (green + f"cargo-postgres: {probe.COMMAND}\n", 0, False),
    "foreign_invocation": (green + "cargo-postgres: === another-target ===\n", 0, False),
    "wrong_summary_count": (green.replace("4 passed;", "2 passed;"), 0, False),
    "wrong_timing_status": (green.replace('"status": "pass"', '"status": "fail"'), 0, False),
    "wrong_rollup": (green.replace("cargo-postgres: 1 passed, 0 failed", "cargo-postgres: 2 passed, 0 failed"), 0, False),
    "wrong_final_roster": (green.replace("  PASS  app-auth-rest-pg", "  PASS  another-target"), 0, False),
    "duplicate_summary": (green + "test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 212 filtered out;\n", 0, False),
    "extra_singular_discovery": (green + "running 1 test\n", 0, False),
    "bare_discovery": (green + "running\n", 0, False),
    "malformed_discovery": (green + "running unknown tests\n", 0, False),
    "unknown_case_status": (green + "test foreign_case ... UNKNOWN\n", 0, False),
    "malformed_extra_summary": (green + "test result: UNKNOWN\n", 0, False),
    "bare_test_record": (green + "test\n", 0, False),
    "tab_test_record": (green + "test\tforeign_case ... ok\n", 0, False),
    "ansi_color": (green.replace("running 4 tests", "\x1b[32mrunning 4 tests\x1b[0m"), 0, True),
}
first_boundary = probe.FAILURE_BOUNDARIES['cases'][names[0]]
parser_cases.update({
    'compile_failure': ('error[E0432]: unresolved import\nerror: could not compile console-app\n', 1, False),
    'missing_failure_detail': (red.replace(f'---- {names[0]} stdout ----', '---- foreign_case stdout ----'), 1, False),
    'unexpected_failure_detail_green': (green + f'---- {names[0]} stdout ----\n', 0, False),
    'fixture_unwrap_failure': (red.replace(first_boundary['diagnostic'], 'called `Result::unwrap()` on an `Err` value: fixture preparation failed', 1), 1, False),
    'fixture_sql_failure': (red.replace(first_boundary['diagnostic'], 'database fixture failed: permission denied for relation accounts', 1), 1, False),
    'wrong_panic_line': (red.replace(f":{first_boundary['line']}:{first_boundary['column']}:", f":{first_boundary['line'] + 1}:{first_boundary['column']}:", 1), 1, False),
    'wrong_panic_column': (red.replace(f":{first_boundary['line']}:{first_boundary['column']}:", f":{first_boundary['line']}:{first_boundary['column'] + 1}:", 1), 1, False),
    'wrong_panic_path': (red.replace(first_boundary['panic_path'], 'app/tests/foreign_fixture.rs', 1), 1, False),
    'wrong_panic_thread': (red.replace(f"thread '{names[0]}'", "thread 'tokio-runtime-worker'", 1), 1, False),
    'extra_nested_panic': (red + "thread 'fixture' (1) panicked at fixture.rs:1:1:\nextra\n", 1, False),
})
owner_name = next(name for name in names if 'owners_and_effective' in name)
owner_boundary = probe.FAILURE_BOUNDARIES['cases'][owner_name]
handoff_name = next(name for name in names if 'handoff_target' in name)
handoff_boundary = probe.FAILURE_BOUNDARIES['cases'][handoff_name]
owner_diag = owner_boundary['diagnostic']
handoff_diag = handoff_boundary['diagnostic']
owner_prefix = 'custody must have distinct NOLOGIN owners: '
owner_rows = __import__('re').findall(r'\("[a-z_]+", "[a-z_]+", (?:true|false)\)', owner_diag)
parser_cases.update({
    'owner_roster_order': (red.replace(owner_diag, owner_prefix + '[' + ', '.join(reversed(owner_rows)) + ']'), 1, True),
    'owner_roster_missing': (red.replace(owner_diag, owner_prefix + '[' + ', '.join(owner_rows[:-1]) + ']'), 1, False),
    'owner_roster_duplicate': (red.replace(owner_diag, owner_prefix + '[' + ', '.join(owner_rows[:-1] + [owner_rows[0]]) + ']'), 1, False),
    'owner_roster_foreign_role': (red.replace(owner_diag, owner_diag.replace('console_app', 'foreign_owner')), 1, False),
    'owner_roster_changed_login': (red.replace(owner_diag, owner_diag.replace('true', 'false')), 1, False),
    'handoff_dynamic_row_detail': (red.replace(handoff_diag, __import__('re').sub(r'detail: Some\("Failing row contains \([^"\n]*\)\."\)', 'detail: Some("Failing row contains (different private values).")', handoff_diag)), 1, True),
    'handoff_wrong_sqlstate': (red.replace(handoff_diag, handoff_diag.replace('23514', '42501')), 1, False),
    'handoff_wrong_constraint': (red.replace(handoff_diag, handoff_diag.replace('auth_device_login_handoffs_check1', 'different_check')), 1, False),
    'handoff_wrong_table': (red.replace(handoff_diag, handoff_diag.replace('auth_device_login_handoffs', 'foreign_table')), 1, False),
    'handoff_missing_row_detail': (red.replace(handoff_diag, handoff_diag.replace('detail: Some(', 'detail: None, unexpected: Some(')), 1, False),
    'missing_exact_flag': (green.replace(' --exact ', ' '), 0, False),
    'unexpected_second_filter': (green.replace(' --exact ', ' --exact account_storage::foreign '), 0, False),
})

for name, (text, code, expected) in parser_cases.items():
    try:
        observed = probe.validate(text, code)
        accepted = True
        assert observed["executed"] == 4 and observed["filtered"] == 212 and observed["ignored"] == 0
    except (AssertionError, ValueError, KeyError, TypeError):
        accepted = False
    results.append(dict(group="parser", name=name, passed=accepted == expected, accepted=accepted))

# Import only a private copy to verify the hard-coded expected-roster hash.
# Never execute probe.main, git, the driver, Cargo, Docker, or a database here.
for name, changed in [('exact_roster', False), ('changed_roster', True)]:
    case = evidence / name
    case.mkdir()
    (case / 'probe.py').write_bytes((candidate / 'probe.py').read_bytes())
    roster = (candidate / 'expected-cases.json').read_bytes()
    (case / 'expected-cases.json').write_bytes(roster + (b' ' if changed else b''))
    (case / 'failure-boundaries.json').write_bytes((candidate / 'failure-boundaries.json').read_bytes())
    done = subprocess.run([sys.executable, '-B', '-c', "import runpy,sys; runpy.run_path(sys.argv[1], run_name='synthetic_import_control')", str(case / 'probe.py')], capture_output=True, text=True)
    passed = done.returncode == 0 if not changed else done.returncode == 126 and 'unreviewed expected roster' in done.stderr
    results.append(dict(group='roster_import', name=name, passed=passed, exit=done.returncode))

for name, changed in [('exact_boundaries', False), ('changed_boundaries', True)]:
    case = evidence / name
    case.mkdir()
    for filename in ['probe.py', 'expected-cases.json']:
        (case / filename).write_bytes((candidate / filename).read_bytes())
    boundary_bytes = (candidate / 'failure-boundaries.json').read_bytes()
    (case / 'failure-boundaries.json').write_bytes(boundary_bytes + (b' ' if changed else b''))
    done = subprocess.run([sys.executable, '-B', '-c', "import runpy,sys; runpy.run_path(sys.argv[1], run_name='synthetic_import_control')", str(case / 'probe.py')], capture_output=True, text=True)
    passed = done.returncode == 0 if not changed else done.returncode == 126 and 'unreviewed semantic failure boundaries' in done.stderr
    results.append(dict(group='boundary_import', name=name, passed=passed, exit=done.returncode))

# These import-only subprocesses cannot call main or the real driver.
for name, filename, replacement in [
    ('missing_roster', 'expected-cases.json', None),
    ('malformed_roster', 'expected-cases.json', b'{invalid'),
    ('missing_boundaries', 'failure-boundaries.json', None),
    ('malformed_boundaries', 'failure-boundaries.json', b'{invalid'),
]:
    case = evidence / name
    case.mkdir()
    for item in ['probe.py', 'expected-cases.json', 'failure-boundaries.json']:
        if item != filename:
            (case / item).write_bytes((candidate / item).read_bytes())
        elif replacement is not None:
            (case / item).write_bytes(replacement)
    done = subprocess.run([sys.executable, '-B', '-c', "import runpy,sys; runpy.run_path(sys.argv[1], run_name='synthetic_import_control')", str(case / 'probe.py')], capture_output=True, text=True)
    results.append(dict(group='pinned_input_prerequisites', name=name, passed=done.returncode == 126 and 'prerequisite failure:' in done.stderr, exit=done.returncode))

# Read-only hashing of the exact private candidate bytes; drift lives only in a
# new synthetic directory. This checks the pre-driver oracle gate itself.
source_root = pathlib.Path(probe.FAILURE_BOUNDARIES['test_candidate']) / 'post'
for name in ['exact_test_sources', 'changed_test_source', 'missing_test_source']:
    root = source_root
    if name != 'exact_test_sources':
        root = evidence / name
        root.mkdir()
        for path in probe.FAILURE_BOUNDARIES['test_source_sha256']:
            target = root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((source_root / path).read_bytes())
        first = root / next(iter(probe.FAILURE_BOUNDARIES['test_source_sha256']))
        if name == 'changed_test_source':
            first.write_bytes(first.read_bytes() + b' ')
        else:
            first.unlink()
    try:
        probe.verify_test_sources(root)
        accepted = True
    except (AssertionError, OSError):
        accepted = False
    results.append(dict(group='pre_driver_test_sources', name=name, passed=accepted == (name == 'exact_test_sources'), accepted=accepted))

done = subprocess.run([sys.executable, '-O', '-B', '-c', "import runpy,sys; runpy.run_path(sys.argv[1], run_name='synthetic_import_control')", str(candidate / 'probe.py')], capture_output=True, text=True)
results.append(dict(group='python_mode', name='optimized_python_refuses', passed=done.returncode == 126 and 'optimized Python disables required guards' in done.stderr, exit=done.returncode))

# Only extracted functions run, against a fake executable at the front of PATH.
# No real Docker command, Cargo command, database, or source mutation occurs.
source = (candidate / "driver.sh").read_text()
bounded = source[source.index("docker_bounded() {"):source.index("cargo() {")]
wrapper = source[source.index("docker() {"):source.index("\nexport -f cargo docker")]
fake_bin = evidence / "fake-bin"
fake_bin.mkdir()
fake = fake_bin / "docker"
fake.write_text('''#!/usr/bin/env python3
import json,os,pathlib,sys
with pathlib.Path(os.environ['CONTROL_DOCKER_LOG']).open('a') as f: f.write(json.dumps(sys.argv[1:])+'\\n')
kind=sys.argv[1]
if kind=='inspect': print(os.environ['CONTROL_LABEL'])
raise SystemExit(int(os.environ.get('CONTROL_'+kind.upper()+'_EXIT','0')))
''')
fake.chmod(0o700)
container = "console-cargo-postgres-review-fixture"
docker_cases = [
    ("owned_success", True, container, "-f", "reviewed-run-owner", 0, 0, 0, 0, True),
    ("foreign_collision", True, container, "-f", "foreign-owner", 125, 0, 0, 2, False),
    ("missing_record", False, container, "-f", "reviewed-run-owner", 0, 0, 0, 2, False),
    ("wrong_name", True, "console-cargo-postgres-foreign", "-f", "reviewed-run-owner", 0, 0, 0, 2, False),
    ("unexpected_rm_flag", True, container, "--force", "reviewed-run-owner", 0, 0, 0, 2, False),
    ("inspect_failure", True, container, "-f", "reviewed-run-owner", 0, 1, 0, 2, False),
    ("inspect_timeout_status", True, container, "-f", "reviewed-run-owner", 0, 124, 0, 2, False),
    ("empty_label", True, container, "-f", "", 0, 0, 0, 2, False),
    ("owned_removal_failure", True, container, "-f", "reviewed-run-owner", 0, 0, 1, 1, True),
]
for name, launch, target, flag, label, run_exit, inspect_exit, rm_exit, expected_exit, expect_rm in docker_cases:
    case = evidence / name
    case.mkdir()
    script = bounded + wrapper + "\n"
    if launch:
        script += f'docker run --name {container} "$FENCE_IMAGE"\n'
    script += f"docker rm {flag} {target}\n"
    path = case / "control.sh"
    path.write_text(script)
    env = dict(os.environ, PATH=str(fake_bin) + ":" + os.environ["PATH"], FENCE_IMAGE="postgres:review-fixture", FENCE_LABEL="reviewed-run-owner", FENCE_CONTAINER_RECORD=str(case / "container-name.txt"), CONTROL_DOCKER_LOG=str(case / "docker.jsonl"), CONTROL_LABEL=label, CONTROL_RUN_EXIT=str(run_exit), CONTROL_INSPECT_EXIT=str(inspect_exit), CONTROL_RM_EXIT=str(rm_exit))
    done = subprocess.run(["bash", str(path)], env=env, capture_output=True, text=True)
    calls_path = case / "docker.jsonl"
    calls = [json.loads(line) for line in calls_path.read_text().splitlines()] if calls_path.exists() else []
    removals = [call for call in calls if call[0] == "rm"]
    passed = done.returncode == expected_exit and bool(removals) == expect_rm and all(call == ["rm", "-f", container] for call in removals)
    results.append(dict(group="fake_docker", name=name, passed=passed, exit=done.returncode, calls=calls))

# Exercise main's evidence classification with a synthetic driver result. Never
# invoke its real driver, git command, or runtime. Every mock artifact is retained.
real_subprocess, real_uuid, real_file, real_verify = probe.subprocess, probe.uuid, probe.__file__, probe.verify_test_sources
probe.verify_test_sources = lambda root: None
classification_cases = [
    ("complete_green", 0, 0), ("complete_red", 1, 1), ("prerequisite_exit", 2, 126), ("compile_exit", 101, 126), ("frozen_test_drift", 0, 126), ("fixture_failure", 1, 126), ("git_failure", 0, 126), ("missing_git", 0, 126), ("driver_spawn_error", 0, 126), ("missing_private_driver", 0, 126), ("driver_prerequisite126", 126, 126),
    ("missing_cases", 0, 126), ("dirty_snapshot", 0, 126), ("changed_snapshot", 0, 126),
    ("wrong_driver_hash", 0, 126), ("duplicate_prebuild", 0, 126),
    ("container_remains", 0, 126), ("cleanup_error", 0, 126), ("changed_artifact", 0, 126),
    ("omitted_receipt_artifact", 0, 126), ("missing_historical_fixture", 0, 126),
]
for name, driver_exit, expected in classification_cases:
    run_id = "synthetic-control-" + uuid.uuid4().hex
    probe.uuid = types.SimpleNamespace(uuid4=lambda value=run_id: types.SimpleNamespace(hex=value))
    def fake_run(argv, name=name, driver_exit=driver_exit):
        if name == "driver_spawn_error":
            raise FileNotFoundError("synthetic missing Bash/driver transport")
        run = pathlib.Path(argv[-1])
        run.mkdir()
        before = dict(head="f" * 40, status_porcelain=" M fixture" if name == "dirty_snapshot" else "", files={path: "0" * 64 for path in probe.HISTORICAL_FIXTURES})
        before['files'].update(probe.FAILURE_BOUNDARIES['test_source_sha256'])
        if name == 'frozen_test_drift':
            before['files'][next(iter(probe.FAILURE_BOUNDARIES['test_source_sha256']))] = 'unreviewed'
        if name == "missing_historical_fixture":
            before["files"].pop(sorted(probe.HISTORICAL_FIXTURES)[0])
        after = dict(before, files={"changed": "value"}) if name == "changed_snapshot" else before
        data = {filename: "synthetic fixture" for filename in probe.REQUIRED_ARTIFACTS}
        data.update({
            "source-before.json": json.dumps(before), "source-after.json": json.dumps(after),
            "cleanup.txt": "confirmed owned container absent via successful bounded docker ps -a",
            "container-name.txt": container, "containers-after.txt": container if name == "container_remains" else "",
            "cleanup-final-list-error.txt": "failure" if name == "cleanup_error" else "",
            "probe.log": "" if name == "missing_cases" else (red if driver_exit == 1 else green),
        })
        if name == 'fixture_failure':
            data['probe.log'] = red.replace(first_boundary['diagnostic'], 'called `Result::unwrap()` on an `Err` value: fixture preparation failed', 1)
        for filename, text in data.items():
            (run / filename).write_text(text)
        receipt = dict(driver_sha256="wrong" if name == "wrong_driver_hash" else sha(candidate / "driver.sh"), probe_exit=driver_exit, prebuild_interception_count=2 if name == "duplicate_prebuild" else 1, artifacts={filename: sha(run / filename) for filename in data})
        if name == "omitted_receipt_artifact":
            receipt["artifacts"].pop("probe.log")
        (run / "driver-receipt.json").write_text(json.dumps(receipt))
        if name == "changed_artifact":
            (run / "probe.log").write_text("changed")
        return types.SimpleNamespace(returncode=driver_exit)
    def fake_check_output(*args, **kwargs):
        if name == 'git_failure':
            raise probe.CalledProcessError(128, ['git', 'rev-parse', 'HEAD'], stderr='synthetic repository failure')
        if name == 'missing_git':
            raise FileNotFoundError('synthetic Git unavailable')
        return 'f' * 40
    if name == 'missing_private_driver':
        missing_private = evidence / 'missing-private-driver'
        missing_private.mkdir()
        probe.__file__ = str(missing_private / 'probe.py')
    else:
        probe.__file__ = real_file
    probe.subprocess = types.SimpleNamespace(check_output=fake_check_output, run=fake_run)
    with contextlib.redirect_stdout(io.StringIO()):
        code = probe.main()
    run = pathlib.Path("/private/tmp/account-credential-custody4-" + run_id)
    result = json.loads((run / "selected-test-results.json").read_text())
    classification = "COMPLETE_SELECTED_ACCOUNT_CREDENTIAL_CUSTODY_EXECUTION" if expected in (0, 1) else "INCOMPLETE_OR_PREREQUISITE_FAILURE"
    results.append(dict(group="classification", name=name, passed=code == expected and result["classification"] == classification, exit=code, classification=result["classification"], evidence=str(run)))
probe.subprocess, probe.uuid, probe.__file__, probe.verify_test_sources = real_subprocess, real_uuid, real_file, real_verify

report = dict(candidate_sha256={name: sha(candidate / name) for name in ["driver.sh", "probe.py", "controls.py", "expected-cases.json", "roster-provenance.json", "failure-boundaries.json"]}, controls=results, executed=len(results), passed=sum(result["passed"] for result in results), real_docker_calls=0, cargo_calls=0, database_calls=0, rust_runtime_tests=0)
(evidence / "control-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(dict(evidence=str(evidence), executed=report["executed"], passed=report["passed"], failed=[result["name"] for result in results if not result["passed"]]), indent=2))
raise SystemExit(0 if all(result["passed"] for result in results) else 1)
