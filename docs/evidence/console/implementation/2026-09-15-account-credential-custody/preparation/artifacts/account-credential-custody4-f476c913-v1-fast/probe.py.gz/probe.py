#!/usr/bin/env python3
"""Bounded evidence adapter around the existing PostgreSQL harness, not a product implementation."""
import collections
import hashlib
import json
import pathlib
import re
import subprocess
from subprocess import CalledProcessError
import sys
import uuid

if not __debug__:
    print("probe prerequisite failure: optimized Python disables required guards", file=sys.stderr)
    raise SystemExit(126)

EXPECTED_ROSTER_SHA256 = '4131306dfe7c9fc308e80ad449dad76047d94cde13f845730b205a37e42bd5d9'
ROSTER_PATH = pathlib.Path(__file__).resolve().parent / 'expected-cases.json'
try:
    assert hashlib.sha256(ROSTER_PATH.read_bytes()).hexdigest() == EXPECTED_ROSTER_SHA256, 'unreviewed expected roster'
    EXPECTED_NAMES = json.loads(ROSTER_PATH.read_text())
    assert len(EXPECTED_NAMES) == len(set(EXPECTED_NAMES)) == 4, 'invalid expected roster'
    EXPECTED = set(EXPECTED_NAMES)
except (AssertionError, OSError, ValueError, TypeError) as error:
    print('probe roster prerequisite failure: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
    raise SystemExit(126) from error
COMMAND = 'cargo test --locked --manifest-path backend/Cargo.toml -p console-app --test auth_rest -- --test-threads=1 --exact account_storage::account_custody_has_no_company_ownership_or_destructive_foreign_keys account_storage::account_custody_owners_and_effective_column_grants_are_separate_from_business account_storage::company_login_cannot_read_or_mutate_account_custody_even_with_company_context account_storage::handoff_target_storage_accepts_an_account_without_company_or_employer_user'
HISTORICAL_FIXTURES = {
    'backend/app/tests/auth_rest/fixtures/account-custody-dormant-v1-7af6dfd4.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-projection-v2-69e3ca9c.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-terms-guard-v3-7c599773.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-root-input-d66e2112.sql',
}
REQUIRED_ARTIFACTS = {
    'source-before.json', 'source-after.json', 'probe.log', 'probe-exit.txt',
    'postgres-map.json', 'prebuild-dispatch.txt', 'cleanup.txt',
    'ownership-label.txt', 'container-name.txt', 'containers-before-cleanup.txt',
    'containers-after.txt', 'cleanup-list-error.txt', 'cleanup-final-list-error.txt',
}


# Bound only the reviewed test oracles and historical input, not changing
# implementation bytes. Root can use this same probe before and after a fix.
EXPECTED_FAILURE_BOUNDARIES_SHA256 = 'ea99d4004bb02771b078149312dcefceded1cc0d9cd18767270744291e3438d3'
FAILURE_BOUNDARIES_PATH = pathlib.Path(__file__).resolve().parent / 'failure-boundaries.json'
try:
    assert hashlib.sha256(FAILURE_BOUNDARIES_PATH.read_bytes()).hexdigest() == EXPECTED_FAILURE_BOUNDARIES_SHA256, 'unreviewed semantic failure boundaries'
    FAILURE_BOUNDARIES = json.loads(FAILURE_BOUNDARIES_PATH.read_text())
    assert set(FAILURE_BOUNDARIES['cases']) == EXPECTED, 'semantic boundary roster mismatch'
    assert FAILURE_BOUNDARIES['test_source_sha256'], 'missing frozen test source hashes'
except (AssertionError, OSError, ValueError, KeyError, TypeError) as error:
    print('probe boundary prerequisite failure: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
    raise SystemExit(126) from error


def normalized_diagnostic(diagnostic, expected):
    mode = expected['diagnostic_mode']
    if mode == 'exact':
        return diagnostic
    if mode == 'owner_roster':
        prefix = 'custody must have distinct NOLOGIN owners: '
        assert diagnostic.startswith(prefix), 'owner diagnostic prefix mismatch'
        body = diagnostic[len(prefix):]
        entry = r'\("([a-z_]+)", "([a-z_]+)", (true|false)\)'
        assert re.fullmatch(r'\[' + entry + r'(?:, ' + entry + r')*\]', body), 'malformed owner diagnostic roster'
        entries = re.findall(entry, body)
        assert len(entries) == 13 and len({item[0] for item in entries}) == 13, 'missing/duplicate owner diagnostic row'
        return prefix + json.dumps(sorted(entries), separators=(',', ':'))
    if mode == 'pg_check_row_detail':
        result, count = re.subn(r'detail: Some\("Failing row contains \([^"\n]*\)\."\)', 'detail: Some("[ROW_DETAIL]")', diagnostic)
        assert count == 1, 'missing/ambiguous PostgreSQL failing-row detail'
        return result
    raise AssertionError('unreviewed diagnostic normalization')


def validate_semantic_failures(text, failed):
    blocks = re.findall(r'^---- ([^\n]+) stdout ----\n(.*?)(?=^---- [^\n]+ stdout ----\n|^failures:\n|^test result:|\Z)', text, re.M | re.S)
    assert len(blocks) == len(failed) and {name for name, _ in blocks} == failed, 'missing/duplicate/foreign failure detail'
    assert text.count(' panicked at ') == len(failed), 'missing or unexpected nested panic'
    validated = []
    for name, body in blocks:
        expected = FAILURE_BOUNDARIES['cases'][name]
        panics = re.findall(r"^thread '([^'\n]+)' \(\d+\) panicked at ([^:\n]+):(\d+):(\d+):\n([^\n]+)", body, re.M)
        assert len(panics) == 1, 'unmatched panic record'
        thread, path, line, column, diagnostic = panics[0]
        assert thread == name and path == expected['panic_path'] and int(line) == expected['line'] and int(column) == expected['column'], 'unreviewed panic source boundary'
        assert normalized_diagnostic(diagnostic, expected) == expected['normalized_diagnostic'], 'unreviewed assertion or prerequisite failure'
        validated.append({'name': name, 'path': path, 'line': int(line), 'column': int(column), 'diagnostic': diagnostic})
    return validated


def validate(text, exit_code):
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    found = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    counts = collections.Counter(status for _, status in found)
    assert len(found) == 4 and {name for name, _ in found} == EXPECTED, 'missing/duplicate/foreign case'
    assert counts['ignored'] == 0, 'ignored case'
    assert re.findall(r'^running(?:[ \t].*)?$', text, re.M) == ['running 4 tests'], 'discovery mismatch'
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    assert len(re.findall(r'^test(?:[ \t].*)?$', text, re.M)) == len(found) + len(summaries), 'unmatched test record'
    assert len(summaries) == 1 and summaries[0][:5] == ('FAILED' if counts['FAILED'] else 'ok', str(counts['ok']), str(counts['FAILED']), '0', '0'), 'summary mismatch'
    filtered = int(summaries[0][5])
    assert filtered == 212, 'filtered baseline inventory mismatch'
    assert re.findall(r'^cargo-postgres: === (.+) ===$', text, re.M) == ['app-auth-rest-pg'], 'invocation mismatch'
    assert re.findall(r'^cargo-postgres: (cargo test .*)$', text, re.M) == [COMMAND], 'argv mismatch'
    timing = [json.loads(line) for line in re.findall(r'^cargo-postgres-timing: (.+)$', text, re.M)]
    assert len(timing) == 1 and timing[0]['name'] == 'app-auth-rest-pg' and timing[0]['package'] == 'console-app', 'timing identity mismatch'
    assert timing[0]['status'] == ('fail' if counts['FAILED'] else 'pass'), 'timing outcome mismatch'
    assert re.findall(r'^cargo-postgres: (\d+) passed, (\d+) failed$', text, re.M) == [('0', '1') if counts['FAILED'] else ('1', '0')], 'rollup mismatch'
    assert re.findall(r'^  (PASS|FAIL)  (.+)$', text, re.M) == [('FAIL' if counts['FAILED'] else 'PASS', 'app-auth-rest-pg')], 'final roster mismatch'
    assert exit_code == (1 if counts['FAILED'] else 0), 'harness exit mismatch'
    semantic_failures = validate_semantic_failures(text, {name for name, status in found if status == 'FAILED'})
    return {'semantic_failures': semantic_failures, 'executed': 4, 'passed': counts['ok'], 'failed': counts['FAILED'], 'filtered': filtered, 'ignored': 0, 'cases': dict(found)}


def verify_test_sources(root):
    for path, digest in FAILURE_BOUNDARIES['test_source_sha256'].items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == digest, 'frozen test source or historical fixture changed before execution'


def main():
    run = pathlib.Path('/private/tmp/account-credential-custody4-' + uuid.uuid4().hex)
    print(run, flush=True)
    result = {}
    try:
        root = pathlib.Path.cwd()
        candidate = pathlib.Path(__file__).resolve().parent
        private = {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in ['driver.sh', 'probe.py', 'expected-cases.json', 'failure-boundaries.json']}
        result['private_sha256'] = private
        assert private['expected-cases.json'] == EXPECTED_ROSTER_SHA256, 'expected roster hash mismatch'
        assert private['failure-boundaries.json'] == EXPECTED_FAILURE_BOUNDARIES_SHA256, 'semantic boundary hash mismatch'
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
        result['head'] = head
        verify_test_sources(root)
        code = subprocess.run(['bash', str(candidate / 'driver.sh'), str(root), head, str(run)]).returncode
        result['driver_exit'] = code
        assert code in (0, 1), 'driver prerequisite failure'
        assert private['expected-cases.json'] == EXPECTED_ROSTER_SHA256, 'expected roster hash mismatch'
        assert private == {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in private}, 'private source changed'
        before = json.loads((run / 'source-before.json').read_text())
        assert before == json.loads((run / 'source-after.json').read_text()) and before['head'] == head and not before['status_porcelain'], 'source snapshot mismatch'
        assert HISTORICAL_FIXTURES <= set(before['files']), 'historical fixture missing from snapshot'
        assert all(before['files'].get(path) == digest for path, digest in FAILURE_BOUNDARIES['test_source_sha256'].items()), 'frozen test source or historical fixture changed'
        receipt = json.loads((run / 'driver-receipt.json').read_text())
        assert REQUIRED_ARTIFACTS <= set(receipt['artifacts']), 'required receipt artifact omitted'
        assert receipt['driver_sha256'] == private['driver.sh'] and receipt['probe_exit'] == code and receipt['prebuild_interception_count'] == 1, 'driver receipt mismatch'
        for name, digest in receipt['artifacts'].items():
            assert pathlib.Path(name).name == name and hashlib.sha256((run / name).read_bytes()).hexdigest() == digest, 'driver artifact changed'
        assert (run / 'cleanup.txt').read_text().strip() == 'confirmed owned container absent via successful bounded docker ps -a', 'cleanup incomplete'
        name = (run / 'container-name.txt').read_text().strip()
        assert name and name not in (run / 'containers-after.txt').read_text().splitlines(), 'owned container remains'
        assert not (run / 'cleanup-final-list-error.txt').read_text(), 'final listing error'
        result.update(validate((run / 'probe.log').read_text(), code))
        result['classification'] = 'COMPLETE_SELECTED_ACCOUNT_CREDENTIAL_CUSTODY_EXECUTION'
    except (AssertionError, OSError, ValueError, KeyError, TypeError, CalledProcessError) as error:
        result.update(classification='INCOMPLETE_OR_PREREQUISITE_FAILURE', detail=type(error).__name__ + ': ' + str(error))
        code = 126
        run.mkdir(mode=0o700, exist_ok=True)
        with (run / 'prerequisite-error.txt').open('x') as artifact:
            artifact.write(result['detail'] + '\n')
    with (run / 'selected-test-results.json').open('x') as artifact:
        artifact.write(json.dumps(result, indent=2) + '\n')
    return code


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, CalledProcessError) as error:
        print('probe evidence-write prerequisite failure: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
        raise SystemExit(126) from error
