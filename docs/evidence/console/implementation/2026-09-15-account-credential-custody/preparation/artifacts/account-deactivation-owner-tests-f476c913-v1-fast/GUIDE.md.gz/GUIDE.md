# Private additive Company-deactivation owner tests

Base `f476c9133b0de665c217366c2ebe5933a39493cb`. Author `/root/fast_gate_review`; root owns source integration and all Cargo/PostgreSQL runtime. This is a tests-only candidate for independent review. No product change or implementation admission is included.

Exactly one existing test source is extended: `backend/crates/identity/adapter-postgres/tests/deactivate_revokes_credentials.rs`. Its entire original byte prefix, including the existing test and helpers, is preserved. Five tests are appended inside `account_custody_deactivation`. `post/` holds the exact resulting file and `tests.patch` is the additive diff. No new Cargo target, manifest, dependency, BUCK file, test skip or original assertion change.

The current owner is Company-scoped: `PgOrgStore::deactivate_user` obtains `current_org`, changes `users.is_active`, performs a credential sweep and bumps Company subject freshness. The REST alias requires Company UserManage. This is not the explicit Account security-suspension owner. AS1 account-contract lines5,16,24,25 require native Account custody to survive Company relationship termination while the old unfenced protocol retains its separate security behavior.

## Test boundaries

1. `active_account_custody_survives_company_deactivation_and_replay`: the actual Business LOGIN owner must remove Company `is_active` eligibility and preserve the fenced Account root, security state/generation, complete passkey rows, complete family/token history and Account security events. The Company action and replay cannot claim global key/family revocation in Company audit. The existing replay conflict is retained.
2. `nonactive_account_security_is_not_reclassified_by_company_deactivation`: the same owner checks run for explicit PENDING_ENROLLMENT, SECURITY_SUSPENDED and RECOVERY_REQUIRED fixture states. No state is derived from Employment or Company status. A current RED at the first pending-state assertion does not prove later loop variants executed.
3. `unavailable_account_authority_preserves_fenced_subject_before_company_effect`.
4. `unavailable_account_authority_cannot_select_unfenced_legacy_revocation`: these two cases hold a real ACCESS EXCLUSIVE lock on `account_security`. The real Auth projection first proves the subject's known classification, then must fail specifically with SQLSTATE55P03 under the held lock. Calling the existing Business-only owner while authority remains unavailable must return a bounded refusal and leave complete Company user/freshness, Account/security, credential/history and audit snapshots unchanged. After releasing the lock, the same owner must succeed, proving that always-deny is insufficient. Native custody remains unchanged; legacy credentials are revoked.
5. `unfenced_legacy_subject_still_loses_keys_families_and_refresh_after_company_deactivation`: explicit absence of `account_security`, actual Business LOGIN deactivation, owner-only readback, all key deletion/family/token revocation, actual refresh `FamilyRevoked`, exact original audit actions and no accidental enrollment.

Each subject has real existing legacy refresh issuance, rotation and a second revoked family before any Account security fixture is inserted. These preserve real token history rather than synthetic booleans. The passkey fixture reuses the existing opaque-row fixture because deactivation must not parse or replace key bytes. The explicit security row is privileged test setup, not enrollment, consent, primary WebAuthn proof or native Account session construction. Retained families are custody evidence; no test turns a legacy family into ACCOUNT_V1, calls native login, claims preserved usable login, or certifies native protocol metadata. Those require the browser/session acceptance lane.

Owner readback compares full credential/family/token rows, including hashes, identifiers, counters, history and revocation fields. It does not grant Business direct SELECT. The stable native security projection pins state and security generation while allowing legitimate Company/context revision changes; unavailable-authority rollback additionally compares the complete raw security row and all audit rows. Native Company work eligibility is established by the actual owner return and persisted `users.is_active=false`, not by fabricated Employment or native session status.

## Integration and execution

Review the exact manifest and post hash first. The prior test's Business credential-count helper is a separate observation-fixture correction; this candidate preserves it. If root combines that independently approved correction with this append, freeze the combined test source and update its base/line/hash receipts before implementation. Never copy the post file over a different reviewed prefix.

Reuse the existing wrapper `identity-adapter-postgres-deactivate-revokes-credentials-pg`; no coordinator is needed. Its unfiltered existing command becomes6 source-declared SQLx tests after this append:

`cargo test --locked --manifest-path backend/Cargo.toml -p console-identity-adapter-postgres --test deactivate_revokes_credentials -- --test-threads=1`

Selected new owner boundaries can use the same harness map entry with the single existing libtest module filter:

`cargo test --locked --manifest-path backend/Cargo.toml -p console-identity-adapter-postgres --test deactivate_revokes_credentials account_custody_deactivation:: -- --test-threads=1`

The selected expectation is5 discovered/executed,1 existing case filtered, no ignored/measured. Prediction on current source: four behavioral REDs (two custody-retention failures and two mutation-under-unavailable-authority failures), plus one explicit legacy positive. This prediction is not runtime evidence. Compilation, fixture issuance, exact real-login identity, SQLSTATE55P03 fault control and complete snapshots are prerequisites; their failure is not the intended owner RED. Root must retain raw first diagnostics, exact names/counts/source hashes, selected command, owned database/cleanup evidence and independent failure review before admitting an implementation lane.

The implementation must classify Account-versus-legacy and perform any permitted legacy credential sweep within a serialized current-authority owner boundary. An Auth precheck followed by an unguarded Business mutation is insufficient. Tests call the existing `PgOrgStore` API, add no Business auth-only grant and invent no missing capability API. The narrow owner/helper and transaction composition are implementation responsibilities. These sequential and unavailable-authority tests do not independently prove a concurrent enrollment/deactivation cutover race; independent implementation review must check locking, admission/drain and recheck, and add a separately reviewed race fixture if the chosen transition can overlap.

## Verification and limits

The installed Rust1.98.1 rustfmt parsed/formatted only the private appended module. The existing prefix is byte-identical; static inventory finds five new and one preserved SQLx cases; patch applicability is checked read-only. No Cargo compile, database, test runtime, Docker call or shared-source edit was performed. Rustfmt is syntax evidence, not typechecking or executed behavioral proof.

Pre-mortem: blanket revocation could erase a native Account's credentials; state-dependent fallback could restore employer authority; unavailable classification could choose legacy mutation; a mocked or privileged caller could hide missing runtime ownership. Detection uses real LOGIN owner calls, preserved complete rows, every security state, replay, real locked authority, positive restoration and real legacy refresh denial. Fixture error/setup RED must never be counted as behavioral admission.

Blast radius is one private appended test candidate. Future root runtime uses the existing isolated PostgreSQL harness. Rollback is to not integrate the candidate while preserving its evidence; no product effect exists. Stop on prefix/hash drift, stale observation-fixture conflict, failed prerequisites, absent independent test approval, unreviewed source or attempted product/authority expansion. Native session/login, populated contexts, actor46, Company purge, production/payment/legal claims remain outside these tests.

Independent review requested from `/root/capture_review` or `/root/inventory_repair`; author is not an independent reviewer. Root retains exact approval authority. Lenses: Cartesian doubt, Essentialism, Systems Thinking, Red Team, Operability, Blast radius and Zero trust.
