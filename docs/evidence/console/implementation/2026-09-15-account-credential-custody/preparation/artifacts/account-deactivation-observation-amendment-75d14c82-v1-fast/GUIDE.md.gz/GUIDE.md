# Separate legacy credential-count observation amendment

Base `75d14c82c97ebdf21e1e849840a9bd4693e5e2bd`. Author `/root/fast_gate_review`; root is the only integration writer/runtime operator. This private tests-only amendment is separate from the additive Account deactivation tests.

Exactly one helper and its two observation call sites change in `backend/crates/identity/adapter-postgres/tests/deactivate_revokes_credentials.rs`. `count_credentials_as_runtime` becomes `count_credentials_as_owner`, using the existing privileged fixture pool and transaction-local `row_security=off`. Its SELECT explicitly requires both `org_id=$1` and `user_id=$2`, preserving the prior Company RLS plus user predicate. It does not grant Business credential privileges or widen the observation to another Company/user.

The original Business pool, `PgOrgStore::deactivate_user`, real refresh invocation and `FamilyRevoked` assertion, exact audit assertions, identity fixtures, expected before/after credential counts and all test behavior assertions remain unchanged. The test still executes the Company mutation through its original restricted Business current role. Only its privileged observation moves; the appended native tests in the separate combined candidate exercise real LOGIN connections.

This correction is necessary because custody4 explicitly requires Business direct credential SELECT to fail42501. Retaining that forbidden SELECT as a fixture observation would conflict with the intended privilege boundary. The expected legacy key/family revocation behavior is preserved; native Account custody preservation remains separately tested.

`tests.patch` applies to the exact clean base without source edits during preparation. Syntax was checked with installed Rust1.98.1 rustfmt in stdout-only mode; no Cargo/typechecking/database/runtime was performed. The original test body compares byte-identically after reversing only the two observation call substitutions, and the rest of the file compares identically after reversing the helper replacement. No skips, grants, dependency/target/generated changes or product edits.

Review this exact amendment independently. Root may import it alone or use the combined V2 package, never both patches against an already amended file. If the source/base differs, preserve both candidates and rebind a new exact candidate before integration. Root retains all test approval and runtime authority. Rollback is to not integrate this private candidate; no product effect exists. Stop on predicate loss, assertion drift, new grants, source/hash mismatch or absent independent review.

Lenses: Cartesian doubt, Essentialism, Red Team, Operability, Blast radius and Zero trust. Independent reviewer requested `/root/capture_review`; no review approval is claimed here.
