# Combined Company-deactivation owner tests V2

Base `75d14c82c97ebdf21e1e849840a9bd4693e5e2bd`. Author `/root/fast_gate_review`; root owns integration and all Cargo/PostgreSQL runtime. This tests-only candidate combines the separate owner-count observation amendment with five additive owner tests. Exactly one existing source file changes, with six total SQLx cases and no new target, manifest, dependency, BUCK file, skip or product edit.

The original test changes only its credential-count helper and two observation calls. Privileged readback uses the explicit original Company-and-user predicate. The original Business deactivate, real refresh `FamilyRevoked`, audit assertions and all behavior expectations remain intact. `observation-amendment.patch` records that component separately. Import the combined `tests.patch` once; do not apply both the combined patch and standalone amendment.

V1 `/private/tmp/account-deactivation-owner-tests-f476c913-v1-fast` remains immutable. V2 also addresses Capture's two independent review findings in the additive module, explicitly recorded in `v1-to-v2-module.diff`: the helper retains typed `PgOrgError` and replay must be `ErrorKind::Conflict`; legacy/restored-unfenced checks compare complete precomputed family/token/history rows, preserving IDs/hashes/counts and previously revoked values. The only expected legacy row changes are deletion of key rows, initially-null family `revoked_at` plus `revoked_reason='user_deactivated'`, and initially-null token `revoked_at`. Expected event time is independently converted by `SELECT to_jsonb($1::timestamptz)` before effects, so PostgreSQL precision/formatting is exact without learning the answer from mutated rows. A real refused refresh must preserve that exact history too. V2 does not claim its revised additive module is byte-identical to V1.

## Six actual owner cases

- The preserved original legacy revocation test, with its narrow observation correction.
- ACTIVE Account custody survives actual Company deactivation and Conflict replay; Company eligibility becomes inactive.
- PENDING_ENROLLMENT, SECURITY_SUSPENDED and RECOVERY_REQUIRED are explicit fixture states and retain custody. Current RED at the first state does not prove later loop variants executed.
- Fenced Account authority unavailability refuses before any Company/custody/audit mutation; restoration permits the actual Company action and retains Account custody.
- Unfenced legacy authority unavailability likewise refuses and cannot select destructive fallback; restoration performs exactly the permitted legacy revocation delta.
- Explicit unfenced legacy real-LOGIN positive preserves original revocation/audit behavior and returns actual `FamilyRevoked`, with exact retained family/token history.

The five additive cases call the existing `PgOrgStore::deactivate_user` through real verified Business LOGIN connections. They do not invent a missing owner API or expose auth-only grants to Business. Owner-only snapshots compare complete opaque key/family/token history, stable Account identity/security state/generation and Account security events. Company/context revisions may legitimately change; the unavailable-authority rollback oracle also compares complete raw security, Company user/freshness and audit rows.

The fault holds a real ACCESS EXCLUSIVE lock on `account_security`; the real Auth projection first establishes the known classification and then must fail specifically with55P03 while the lock is held. Bounded owner refusal plus no mutation is required; after releasing the lock, the same actual action must succeed, preventing an always-deny implementation from passing.

Fixtures issue and rotate real existing legacy refresh families before explicitly inserting Account security facts. They retain a second already-revoked family too. This proves ownership/history preservation, not enrollment, consent, primary WebAuthn proof, a working ACCOUNT_V1 session, or continued usable native login. No state is inferred from Employment. The existing opaque passkey fixture is compared without parsing or changing key bytes. Native browser/session acceptance remains separate.

## Integration and root runtime

Verify every metadata hash and the exact pre/post source hashes. `tests.patch` applies read-only to the clean base; `post/` is the reviewed result. If another approved source edit lands first, preserve these immutable artifacts and rebind the combined candidate before importing. Do not overwrite a changed test prefix. Independent test approval must bind to the final combined test commit.

Reuse existing wrapper `identity-adapter-postgres-deactivate-revokes-credentials-pg` and its unfiltered command:

`cargo test --locked --manifest-path backend/Cargo.toml -p console-identity-adapter-postgres --test deactivate_revokes_credentials -- --test-threads=1`

Root's intended complete execution is6 discovered/executed,0 filtered/ignored/measured. Predicted baseline is4 behavioral REDs and2 legacy positives; this is a source prediction, not an execution result. `predicted-boundaries.json` locates only the intended first assertion sites. Compiler/setup/login/SQLSTATE fault-control/snapshot failures cannot be counted as owner behavioral RED. Retain exact argv/names/counts, raw diagnostics, source/head hashes and isolated-harness cleanup evidence, then independently review before coherent caller conversion admission.

The existing custody4 probe remains the credential catalog/ACL boundary; rerun and bind it to the exact approved combined test commit as required. Classification and any permitted legacy sweep must share a serialized current-authority owner boundary. A detached Auth precheck followed by unguarded Business mutation remains insufficient. These owner tests do not independently prove a concurrent enrollment/deactivation race; review locking, admission/drain and recheck in the implementation and obtain a separately reviewed race fixture if the selected transition can overlap.

## Evidence and stops

Installed Rust1.98.1 rustfmt parses the private source; read-only `git apply --check` verifies patch applicability. V1 hashes remain intact, the original test's assertions/calls are preserved except the reviewed observation substitution, and static inventory contains exactly six cases. No Cargo compile, database/runtime, real Docker or shared-source mutation was performed by this author.

Pre-mortem: native blanket revocation, state-dependent employer authority, outage fallback, deleted legacy history or a replay failure disguised as Conflict. Detection: exact retained snapshots/deltas, all security states, typed replay error, real authority lock, restoration and actual legacy refresh denial. Blast radius is one private test candidate; future runtime stays in the existing isolated harness. Rollback is to not integrate while preserving evidence. Stop on stale source/hash, weakened predicate/assertions, missing review/test approval, prerequisite failure or attempted product/authority expansion. Native sessions, populated contexts, actor46, purge proof and production/payment/legal claims remain outside these tests.

Lenses: Cartesian doubt, Essentialism, Systems Thinking, Red Team, Operability, Blast radius and Zero trust. Independent reviewer `/root/capture_review` supplied the V1 findings; independent V2 approval is still required. Root retains exact integration/runtime and approval authority.
