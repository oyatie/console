// PRIVATE APPEND-ONLY CANDIDATE for the existing recovery.rs integration target.
// Uses its imports and helpers. No existing test body changes. Not compiled/run.

async fn fresh_cleanup_backend_exists(owner: &PgPool, backend: &Backend) -> bool {
    sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=$1 AND backend_start=$2 AND datname=current_database() AND application_name=$3)",
    )
    .bind(backend.pid)
    .bind(backend.started)
    .bind(&backend.application_name)
    .fetch_one(owner)
    .await
    .unwrap()
}

async fn assert_fresh_backend_closed(owner: &PgPool, backend: &Backend) {
    tokio::time::timeout(Duration::from_secs(2), async {
        while fresh_cleanup_backend_exists(owner, backend).await {
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("FRESH_SYNCREP_CLEANUP: exact abandoned backend survives bounded cleanup while replay remains paused");
}

#[sqlx::test(migrations = "../../platform/db/migrations")]
async fn fresh_commit_deadline_reclaims_backend_before_replay_resumes(owner: PgPool) {
    let org = OrgId::from_uuid(Uuid::new_v4());
    let actor = seed_org_and_super_admin(&owner, *org.as_uuid(), "fresh-deadline-cleanup").await;
    let descriptor = admitted_fixture_descriptor(&owner, 700).await;
    let (pool, backend) = runtime_pool(&owner, "console-recovery-fresh-deadline").await;
    let port = required_port(pool.clone(), &descriptor);
    let command = create(org, actor);
    let sent = command.clone();
    control("pause-replay");
    let resume = ResumeOnDrop;
    let started = tokio::time::Instant::now();
    let call = tokio::task::spawn_blocking(move || port.execute(&sent));
    sync_wait(&owner, &backend, &call).await;
    let error = tokio::time::timeout(Duration::from_secs(2), call)
        .await
        .expect("FRESH_SYNCREP_DEADLINE: owner exceeded its caller budget")
        .unwrap()
        .unwrap_err();
    assert!(
        matches!(
            error,
            console_payroll_adapter_postgres::pay_run::PayRunError::DurabilityUnknown(_)
        ),
        "FRESH_SYNCREP_UNKNOWN: actual fresh COMMIT cannot return success or known rollback: {error:?}"
    );
    assert!(started.elapsed() < Duration::from_secs(2));
    assert_fresh_backend_closed(&owner, &backend).await;
    let committed = command_receipt_rows(&owner, org).await;
    assert_eq!(committed["receipts"].as_array().unwrap().len(), 1);
    assert_eq!(committed["drafts"].as_array().unwrap().len(), 1);
    control("resume-replay");
    drop(resume);
    let mut retry_descriptor = descriptor.clone();
    retry_descriptor["timeout_ms"] = json!(15_000);
    let retry = required_port(pool.clone(), &retry_descriptor);
    let sent = command.clone();
    finish_command(tokio::task::spawn_blocking(move || retry.execute(&sent)))
        .await
        .unwrap();
    let standby = standby_pool(&owner).await;
    assert_eq!(command_receipt_rows(&owner, org).await, committed);
    assert_eq!(command_receipt_rows(&standby, org).await, committed);
    standby.close().await;
    pool.close().await;
}

#[sqlx::test(migrations = "../../platform/db/migrations")]
async fn aborted_fresh_stage_retains_capacity_until_native_wait_ends(owner: PgPool) {
    let org = OrgId::from_uuid(Uuid::new_v4());
    seed_org_and_super_admin(&owner, *org.as_uuid(), "fresh-abort-cleanup").await;
    let descriptor = admitted_fixture_descriptor(&owner, 700).await;
    let (pool, backend) = runtime_pool(&owner, "console-recovery-fresh-abort").await;
    let draft = StagePayrollDraft {
        org,
        outbox_event_id: Uuid::new_v4(),
        run_id: Uuid::new_v4(),
        period_start: Some(date!(2026 - 06 - 01)),
        period_end: Some(date!(2026 - 06 - 30)),
        connector: Some("m2".into()),
        job: Some("payroll_draft".into()),
    };
    let retry_draft = draft.clone();
    let port = required_port(pool.clone(), &descriptor);
    control("pause-replay");
    let resume = ResumeOnDrop;
    let call = tokio::spawn(async move { port.stage(draft).await });
    sync_wait(&owner, &backend, &call).await;
    call.abort();
    assert!(call.await.unwrap_err().is_cancelled());
    // The pool has exactly one slot. Once it issues a replacement, observe the
    // old exact backend afterward in one server snapshot: it must no longer be
    // an abandoned SyncRep waiter. No timing-only sleep stands in for this fact.
    let replacement: i32 = tokio::time::timeout(
        Duration::from_secs(3),
        sqlx::query_scalar("SELECT pg_backend_pid()").fetch_one(&pool),
    )
    .await
    .expect("FRESH_SYNCREP_POOL_RECOVERY: retained capacity was never released")
    .unwrap();
    assert_ne!(replacement, backend.pid);
    let abandoned_waiter: bool = sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=$1 AND backend_start=$2 AND datname=current_database() AND application_name=$3 AND wait_event='SyncRep')",
    )
    .bind(backend.pid)
    .bind(backend.started)
    .bind(&backend.application_name)
    .fetch_one(&owner)
    .await
    .unwrap();
    assert!(
        !abandoned_waiter,
        "FRESH_SYNCREP_CAPACITY: replacement admitted while abandoned fresh COMMIT still owns server resources"
    );
    assert_fresh_backend_closed(&owner, &backend).await;
    let committed = command_receipt_rows(&owner, org).await;
    assert_eq!(committed["receipts"].as_array().unwrap().len(), 0);
    assert_eq!(committed["drafts"].as_array().unwrap().len(), 1);
    control("resume-replay");
    drop(resume);
    let mut retry_descriptor = descriptor.clone();
    retry_descriptor["timeout_ms"] = json!(15_000);
    let retry = required_port(pool.clone(), &retry_descriptor);
    assert!(!retry.stage(retry_draft).await.unwrap());
    let standby = standby_pool(&owner).await;
    assert_eq!(command_receipt_rows(&owner, org).await, committed);
    assert_eq!(command_receipt_rows(&standby, org).await, committed);
    standby.close().await;
    pool.close().await;
}
