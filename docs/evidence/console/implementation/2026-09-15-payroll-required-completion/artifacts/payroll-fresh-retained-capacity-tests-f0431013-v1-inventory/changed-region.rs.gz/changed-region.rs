// PRIVATE APPEND-ONLY CANDIDATE for the existing recovery.rs integration target.
// Uses its imports and helpers. No existing test body changes. Not compiled/run.

async fn fresh_cleanup_backend_exists(owner: &PgPool, backend: &Backend) -> bool {
    sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=$1 AND backend_start=$2 AND datname=current_database() AND application_name=$3)",
    )
    .bind(backend.pid)
    .bind(backend.started)
    .bind(&backend.application_name)
    .fetch_one(owner)
    .await
    .unwrap()
}

async fn assert_fresh_backend_closed(owner: &PgPool, backend: &Backend) {
    tokio::time::timeout(Duration::from_secs(2), async {
        while fresh_cleanup_backend_exists(owner, backend).await {
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("FRESH_SYNCREP_CLEANUP: exact abandoned backend survives bounded cleanup after replay recovers");
}

async fn set_fresh_cleanup_timers(
    pool: &PgPool,
    backend: &Backend,
    statement_ms: u64,
    transaction_ms: u64,
) {
    // Configure the existing restricted one-slot pool's actual session. These
    // are test inputs; the owner still chooses its own transaction-local cap.
    let row = sqlx::query(
        "SELECT pg_backend_pid(), set_config('statement_timeout',$1,false), set_config('transaction_timeout',$2,false)",
    )
    .bind(format!("{statement_ms}ms"))
    .bind(format!("{transaction_ms}ms"))
    .fetch_one(pool)
    .await
    .unwrap();
    assert_eq!(row.get::<i32, _>(0), backend.pid);
    let actual: (i32, i64, i64) = sqlx::query_as(
        "SELECT pg_backend_pid(), (SELECT setting::bigint FROM pg_settings WHERE name='statement_timeout'), (SELECT setting::bigint FROM pg_settings WHERE name='transaction_timeout')",
    )
    .fetch_one(pool)
    .await
    .unwrap();
    assert_eq!(
        actual,
        (backend.pid, statement_ms as i64, transaction_ms as i64)
    );
}

async fn assert_exact_fresh_waiter(owner: &PgPool, backend: &Backend) {
    let rows: Vec<(i32, time::OffsetDateTime, bool)> = sqlx::query_as(
        "SELECT pid,backend_start,state='active' AND wait_event_type='IPC' AND wait_event='SyncRep' \
         FROM pg_stat_activity WHERE datname=current_database() AND usename='console_rt' AND application_name=$1",
    )
    .bind(&backend.application_name)
    .fetch_all(owner)
    .await
    .unwrap();
    assert_eq!(
        rows,
        vec![(backend.pid, backend.started, true)],
        "FRESH_SYNCREP_CAPACITY: exactly the original active native waiter must occupy this isolated pool"
    );
}

async fn assert_fresh_capacity_retained(
    owner: &PgPool,
    pool: &PgPool,
    backend: &Backend,
    descriptor: &Value,
    draft: &StagePayrollDraft,
) {
    // Bound resource occupancy while replay is deliberately unavailable. These
    // attempts exercise the original pool; opening another pool would evade the
    // admission condition under test. Each actual owner attempt has its own
    // short explicit fixture policy and must expire before acquiring capacity.
    let mut attempted_policy = descriptor.clone();
    attempted_policy["timeout_ms"] = json!(100);
    for attempt in 0..3 {
        assert_exact_fresh_waiter(owner, backend).await;
        let acquisition = tokio::time::timeout(Duration::from_millis(75), pool.acquire()).await;
        assert!(
            acquisition.is_err(),
            "FRESH_SYNCREP_CAPACITY: acquisition attempt {attempt} completed while the original native waiter remained paused"
        );
        assert!(!pool.is_closed(), "responsive retained pool remains open");
        let port = required_port(pool.clone(), &attempted_policy);
        let error = tokio::time::timeout(Duration::from_millis(500), port.stage(draft.clone()))
            .await
            .expect("FRESH_SYNCREP_ATTEMPT_DEADLINE: queued owner must honor its own policy budget")
            .unwrap_err();
        assert_eq!(error.kind, console_kernel_core::ErrorKind::Internal);
        assert!(
            error.message.starts_with("database durability UNKNOWN:"),
            "FRESH_SYNCREP_ATTEMPT_UNKNOWN: queued stage cannot claim success or known rollback: {error}"
        );
        assert_exact_fresh_waiter(owner, backend).await;
    }
}

async fn replacement_after_fresh_recovery(owner: &PgPool, pool: &PgPool, backend: &Backend) {
    // The first requested replacement query samples its own PID and the exact
    // original waiter together. It is queued before replay resumes, proving
    // there is no separate admission window between recovery and the probe.
    let mut replacement = Box::pin(
        sqlx::query_as::<_, (i32, bool)>(
            "SELECT pg_backend_pid(), EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=$1 AND backend_start=$2 AND datname=current_database() AND application_name=$3 AND wait_event='SyncRep')",
        )
        .bind(backend.pid)
        .bind(backend.started)
        .bind(&backend.application_name)
        .fetch_one(pool),
    );
    let early = tokio::time::timeout(Duration::from_millis(200), &mut replacement).await;
    assert!(
        early.is_err(),
        "FRESH_SYNCREP_CAPACITY: replacement query was admitted before actual replay recovery"
    );
    assert_exact_fresh_waiter(owner, backend).await;
    control("resume-replay");
    let (replacement, abandoned_waiter) = tokio::time::timeout(Duration::from_secs(3), replacement)
        .await
        .expect(
            "FRESH_SYNCREP_POOL_RECOVERY: original capacity did not recover after replay resumed",
        )
        .unwrap();
    assert_ne!(replacement, backend.pid);
    assert!(
        !abandoned_waiter,
        "FRESH_SYNCREP_CAPACITY: replacement overlapped the exact original native waiter"
    );
    assert_fresh_backend_closed(owner, backend).await;
}

#[sqlx::test(migrations = "../../platform/db/migrations")]
async fn fresh_commit_deadline_retains_capacity_until_replay_resumes(owner: PgPool) {
    // The reviewed amendment bounds caller UNKNOWN and occupied capacity;
    // backend cleanup follows actual replay recovery. These four inputs preserve
    // compatibility with supplied session timers, not a disproved native COMMIT
    // timer claim. The previous hard-cleanup probe is retained as history.
    for (scenario, policy_ms, statement_ms, transaction_ms) in [
        ("default", 700_u64, 0_u64, 0_u64),
        ("equal-positive-timers", 5_000, 1_200, 1_200),
        ("shorter-transaction-timer", 5_000, 5_000, 1_200),
        ("shorter-statement-timer", 5_000, 400, 0),
    ] {
        println!(
            "fresh-cleanup canonical scenario={scenario} policy_ms={policy_ms} statement_ms={statement_ms} transaction_ms={transaction_ms}"
        );
        let org = OrgId::from_uuid(Uuid::new_v4());
        let actor =
            seed_org_and_super_admin(&owner, *org.as_uuid(), "fresh-deadline-cleanup").await;
        let descriptor = admitted_fixture_descriptor(&owner, policy_ms).await;
        let label = format!("console-recovery-fresh-deadline-{scenario}");
        let (pool, backend) = runtime_pool(&owner, &label).await;
        set_fresh_cleanup_timers(&pool, &backend, statement_ms, transaction_ms).await;
        let port = required_port(pool.clone(), &descriptor);
        let command = create(org, actor);
        let sent = command.clone();
        control("pause-replay");
        let resume = ResumeOnDrop;
        let started = tokio::time::Instant::now();
        let call = tokio::task::spawn_blocking(move || port.execute(&sent));
        sync_wait(&owner, &backend, &call).await;
        if statement_ms > 0 {
            assert!(
                started.elapsed() < Duration::from_millis(1_500),
                "FRESH_SYNCREP_TIMER_PREREQUISITE: fresh native witness arrived after the existing setup budget"
            );
        }
        let caller_bound = Duration::from_millis(policy_ms + 1_300);
        let error = tokio::time::timeout_at(started + caller_bound, call)
            .await
            .expect("FRESH_SYNCREP_DEADLINE: owner exceeded its caller budget")
            .unwrap()
            .unwrap_err();
        assert!(
            matches!(
                error,
                console_payroll_adapter_postgres::pay_run::PayRunError::DurabilityUnknown(_)
            ),
            "FRESH_SYNCREP_UNKNOWN: actual fresh COMMIT cannot return success or known rollback: {error:?}"
        );
        assert!(started.elapsed() < caller_bound);
        let attempted_draft = match &command.query {
            PayRunQuery::CreateRun {
                run_id,
                period_start,
                period_end,
                connector,
                job,
            } => StagePayrollDraft {
                org,
                outbox_event_id: *command.command_id.as_uuid(),
                run_id: *run_id,
                period_start: Some(*period_start),
                period_end: Some(*period_end),
                connector: connector.clone(),
                job: job.clone(),
            },
            _ => panic!("fixture requires actual CreateRun input"),
        };
        assert_fresh_capacity_retained(&owner, &pool, &backend, &descriptor, &attempted_draft)
            .await;
        assert_eq!(
            command_receipt_rows(&owner, org).await,
            json!({"receipts": [], "drafts": []}),
            "live native SyncRep transaction remains snapshot-invisible"
        );
        replacement_after_fresh_recovery(&owner, &pool, &backend).await;
        drop(resume);
        let committed = command_receipt_rows(&owner, org).await;
        assert_eq!(committed["receipts"].as_array().unwrap().len(), 1);
        assert_eq!(committed["drafts"].as_array().unwrap().len(), 1);
        let mut retry_descriptor = descriptor.clone();
        retry_descriptor["timeout_ms"] = json!(15_000);
        let retry = required_port(pool.clone(), &retry_descriptor);
        let sent = command.clone();
        finish_command(tokio::task::spawn_blocking(move || retry.execute(&sent)))
            .await
            .unwrap();
        let standby = standby_pool(&owner).await;
        assert_eq!(command_receipt_rows(&owner, org).await, committed);
        assert_eq!(command_receipt_rows(&standby, org).await, committed);
        standby.close().await;
        pool.close().await;
    }
}

#[sqlx::test(migrations = "../../platform/db/migrations")]
async fn aborted_fresh_stage_retains_capacity_until_native_wait_ends(owner: PgPool) {
    // Native wait ends through actual replay recovery. The unchanged exact
    // test name and timer inputs preserve historical probe traceability.
    for (scenario, policy_ms, statement_ms, transaction_ms) in [
        ("default", 700_u64, 0_u64, 0_u64),
        ("equal-positive-timers", 5_000, 1_200, 1_200),
        ("shorter-transaction-timer", 5_000, 5_000, 1_200),
        ("shorter-statement-timer", 5_000, 400, 0),
    ] {
        println!(
            "fresh-cleanup stage scenario={scenario} policy_ms={policy_ms} statement_ms={statement_ms} transaction_ms={transaction_ms}"
        );
        let org = OrgId::from_uuid(Uuid::new_v4());
        seed_org_and_super_admin(&owner, *org.as_uuid(), "fresh-abort-cleanup").await;
        let descriptor = admitted_fixture_descriptor(&owner, policy_ms).await;
        let label = format!("console-recovery-fresh-abort-{scenario}");
        let (pool, backend) = runtime_pool(&owner, &label).await;
        set_fresh_cleanup_timers(&pool, &backend, statement_ms, transaction_ms).await;
        let draft = StagePayrollDraft {
            org,
            outbox_event_id: Uuid::new_v4(),
            run_id: Uuid::new_v4(),
            period_start: Some(date!(2026 - 06 - 01)),
            period_end: Some(date!(2026 - 06 - 30)),
            connector: Some("m2".into()),
            job: Some("payroll_draft".into()),
        };
        let retry_draft = draft.clone();
        let port = required_port(pool.clone(), &descriptor);
        control("pause-replay");
        let resume = ResumeOnDrop;
        let started = tokio::time::Instant::now();
        let call = tokio::spawn(async move { port.stage(draft).await });
        sync_wait(&owner, &backend, &call).await;
        if statement_ms > 0 {
            assert!(
                started.elapsed() < Duration::from_millis(1_500),
                "FRESH_SYNCREP_TIMER_PREREQUISITE: fresh native witness arrived after the existing setup budget"
            );
        }
        call.abort();
        assert!(call.await.unwrap_err().is_cancelled());
        assert_fresh_capacity_retained(&owner, &pool, &backend, &descriptor, &retry_draft).await;
        assert_eq!(
            command_receipt_rows(&owner, org).await,
            json!({"receipts": [], "drafts": []}),
            "aborted caller must not expose the still-waiting native transaction"
        );
        replacement_after_fresh_recovery(&owner, &pool, &backend).await;
        drop(resume);
        let committed = command_receipt_rows(&owner, org).await;
        assert_eq!(committed["receipts"].as_array().unwrap().len(), 0);
        assert_eq!(committed["drafts"].as_array().unwrap().len(), 1);
        let mut retry_descriptor = descriptor.clone();
        retry_descriptor["timeout_ms"] = json!(15_000);
        let retry = required_port(pool.clone(), &retry_descriptor);
        assert!(!retry.stage(retry_draft).await.unwrap());
        let standby = standby_pool(&owner).await;
        assert_eq!(command_receipt_rows(&owner, org).await, committed);
        assert_eq!(command_receipt_rows(&standby, org).await, committed);
        standby.close().await;
        pool.close().await;
    }
}
