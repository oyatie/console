# App composition acceptance candidate — private source package

Immutable repository base: `3238e8c6369e41a22941fd3dee699414fff1b643`.
Author: `/root/capture_review`. Repository, migration, SQL, harness, Cargo and native runtime owner: `/root`. Independent prerequisite reviewer: `/root/inventory_repair`; final test approval remains required. This package is acceptance-test authoring, not an admitted implementation lane or runtime result.

The three tests are bound to the existing API/startup and worker-spawn boundaries. They require actual Business and Auth LOGIN credentials, the real observer installer, real app migrations including Apalis, Account custody finalization, actual `AppState::from_config`, and native primary/standby observations. Application queries do not borrow the SQLx superuser pool or use `SET ROLE`.

## Import scope and mechanical guide

`fixture.patch` changes only `tools/lanes/recovery/recovery_postgres.sh`. It adds one protected generated Auth password and URL, then copies the existing CI password-only initialization after the existing canonical-enforce migrated probe. The copied block substitutes only `"${container_name}"` with `"$primary"`; role capabilities, memberships and persistent relation owners/ACLs are compared before and after. It neither creates nor enables the Auth role and adds no grants. Its exact inverse restores every original harness byte. Keep original mode `100755`.

`acceptance.patch` adds `backend/app/src/durability_composition_tests.rs`, two cfg/module lines in `backend/app/src/lib.rs`, and one explicit `test-recovery = ["test-postgres"]` feature in `backend/app/Cargo.toml`. No dependency, lockfile, migration, product implementation or authority record changes are included. Original library/manifest bytes are preserved after removing these exact additions. The module is compiled only by `all(test, feature = "test-recovery")`; ordinary `test-postgres` and the current Buck single-node suite exclude it. The explicit recovery feature includes the existing PostgreSQL feature for supported app fixture behavior.

The root should inspect the manifest, recheck regular-blob preimages against the exact proposed integration candidate, independently review tests and fixture, and import those two patches serially. All final evidence must bind to the resulting reviewed test commit. An apply-clean later head is not automatically equivalent to the base. Do not overwrite concurrent edits or use this package's whole library image to replace the checkout.

`constructor-design.patch` is a SEPARATE OPTIONAL DESIGN PROPOSAL against the acceptance postimage. It extracts the existing production `workflow_drain::spawn(pool.clone(), state.postgres_durability())` expression into a tiny private function and routes the worker test through that function. It takes no independent config, policy override, callback, test flag or new public API. It is not part of the acceptance import, not an approved implementation and not needed to compile these tests on the current code. The current tests prove existing `spawn` propagation from admitted state; source inspection separately establishes the current production caller expression. Neither variant runs all of `run_dispatch_worker` or proves its unrelated worker infrastructure.

## Exact authored cases

1. `durability_composition_tests::required_app_startup_admits_only_the_installed_observer`: actual API/Worker startup accepts the installed observer; committed missing Business EXECUTE, mismatched native system ID and primary epoch receive specific bounded durability UNKNOWN config refusal; restoring the exact observer profile permits startup; missing policy is rejected before an unreachable transport.
2. `durability_composition_tests::required_api_projected_payroll_dispatch_waits_for_remote_apply`: two distinct real authenticated principals author, review, approve and publish a projected payroll type through actual HTTP; actual app dispatch creates one local draft/receipt but cannot return HTTP success or canonical success audit before observed remote apply; identical replay preserves one draft, receipt and audit.
3. `durability_composition_tests::required_workflow_spawn_keeps_unknown_staging_pending_until_retry`: the actual M2 engine emits one pending payroll job; existing app worker `spawn` reaches the actual staging owner and native observer; bounded UNKNOWN discards that exact backend while preserving the local draft and pending event without audit/ACK; shutdown and pool closure precede fresh spawn, which restages the identical draft and acknowledges once. No canonical receipt is created by staging.

## Native witness correction to the frozen outline

Frozen outline: `/private/tmp/payroll-app-composition-3238e8c6-design-v1-capture/DESIGN.md`, SHA256 `f941dba63f1249fcb1ae07e67f5eff83990829a83f35bb77df6b09f5a376295f`.

During authoring, source inspection found `drain_payroll_job_outbox` phase 1 uses `SELECT ... FOR UPDATE SKIP LOCKED` before invoking staging (`workflow/adapter-postgres/src/lib.rs:787–801`). Its lock transaction can produce WAL; a first generic Business SyncRep waiter cannot truthfully identify the payroll staging owner. Root agreed to the narrower native witness correction. Root also reported an independent native cleanup investigation; this package makes no claim to reproduce that evidence.

Both consumers now pause replay, clear the synchronous policy before the real request/spawn, and require the actual owner's `console_durability_observe_v1` query plus real local effects and an independently observed paused standby below the local WAL bound. Success/audit/ACK remain executable at the transport layer, so a Local policy substitution cannot be hidden by a later synchronous audit or ACK COMMIT. The test does not require redundant native SyncRep as an implementation mechanism. Independent source review found that PostgreSQL retains idle last-query text; v2 therefore captures `clock_timestamp()` immediately before the request/spawn and requires the observer query `query_start` to follow that boundary, together with exact PID/backend-start/application-name identity. Idle samples remain valid between native polling queries; requiring only fleeting active-query samples would add a timing flake. This is confirmation-phase evidence, not an assertion that the sampled SQL is still executing; API response/pending worker evidence supplies the progress constraint. Frozen v1 remains historical at `/private/tmp/payroll-app-composition-3238e8c6-tests-v1-capture` (manifest SHA256 `61b9964f9bc42091e0e87d4983503bb37594ceacf85994e748f0c6605d69efe0`). There is no synthetic owner, injected registry, direct payroll stage invocation or relaxed remote-success requirement. Worker UNKNOWN completion additionally requires the exact native backend identity to disappear, then closes the whole first state/pool before retry. A timer alone is not a cleanup witness.

## Root-only verification plan

No Cargo, typecheck, Docker or PostgreSQL was run by the author. Static SQLx attributes authored: **3**. Runtime-discovered tests: **not run**. Runtime-executed tests: **0**. Syntax and private patch-integrity checks are listed in `verification.json`.

After independent approval and serialized fixture import, root can discover with this command from the repository root, preserving its owned build/cache lease:

```sh
cargo test --locked --manifest-path backend/Cargo.toml -p console-app --lib --features test-recovery durability_composition_tests:: -- --list
```

Each exact test must execute under its OWN fresh recovery-supervisor invocation. The observer role is cluster-global while each SQLx test database needs its own local function; running the three tests in a single supervised cluster violates their initial absent-profile admission. Use the existing supervisor and per-test command, for example from the repository root:

```sh
CONSOLE_RECOVERY_CUT= python3 tools/lanes/recovery/supervise_recovery.py "$PWD" -- cargo test --locked --manifest-path backend/Cargo.toml -p console-app --lib --features test-recovery durability_composition_tests::required_app_startup_admits_only_the_installed_observer -- --exact --test-threads=1 --nocapture
```

All three exact invocations are in the syntax-checked private `run-composition-cases.sh` and machine-readable `reachability-plan.json`. Root can execute the runner with the candidate repository path after review. It invokes one fresh existing supervisor per exact case and propagates any failure. It is an operator verification artifact, not a replacement CI check. Root must separately wire the three exact commands into the existing CI recovery facet and extend its strict invocation recognizer/check-executed-tests source mapping; current recognition assumes the payroll recovery binary and rejects app commands. The concrete required paths and command shapes are recorded in `reachability-plan.json`. Feature gating alone is not CI reachability, and CI integration remains HOLD until those serialized changes are reviewed and demonstrated. Record the tested HEAD, protected image/topology evidence, exact command, discovered/executed count, complete failure and cleanup evidence, and each case result. Fixture/auth/schema/compile failure is a prerequisite failure, not the behavioral RED needed for implementation admission. Missing, green or non-executable probes stop implementation admission. If code already passes, retain it as characterization rather than inventing a RED. Any semantic test revision needs a fresh immutable artifact and independent review.

## Scope, risk and stop conditions

Lenses: Cartesian doubt, Essentialism, Systems Thinking, Red Team, Operability / Day-2, Blast radius, Zero trust.

Pre-mortem: an absent Auth transport could impersonate an app regression; migration ownership handoff could lose observer identity; owner-created fixtures could mask role failures; later audit/ACK commits could mask missing Required propagation; a generic SyncRep waiter could be misattributed; a pending worker could write after retry starts. Detection: real login/startup prerequisites, exact closed observer readback, real HTTP and engine boundaries, specific native confirmation evidence, unchanged before/after snapshots, exact backend departure, first-pool closure and fresh spawn.

Blast radius: three test cases, one explicit feature, one cfg declaration and a synthetic owned-harness password initialization. No production SQL changes, role grant changes, production exposure, payroll calculation, canonical owner repair or worker cadence change. Local drafts remain blocked and calculation disabled.

Rollback: before integration, discard only this unimported private candidate; after integration, root reverts only its reviewed test/fixture commit while preserving prior evidence and concurrent changes. Runtime fixture cleanup remains the existing owned supervisor's responsibility; each test restores replay and synchronous policy via its guard. No shared-workspace destructive Git operations.

Stop on a changed preimage, absent real-role credential, wrong marked database custody, observer drift, missing native witness, unrelated fixture failure, discovered/executed-count mismatch, leaked owned resources or review rejection. Remaining HOLDs: independent final test approval, serialized CI/reachability integration, compile/discovery, native runtime of all three exact cases, any later implementation lane, optional constructor proposal, merge/release/production authority.

## V3 integration correction

Independent Fast review of frozen v2 found that `test-postgres` enrolls all three cases in ordinary single-node CI and Buck app suites. V3 preserves the complete test module byte-for-byte and changes only feature enrollment plus its explicit execution plan. Frozen v2 remains historical at `/private/tmp/payroll-app-composition-3238e8c6-tests-v2-capture` (manifest SHA256 `b09cb2a1dbdc9b8db84a6e5aa125b5a393440f6e0983ff71103937895f20ad07`). The bounded prerequisite/timestamp receipt is `/private/tmp/payroll-app-composition-v2-prerequisites-review-inventory/review.json` (`fb672c78f3d5e66944b9d3bfd7c5a372539f70368e568c3a9b3bdaa1eac3c7d8`); the whole v2 source review is `/private/tmp/payroll-app-composition-v2-independent-fast/review.json` (`6e69a4fbe00ee4ccc1e344ebf0a163bd0e0278aac276c8663e0db0ef20cae6ab`). Both are source-only and neither approves unexecuted runtime or a new Required COMMIT design. V3 is a fresh candidate requiring its own final review.
