#[sqlx::test(migrations = "../../platform/db/migrations")]
async fn fresh_stage_transport_error_closes_pool_before_reconciliation(owner: PgPool) {
    let org = OrgId::from_uuid(Uuid::new_v4());
    seed_org_and_super_admin(&owner, *org.as_uuid(), "fresh-transport-cleanup").await;
    let descriptor = admitted_fixture_descriptor(&owner, 5_000).await;
    let (pool, backend) = runtime_pool(&owner, "console-recovery-fresh-transport").await;
    let draft = StagePayrollDraft {
        org,
        outbox_event_id: Uuid::new_v4(),
        run_id: Uuid::new_v4(),
        period_start: Some(date!(2026 - 06 - 01)),
        period_end: Some(date!(2026 - 06 - 30)),
        connector: Some("m2".into()),
        job: Some("payroll_draft".into()),
    };
    let retry_draft = draft.clone();
    let port = required_port(pool.clone(), &descriptor);
    control("pause-replay");
    let resume = ResumeOnDrop;
    let call = tokio::spawn(async move { port.stage(draft).await });
    sync_wait(&owner, &backend, &call).await;
    // Fault injection is confined to the fixture operator and the exact
    // witnessed backend. The production runtime receives no terminate grant.
    let terminated: Option<bool> = sqlx::query_scalar(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid=$1 AND backend_start=$2 AND datname=current_database() AND application_name=$3 AND usename='console_rt' AND wait_event='SyncRep'",
    )
    .bind(backend.pid)
    .bind(backend.started)
    .bind(&backend.application_name)
    .fetch_optional(&owner)
    .await
    .unwrap();
    assert_eq!(terminated, Some(true));
    let error = tokio::time::timeout(Duration::from_secs(2), call)
        .await
        .expect("FRESH_SYNCREP_TRANSPORT: owner did not report the terminated COMMIT transport")
        .unwrap()
        .unwrap_err();
    assert_eq!(error.kind, console_kernel_core::ErrorKind::Internal);
    assert!(
        error.message.starts_with("database durability UNKNOWN:"),
        "FRESH_SYNCREP_UNKNOWN: stage must retain the existing UNKNOWN error boundary: {error}"
    );
    // Request capacity immediately after UNKNOWN, while owned async cleanup
    // may still be running. A new physical connection is a failure, even if
    // the pool would later close. PoolClosed is the control under test; a
    // transport/ping error is not treated as proof that the server backend died.
    let acquisition = tokio::time::timeout(Duration::from_secs(2), pool.acquire())
        .await
        .expect(
            "FRESH_SYNCREP_FAIL_CLOSED: transport-error cleanup did not close the original pool",
        );
    assert!(
        matches!(acquisition, Err(sqlx::Error::PoolClosed)),
        "FRESH_SYNCREP_FAIL_CLOSED: original pool must refuse replacement capacity with PoolClosed"
    );
    assert!(pool.is_closed());
    let committed = command_receipt_rows(&owner, org).await;
    assert_eq!(committed["receipts"].as_array().unwrap().len(), 0);
    assert_eq!(committed["drafts"].as_array().unwrap().len(), 1);
    control("resume-replay");
    drop(resume);
    // Recovery requires an explicit fresh pool and the unchanged policy.
    let (retry_pool, _) = runtime_pool(&owner, "console-recovery-fresh-transport-retry").await;
    let retry = required_port(retry_pool.clone(), &descriptor);
    let restaged = tokio::time::timeout(Duration::from_secs(7), retry.stage(retry_draft))
        .await
        .expect("FRESH_SYNCREP_RECONCILIATION: fresh pool did not resolve the committed draft")
        .unwrap();
    assert!(!restaged);
    let standby = standby_pool(&owner).await;
    assert_eq!(command_receipt_rows(&owner, org).await, committed);
    assert_eq!(command_receipt_rows(&standby, org).await, committed);
    assert!(pool.is_closed());
    standby.close().await;
    retry_pool.close().await;
    pool.close().await;
}
