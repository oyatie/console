Private composition CI/checker candidate. Author: /root/capture_review.
Exact base: f0431013b3795ae88c75f02c326fa08e93a71b6d.

Owned immutable postimages: tools/buck/test_preparation_wiring.py;
scripts/lib/recovery-test-invocations.mjs and .test.mjs;
scripts/check-executed-tests.mjs and .test.mjs. The private runner is copied
unchanged from the frozen V3 test candidate. Root owns actual integration,
workflow, baseline, generated files, Cargo and all DB/Docker resource leases.
Fast owns scripts/check-ci-preflight.mjs and .test.mjs, which are excluded.

Mechanical guide: apply the five-file patch after independently approved V3
acceptance sources and renamed retained-capacity test. Append the three exact
V3 app supervisor commands after the isolated observer in distinct CI steps;
retain the existing recovery condition. Root must pin the new test-recovery
binary variant and update source-attribute baseline from actual discovery.
No production change, constructor proposal, Cargo dependency, or fixture change
is included in this patch. All runtime checks remain root-owned and unexecuted.

Pre-mortem: falsely acknowledge app coverage via the ordinary one-node feature,
a substring filter, a shared supervisor, a hidden fourth test, or an incomplete
feature/cfg source declaration. Detection: exact closed-union source discovery,
full command shape, separate-step checks and hostile mutations.
Blast radius: preparation reachability checks and their source-only fixtures.
Rollback: revert this patch only; keep historical failed test evidence.
Stop: semantic test-source mutation, loss of old controls, product behavior
changes, unbound Cargo discovery or resource lease conflict.
Lenses: Cartesian doubt, Essentialism, Chesterton's Fence, Red Team,
Operability / Day-2, Blast-radius / cell-based, Zero-trust / defense-in-depth.
Independent reviewer: pending. Final hashes and exact counts: manifest.json.
HOLD: admitted import, Cargo discovery/execution, final-SHA CI, production,
public UNKNOWN protocol and global/frozen-backend cleanup claims.
