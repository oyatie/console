Private composition CI/checker candidate. Author: /root/capture_review.
Exact base: f0431013b3795ae88c75f02c326fa08e93a71b6d.

Owned immutable postimages: tools/buck/test_preparation_wiring.py;
scripts/lib/recovery-test-invocations.mjs and .test.mjs;
scripts/check-executed-tests.mjs and .test.mjs. The private runner is copied
unchanged from the frozen V3 test candidate. Root owns actual integration,
workflow, baseline, generated files, Cargo and all DB/Docker resource leases.
Fast owns scripts/check-ci-preflight.mjs and .test.mjs, which are excluded.

Mechanical guide: apply the five-file patch after independently approved V3
acceptance sources and renamed retained-capacity test. Append the three exact
V3 app supervisor commands after the isolated observer in distinct CI steps;
retain the existing recovery condition. Root must pin the new test-recovery
binary variant and update source-attribute baseline from actual discovery.
No production change, constructor proposal, Cargo dependency, or fixture change
is included in this patch. All runtime checks remain root-owned and unexecuted.

Pre-mortem: falsely acknowledge app coverage via the ordinary one-node feature,
a substring filter, a shared supervisor, a hidden fourth test, or an incomplete
feature/cfg source declaration. Detection: exact closed-union source discovery,
full command shape, separate-step checks and hostile mutations.
Blast radius: preparation reachability checks and their source-only fixtures.
Rollback: revert this patch only; keep historical failed test evidence.
Stop: semantic test-source mutation, loss of old controls, product behavior
changes, unbound Cargo discovery or resource lease conflict.
Lenses: Cartesian doubt, Essentialism, Chesterton's Fence, Red Team,
Operability / Day-2, Blast-radius / cell-based, Zero-trust / defense-in-depth.
Independent reviewer: pending. Final hashes and exact counts: manifest.json.
HOLD: admitted import, Cargo discovery/execution, final-SHA CI, production,
public UNKNOWN protocol and global/frozen-backend cleanup claims.

V2 corrects independently disproved V1 lexical source admission. V1 and the
review receipt0933ba82d25426f3929eff57b793c33a96acfeacf62e12e0caf8fe073b8cdbd0
remain immutable. Reuse the existing Rust comment/literal stripper; require
exactly three supported SQLx test attributes with reviewed top-level names,
refuse cfg/cfg_attr/ignore changes in this fixed module, and verify the live
lib.rs declaration and its exact reviewed guard. Python uses the same exported
oracle, avoiding a second lexical implementation. New hostile controls cover
extra Tokio/plain tests, module/test disabling or ignore, nested cases,
comment/literal spoofed cases and comment/literal/additional module guards.
These are narrowly scoped lexical invariants, not arbitrary Rust macro/cfg
evaluation. Root must still record actual Cargo discovery and each supervisor's
exactly one executed, zero ignored result, plus ordinary-feature exclusion.

V3 follows root's request to correct the responsible mechanism for every
supervised source. The same exported supervisedSourceCases(source, expected,
modulePrefix) checks owner9, observer1 and app3; each family has the full
extra-test/cfg/cfg_attr/ignore/nesting and comment/literal spoof control matrix.
The app live lib guard remains separate. V2's app fix was independently reviewed
without another app blocker, but its legacy raw owner/observer census retained
the same six demonstrated bypasses. V2 is superseded and stays immutable.
No public/product contract, workflow, generated baseline or test source changed.
