# Private full Auth REST206 evidence driver

Owner: /root/fast_gate_review, private evidence tooling only. /root remains sole repository writer and Cargo/PostgreSQL/Docker runtime operator. No source lane, test change, product feature, migration, generated file, lockfile, or authority record is changed by this candidate.

Exact test-source base: 9fa5cc7bed1d957ea5c4a650c103b0763f46f5c4. Runtime captures the later integrated clean HEAD supplied to the Bash driver; 9fa is roster provenance, not a requirement to run an obsolete implementation. Immutable target: this candidate directory at the SHA256 hashes in metadata.json. Edits after review require a new candidate revision and independent review.

Mechanical guide

1. Verify every metadata.json artifact hash before running, and retain the independent review receipt outside this frozen directory.
2. Run only under root-owned runtime authorization/resource scheduling, from the approved integrated clean worktree. No standalone Cargo command, discovery run, selector, test skip, or test mutation is introduced.
3. Exact adapter invocation: python3 /private/tmp/account-auth-rest-full206-driver-9fa5cc7b/probe.py
4. The adapter creates a unique /private/tmp/account-auth-rest-full206-<uuid> evidence directory and invokes the existing harness exactly once: bash tools/ci/cargo_needs_postgres.sh --map <run>/postgres-map.json --only app-auth-rest-pg --num-threads 1
5. The only executed test argv remains exactly: cargo test --locked --manifest-path backend/Cargo.toml -p console-app --test auth_rest -- --test-threads=1
6. Preserve the whole source map. --only selects its wrapper; there is no Rust test filter. The existing seven-argument console-app prebuild interception appends only --test auth_rest and must occur exactly once.
7. Inspect full-test-results.json and the original probe.log together. Exit0 plus COMPLETE_FULL_AUTH_REST_EXECUTION means all206 exact named tests passed. Exit1 plus that classification means exactly206 ran with failures; inspect the first causal assertion of each failure before making behavioral-RED claims. Incomplete discovery, prerequisites, source/receipt/hash discrepancies, or cleanup failures classify INCOMPLETE_OR_PREREQUISITE_FAILURE and return126.
8. Verify metadata artifact hashes again after execution. Retain the run's before/after source snapshots, receipt, copied map, exact source HEAD, ownership/cleanup artifacts, and raw log. Independent runtime review remains required.

Evidence boundary

The roster is the disjoint union of191 exact names from the prior completed unfiltered runtime log and15 committed tests (3terms_read,10terms_current,2terms_read_security). All206 names and the roster SHA256 are pinned in expected-cases.json/probe.py; roster-provenance.json records source commit, exact files/hashes, and prior run hashes. Root's separate static196 inventory is not a runtime count and is not used to approximate generated Rust test names. Require exactly206 unique case lines/discovery, zero ignored/measured/filtered, one exact invocation/argv/timing/final wrapper roster/rollup, and a matching exit.

The approved V2 bounded Docker adapter, every-rm exact name/ownership-label check, original harness storage, and independent successful final absence listing are unchanged. The only driver edits are the run-label prefix, adding the historical terms-guard SQL to the snapshot, and removing the three-case selector. Snapshot closure includes all tracked backend Rust/Cargo.toml/BUCK files plus explicit manifests/toolchain/lock/harness/custody SQL and all three historical fixtures. Probe validation also requires those fixtures and mandatory receipt artifacts.

Pre-mortem and controls

- Wrong/duplicate/missing cases, hidden filters, or a partial invocation could masquerade as full coverage. Strict206 parser controls reject each; the prior191 result cannot satisfy this driver.
- Mutable roster or mismatched source/evidence could invalidate attribution. Pin the roster hash, private pre/post hashes, exact clean source snapshots, required receipt artifact hashes, and historical fixture presence; fail closed on discrepancy.
- A failed launch could collide with a foreign container. Retain approved exact recorded-name plus successful current-run-label inspection before any removal; bounded final listing must independently prove absence. No broad cleanup is authorized.
- Blast radius: one labeled temporary PostgreSQL container, existing Cargo cache, and a new private evidence directory; no product source writes. This is harness evidence, not durability or production-exposure proof.
- Detection: 61 simulated controls, Bash syntax, and Python compile checks passed. Controls execute fake Docker only; actual Cargo/database/Rust runtime counts are zero.
- Rollback: stop use of this candidate and retain it and any run evidence. Do not use destructive Git or unscoped Docker cleanup. Root handles any owned-container recovery using exact recorded name and verified current-run label.
- Stop conditions: missing independent review, changed candidate hashes, unclean source, changed original argv, source/receipt/hash mismatch, unexpected runtime roster/count/filter, prerequisite failure, or unverifiable cleanup. Preserve evidence and report the specific condition.

Reasoning lenses: Cartesian doubt; Essentialism / YAGNI; Red Team; Operability / Day-2; Blast-radius / cell-based; Zero-trust / defense-in-depth. These guide narrow evidence classification and bounded deletion review; no claim of production or legal authority follows.

Review identities: author /root/fast_gate_review; independent reviewer requested /root/inventory_repair; runtime operator /root. Remaining HOLDs: independent candidate review, integrated clean-HEAD runtime execution, actual cleanup proof, and independent runtime/failure-causality review. No runtime was executed during candidate preparation.
