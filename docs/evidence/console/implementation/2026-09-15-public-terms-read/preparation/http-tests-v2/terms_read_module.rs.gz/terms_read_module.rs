
    // Public read acceptance only. The fixture administrator models sequential
    // TEST_ONLY release states; these tests confer no publication authority.
    mod terms_read {
        use super::*;

        #[sqlx::test(migrations = false)]
        async fn current_head_and_retained_bytes_are_authoritative_and_read_only(pool: PgPool) {
            let app = fixture(&pool).await;
            let before = terms_reference_rows(&pool).await;
            assert_current_terms(&app, 1).await;
            assert_retained_artifacts(&app).await;

            let unsupported = "f".repeat(64);
            assert!(unsupported != MANIFEST_DIGEST);
            for kind in ["manifests", "content"] {
                request(
                    &app,
                    "GET",
                    &format!("/api/v2/auth/terms/{kind}/{unsupported}"),
                    &Cookies::default(),
                    None,
                    &[],
                )
                .await
                .error(StatusCode::NOT_FOUND, "not_found");
            }
            assert!(terms_reference_rows(&pool).await == before);

            // The same bytes at a later authoritative revision cannot be served
            // with a stale revision chosen from the local artifact index.
            let (_, revision) = seed_next_terms_head(&pool, MANIFEST_DIGEST).await;
            assert_eq!(revision, 2);
            let advanced = terms_reference_rows(&pool).await;
            assert_current_terms(&app, revision).await;
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == advanced);

            // An unsupported current head closes current authority while exact
            // previously registered immutable bytes remain publicly readable.
            let (_, revision) = seed_next_terms_head(&pool, &unsupported).await;
            assert_eq!(revision, 3);
            let unavailable = terms_reference_rows(&pool).await;
            request(
                &app,
                "GET",
                "/api/v2/auth/terms",
                &Cookies::default(),
                None,
                &[],
            )
            .await
            .error(StatusCode::SERVICE_UNAVAILABLE, "authority_unavailable");
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == unavailable);
        }

        #[sqlx::test(migrations = false)]
        async fn registered_content_loss_and_restore_preserve_public_read_state(pool: PgPool) {
            let mut app = fixture(&pool).await;
            let before = terms_reference_rows(&pool).await;
            assert_current_terms(&app, 1).await;
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == before);

            let lost_path = app._artifacts.root.join("fixtures/privacy.txt");
            assert!(std::fs::read(&lost_path).unwrap() == PRIVACY_TEXT.as_bytes());
            std::fs::remove_file(&lost_path).unwrap(); // Only this fixture-owned file.
            // Match the existing outage fixture. This does not require live
            // invalidation of already verified immutable bytes in a running router.
            app.service = router(&pool, app._artifacts.root.clone()).await;
            let digest = manifest()["items"][1]["content_sha256"]
                .as_str()
                .unwrap()
                .to_owned();
            for path in [
                format!("/api/v2/auth/terms/content/{digest}"),
                "/api/v2/auth/terms".to_owned(),
            ] {
                request(&app, "GET", &path, &Cookies::default(), None, &[])
                    .await
                    .error(StatusCode::SERVICE_UNAVAILABLE, "authority_unavailable");
            }
            assert!(terms_reference_rows(&pool).await == before);

            std::fs::write(&lost_path, PRIVACY_TEXT.as_bytes()).unwrap();
            app.service = router(&pool, app._artifacts.root.clone()).await;
            assert_current_terms(&app, 1).await;
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == before);
        }

        #[sqlx::test(migrations = false)]
        async fn auth_database_outage_closes_current_authority_but_retains_public_bytes(
            pool: PgPool,
        ) {
            let mut app = fixture(&pool).await;
            let auth_url = account_transport_urls(&pool)
                .into_iter()
                .find(|(key, _)| *key == "AUTH_DATABASE_URL")
                .expect("existing restricted Auth fixture transport")
                .1;
            let auth = PgPool::connect(&auth_url)
                .await
                .expect("connect genuine restricted Auth fixture transport");
            let role: String = sqlx::query_scalar("SELECT current_user")
                .fetch_one(&auth)
                .await
                .unwrap();
            assert_eq!(role, "console_auth_rt");
            let state = state_with_key(
                &pool,
                app._artifacts.root.clone(),
                &SigningKey::random(&mut OsRng),
            )
            .await;
            app.service = build_router(state.with_auth_database(auth.clone()));
            let before = terms_reference_rows(&pool).await;
            assert_current_terms(&app, 1).await;
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == before);

            // Close this actual Auth transport only; the fixture administrator
            // and immutable artifact reads remain available for the oracle.
            auth.close().await;
            request(
                &app,
                "GET",
                "/api/v2/auth/terms",
                &Cookies::default(),
                None,
                &[],
            )
            .await
            .error(StatusCode::SERVICE_UNAVAILABLE, "authority_unavailable");
            assert_retained_artifacts(&app).await;
            assert!(terms_reference_rows(&pool).await == before);
        }
    }
