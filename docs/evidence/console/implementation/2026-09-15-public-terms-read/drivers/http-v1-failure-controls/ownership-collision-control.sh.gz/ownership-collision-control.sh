docker() {
  local name='' previous='' argument='' matched_image=0
  if [[ "${1:-}" == run ]]; then
    for argument in "$@"; do
      [[ "${previous}" != --name ]] || name="${argument}"
      [[ "${argument}" != "${FENCE_IMAGE}" ]] || matched_image=1
      previous="${argument}"
    done
  fi
  if [[ "${1:-}" == run && "${name}" == console-cargo-postgres-* && "${matched_image}" == 1 ]]; then
    [[ ! -e "${FENCE_CONTAINER_RECORD}" ]] || { echo 'unexpected second scoped container' >&2; return 2; }
    printf '%s\n' "${name}" > "${FENCE_CONTAINER_RECORD}"
    command docker run --label "console.evidence=${FENCE_LABEL}" "${@:2}"
  else
    command docker "$@"
  fi
}
docker run --name console-cargo-postgres-review-collision "$FENCE_IMAGE"
launch_exit=$?
docker rm -f console-cargo-postgres-review-collision
cleanup_exit=$?
printf 'launch_exit=%s cleanup_exit=%s\n' "$launch_exit" "$cleanup_exit"
