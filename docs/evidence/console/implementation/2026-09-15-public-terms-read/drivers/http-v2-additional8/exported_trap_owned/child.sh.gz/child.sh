trap 'docker rm -f "$CAPTURE_CONTAINER"' EXIT
docker run --name "$CAPTURE_CONTAINER" "$FENCE_IMAGE"
