docker_bounded() {
  python3 - "$@" <<'PYBOUND'
import subprocess,sys
try:
    result=subprocess.run(['docker',*sys.argv[1:]],capture_output=True,timeout=30)
    sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
    raise SystemExit(result.returncode)
except subprocess.TimeoutExpired as error:
    if error.stdout:sys.stdout.buffer.write(error.stdout)
    if error.stderr:sys.stderr.buffer.write(error.stderr)
    print('bounded Docker command timed out',file=sys.stderr)
    raise SystemExit(124)
PYBOUND
}

docker() {
  local name='' previous='' argument='' matched_image=0 label=''
  if [[ "${1:-}" == rm ]]; then
    # The original harness EXIT trap also passes through this wrapper. A failed
    # launch can leave a foreign same-name container, so name alone is not custody.
    if [[ $# != 3 || "${2:-}" != -f || ! -f "${FENCE_CONTAINER_RECORD}" ]]; then
      echo 'refused unexpected Docker removal' >&2
      return 2
    fi
    name="$(cat "${FENCE_CONTAINER_RECORD}")"
    if [[ "${name}" != console-cargo-postgres-* || "${3:-}" != "${name}" ]]; then
      echo 'refused unrecorded Docker removal' >&2
      return 2
    fi
    if ! label="$(docker_bounded inspect --format '{{index .Config.Labels "console.evidence"}}' "${name}")"; then
      echo 'refused Docker removal without successful ownership inspection' >&2
      return 2
    fi
    if [[ "${label}" != "${FENCE_LABEL}" ]]; then
      echo 'refused Docker removal with foreign ownership label' >&2
      return 2
    fi
    docker_bounded rm -f "${name}"
    return $?
  fi
  if [[ "${1:-}" == run ]]; then
    for argument in "$@"; do
      [[ "${previous}" != --name ]] || name="${argument}"
      [[ "${argument}" != "${FENCE_IMAGE}" ]] || matched_image=1
      previous="${argument}"
    done
  fi
  if [[ "${1:-}" == run && "${name}" == console-cargo-postgres-* && "${matched_image}" == 1 ]]; then
    [[ ! -e "${FENCE_CONTAINER_RECORD}" ]] || { echo 'unexpected second scoped container' >&2; return 2; }
    printf '%s\n' "${name}" > "${FENCE_CONTAINER_RECORD}"
    command docker run --label "console.evidence=${FENCE_LABEL}" "${@:2}"
  else
    command docker "$@"
  fi
}
export -f docker docker_bounded
bash "$CAPTURE_CHILD"
