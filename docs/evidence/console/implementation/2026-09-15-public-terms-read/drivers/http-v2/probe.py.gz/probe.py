#!/usr/bin/env python3
"""Bounded evidence adapter around the existing PostgreSQL harness, not a product implementation."""
import collections
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import uuid

EXPECTED = {
    'account_browser::terms_read::current_head_and_retained_bytes_are_authoritative_and_read_only',
    'account_browser::terms_read::registered_content_loss_and_restore_preserve_public_read_state',
    'account_browser::terms_read::auth_database_outage_closes_current_authority_but_retains_public_bytes',
}
COMMAND = 'cargo test --locked --manifest-path backend/Cargo.toml -p console-app --test auth_rest account_browser::terms_read:: -- --test-threads=1'


def validate(text, exit_code):
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    found = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    counts = collections.Counter(status for _, status in found)
    assert len(found) == 3 and {name for name, _ in found} == EXPECTED, 'missing/duplicate/foreign case'
    assert counts['ignored'] == 0, 'ignored case'
    assert re.findall(r'^running(?:[ \t].*)?$', text, re.M) == ['running 3 tests'], 'discovery mismatch'
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    assert len(re.findall(r'^test(?:[ \t].*)?$', text, re.M)) == len(found) + len(summaries), 'unmatched test record'
    assert len(summaries) == 1 and summaries[0][:5] == ('FAILED' if counts['FAILED'] else 'ok', str(counts['ok']), str(counts['FAILED']), '0', '0'), 'summary mismatch'
    # Selection is exactly these three cases. Full-binary inventory is separate;
    # retain its nonnegative filtered count without rejecting unrelated additions.
    filtered = int(summaries[0][5])
    assert re.findall(r'^cargo-postgres: === (.+) ===$', text, re.M) == ['app-auth-rest-pg'], 'invocation mismatch'
    assert re.findall(r'^cargo-postgres: (cargo test .*)$', text, re.M) == [COMMAND], 'argv mismatch'
    timing = [json.loads(line) for line in re.findall(r'^cargo-postgres-timing: (.+)$', text, re.M)]
    assert len(timing) == 1 and timing[0]['name'] == 'app-auth-rest-pg' and timing[0]['package'] == 'console-app', 'timing identity mismatch'
    assert timing[0]['status'] == ('fail' if counts['FAILED'] else 'pass'), 'timing outcome mismatch'
    assert re.findall(r'^cargo-postgres: (\d+) passed, (\d+) failed$', text, re.M) == [('0', '1') if counts['FAILED'] else ('1', '0')], 'rollup mismatch'
    assert re.findall(r'^  (PASS|FAIL)  (.+)$', text, re.M) == [('FAIL' if counts['FAILED'] else 'PASS', 'app-auth-rest-pg')], 'final roster mismatch'
    assert exit_code == (1 if counts['FAILED'] else 0), 'harness exit mismatch'
    return {'executed': 3, 'passed': counts['ok'], 'failed': counts['FAILED'], 'filtered': filtered, 'ignored': 0, 'cases': dict(found)}


def main():
    root = pathlib.Path.cwd()
    candidate = pathlib.Path(__file__).resolve().parent
    private = {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in ['driver.sh', 'probe.py']}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    run = pathlib.Path('/private/tmp/account-terms-read3-' + uuid.uuid4().hex)
    print(run, flush=True)
    code = subprocess.run(['bash', str(candidate / 'driver.sh'), str(root), head, str(run)]).returncode
    result = {'head': head, 'driver_exit': code, 'private_sha256': private}
    try:
        assert code in (0, 1), 'driver prerequisite failure'
        assert private == {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in private}, 'private source changed'
        before = json.loads((run / 'source-before.json').read_text())
        assert before == json.loads((run / 'source-after.json').read_text()) and before['head'] == head and not before['status_porcelain'], 'source snapshot mismatch'
        receipt = json.loads((run / 'driver-receipt.json').read_text())
        assert receipt['driver_sha256'] == private['driver.sh'] and receipt['probe_exit'] == code and receipt['prebuild_interception_count'] == 1, 'driver receipt mismatch'
        for name, digest in receipt['artifacts'].items():
            assert pathlib.Path(name).name == name and hashlib.sha256((run / name).read_bytes()).hexdigest() == digest, 'driver artifact changed'
        assert (run / 'cleanup.txt').read_text().strip() == 'confirmed owned container absent via successful bounded docker ps -a', 'cleanup incomplete'
        name = (run / 'container-name.txt').read_text().strip()
        assert name and name not in (run / 'containers-after.txt').read_text().splitlines(), 'owned container remains'
        assert not (run / 'cleanup-final-list-error.txt').read_text(), 'final listing error'
        result.update(validate((run / 'probe.log').read_text(), code))
        result['classification'] = 'COMPLETE_SELECTED_EXECUTION'
    except (AssertionError, OSError, ValueError, KeyError, TypeError) as error:
        result.update(classification='INCOMPLETE_OR_PREREQUISITE_FAILURE', detail=type(error).__name__ + ': ' + str(error))
        code = 126
    (run / 'selected-test-results.json').write_text(json.dumps(result, indent=2) + '\n')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
