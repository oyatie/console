import os, pathlib, subprocess, json, sys, hashlib, tempfile
root=pathlib.Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],text=True):sys.exit(126)
run=pathlib.Path(tempfile.mkdtemp(prefix='public-terms-openapi15-',dir='/private/tmp'))
paths=['backend/openapi/openapi.yaml','backend/crates/platform/auth-rest/src/lib.rs','backend/crates/platform/auth-rest/src/terms.rs','backend/app/tests/openapi_drift.rs']
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
argv=['cargo','test','--locked','--offline','--manifest-path','backend/Cargo.toml','-p','console-app','--test','openapi_drift']
overrides={'RUSTUP_TOOLCHAIN':'1.98.1','CARGO_TARGET_DIR':'/private/tmp/console-account30-cargo','SQLX_OFFLINE':'true'}
with (run/'probe.log').open('wb') as f:code=subprocess.run(argv,env=dict(os.environ,**overrides),stdout=f,stderr=subprocess.STDOUT).returncode
after=snapshot()
unchanged=before==after and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
(run/'receipt.json').write_text(json.dumps({'head':head,'argv':argv,'cwd':str(root),'environment':overrides,'cargo_exit':code,'unchanged':unchanged,'source_before':before,'source_after':after,'log_sha256':hashlib.sha256((run/'probe.log').read_bytes()).hexdigest()},indent=2)+'\n')
print(run)
sys.exit(code if unchanged else 126)
