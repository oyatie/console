#!/usr/bin/env python3
"""Bounded evidence adapter around the existing PostgreSQL harness, not a product implementation."""
import collections
import hashlib
import json
import pathlib
import re
import subprocess
from subprocess import CalledProcessError
import sys
import uuid

if not __debug__:
    print("probe prerequisite failure: optimized Python disables required guards", file=sys.stderr)
    raise SystemExit(126)

EXPECTED_ROSTER_SHA256 = '515732a24673f8520d0c80f7b8b189781cfbf6e18abd0124975341b9f2244eab'
ROSTER_PATH = pathlib.Path(__file__).resolve().parent / 'expected-cases.json'
try:
    assert hashlib.sha256(ROSTER_PATH.read_bytes()).hexdigest() == EXPECTED_ROSTER_SHA256, 'unreviewed expected roster'
    EXPECTED_NAMES = json.loads(ROSTER_PATH.read_text())
    assert len(EXPECTED_NAMES) == len(set(EXPECTED_NAMES)) == 216, 'invalid expected roster'
    EXPECTED = set(EXPECTED_NAMES)
except (AssertionError, OSError, ValueError, TypeError) as error:
    print('probe roster prerequisite failure: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
    raise SystemExit(126) from error
COMMAND = 'cargo test --locked --manifest-path backend/Cargo.toml -p console-app --test auth_rest -- --test-threads=1'
HISTORICAL_FIXTURES = {
    'backend/app/tests/auth_rest/fixtures/account-custody-dormant-v1-7af6dfd4.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-projection-v2-69e3ca9c.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-terms-guard-v3-7c599773.sql',
    'backend/app/tests/auth_rest/fixtures/account-custody-root-input-d66e2112.sql',
}
REQUIRED_ARTIFACTS = {
    'source-before.json', 'source-after.json', 'probe.log', 'probe-exit.txt',
    'postgres-map.json', 'prebuild-dispatch.txt', 'cleanup.txt',
    'ownership-label.txt', 'container-name.txt', 'containers-before-cleanup.txt',
    'containers-after.txt', 'cleanup-list-error.txt', 'cleanup-final-list-error.txt',
}


def validate(text, exit_code):
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    found = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    counts = collections.Counter(status for _, status in found)
    assert len(found) == 216 and {name for name, _ in found} == EXPECTED, 'missing/duplicate/foreign case'
    assert counts['ignored'] == 0, 'ignored case'
    assert re.findall(r'^running(?:[ \t].*)?$', text, re.M) == ['running 216 tests'], 'discovery mismatch'
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    assert len(re.findall(r'^test(?:[ \t].*)?$', text, re.M)) == len(found) + len(summaries), 'unmatched test record'
    assert len(summaries) == 1 and summaries[0][:5] == ('FAILED' if counts['FAILED'] else 'ok', str(counts['ok']), str(counts['FAILED']), '0', '0'), 'summary mismatch'
    filtered = int(summaries[0][5])
    assert filtered == 0, 'filtered cases are not a full-suite execution'
    assert re.findall(r'^cargo-postgres: === (.+) ===$', text, re.M) == ['app-auth-rest-pg'], 'invocation mismatch'
    assert re.findall(r'^cargo-postgres: (cargo test .*)$', text, re.M) == [COMMAND], 'argv mismatch'
    timing = [json.loads(line) for line in re.findall(r'^cargo-postgres-timing: (.+)$', text, re.M)]
    assert len(timing) == 1 and timing[0]['name'] == 'app-auth-rest-pg' and timing[0]['package'] == 'console-app', 'timing identity mismatch'
    assert timing[0]['status'] == ('fail' if counts['FAILED'] else 'pass'), 'timing outcome mismatch'
    assert re.findall(r'^cargo-postgres: (\d+) passed, (\d+) failed$', text, re.M) == [('0', '1') if counts['FAILED'] else ('1', '0')], 'rollup mismatch'
    assert re.findall(r'^  (PASS|FAIL)  (.+)$', text, re.M) == [('FAIL' if counts['FAILED'] else 'PASS', 'app-auth-rest-pg')], 'final roster mismatch'
    assert exit_code == (1 if counts['FAILED'] else 0), 'harness exit mismatch'
    return {'executed': 216, 'passed': counts['ok'], 'failed': counts['FAILED'], 'filtered': filtered, 'ignored': 0, 'cases': dict(found)}


def main():
    run = pathlib.Path('/private/tmp/account-auth-rest-full216-' + uuid.uuid4().hex)
    print(run, flush=True)
    result = {}
    try:
        root = pathlib.Path.cwd()
        candidate = pathlib.Path(__file__).resolve().parent
        private = {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in ['driver.sh', 'probe.py', 'expected-cases.json']}
        result['private_sha256'] = private
        assert private['expected-cases.json'] == EXPECTED_ROSTER_SHA256, 'expected roster hash mismatch'
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
        result['head'] = head
        code = subprocess.run(['bash', str(candidate / 'driver.sh'), str(root), head, str(run)]).returncode
        result['driver_exit'] = code
        assert code in (0, 1), 'driver prerequisite failure'
        assert private['expected-cases.json'] == EXPECTED_ROSTER_SHA256, 'expected roster hash mismatch'
        assert private == {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in private}, 'private source changed'
        before = json.loads((run / 'source-before.json').read_text())
        assert before == json.loads((run / 'source-after.json').read_text()) and before['head'] == head and not before['status_porcelain'], 'source snapshot mismatch'
        assert HISTORICAL_FIXTURES <= set(before['files']), 'historical fixture missing from snapshot'
        receipt = json.loads((run / 'driver-receipt.json').read_text())
        assert REQUIRED_ARTIFACTS <= set(receipt['artifacts']), 'required receipt artifact omitted'
        assert receipt['driver_sha256'] == private['driver.sh'] and receipt['probe_exit'] == code and receipt['prebuild_interception_count'] == 1, 'driver receipt mismatch'
        for name, digest in receipt['artifacts'].items():
            assert pathlib.Path(name).name == name and hashlib.sha256((run / name).read_bytes()).hexdigest() == digest, 'driver artifact changed'
        assert (run / 'cleanup.txt').read_text().strip() == 'confirmed owned container absent via successful bounded docker ps -a', 'cleanup incomplete'
        name = (run / 'container-name.txt').read_text().strip()
        assert name and name not in (run / 'containers-after.txt').read_text().splitlines(), 'owned container remains'
        assert not (run / 'cleanup-final-list-error.txt').read_text(), 'final listing error'
        result.update(validate((run / 'probe.log').read_text(), code))
        result['classification'] = 'COMPLETE_FULL_AUTH_REST_EXECUTION'
    except (AssertionError, OSError, ValueError, KeyError, TypeError, CalledProcessError) as error:
        result.update(classification='INCOMPLETE_OR_PREREQUISITE_FAILURE', detail=type(error).__name__ + ': ' + str(error))
        code = 126
        run.mkdir(mode=0o700, exist_ok=True)
        with (run / 'prerequisite-error.txt').open('x') as artifact:
            artifact.write(result['detail'] + '\n')
    with (run / 'full-test-results.json').open('x') as artifact:
        artifact.write(json.dumps(result, indent=2) + '\n')
    return code


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, CalledProcessError) as error:
        print('probe evidence-write prerequisite failure: ' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
        raise SystemExit(126) from error
