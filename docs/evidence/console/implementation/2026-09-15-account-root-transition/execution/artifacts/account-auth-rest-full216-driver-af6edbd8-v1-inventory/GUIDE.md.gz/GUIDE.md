# Private full Auth REST216 evidence adapter

Owner: /root/inventory_repair for this private candidate only. /root is the sole repository writer and Cargo/PostgreSQL/Docker runtime operator. No product, test, generated file, migration, lockfile, or authority-record edit is included.

Exact roster-source base: af6edbd8c47480928ce8be15312d054fbdfc5e2c. Immutable target: this directory at all metadata.json hashes. The existing full206 directory and historical results are preserved. Runtime captures the later integrated clean HEAD; the roster source is provenance, not a requirement to run an obsolete implementation.

## Mechanical guide

1. Independently review this candidate and verify every metadata.json artifact hash. Retain the reviewer receipt outside the frozen directory; any candidate edit requires a new revision and review.
2. Root alone schedules runtime from the approved integrated clean worktree, retaining the adapter's stdout/stderr as well as its run evidence. No standalone discovery, Cargo command, selector, test mutation, or skip is introduced.
3. Exact command: `python3 /private/tmp/account-auth-rest-full216-driver-af6edbd8-v1-inventory/probe.py`.
4. The adapter creates one unique `/private/tmp/account-auth-rest-full216-<uuid>` evidence directory and invokes `bash tools/ci/cargo_needs_postgres.sh --map <run>/postgres-map.json --only app-auth-rest-pg --num-threads 1` once.
5. Actual test argv stays exactly `cargo test --locked --manifest-path backend/Cargo.toml -p console-app --test auth_rest -- --test-threads=1`. The whole PostgreSQL map is retained; `--only` chooses its wrapper without filtering Rust tests. The exact seven-argument package prebuild interception appends only `--test auth_rest` and must occur exactly once. No `--offline` is added; inherited SQLX_OFFLINE remains true.
6. Exit0 plus `COMPLETE_FULL_AUTH_REST_EXECUTION` means all216 exact named cases passed. Exit1 with that classification means216 executed with failures; those failures remain untriaged. This adapter does not establish semantic RED admission. Read each original first causal diagnostic before any behavioral conclusion. Exit126/`INCOMPLETE_OR_PREREQUISITE_FAILURE` means the full evidence contract did not pass.
7. Read `full-test-results.json` with the raw `probe.log`, before/after source snapshots, driver receipt, copied map, exact HEAD, prebuild dispatch, and all ownership/cleanup artifacts. Recheck candidate hashes and obtain independent runtime/failure review.

## Evidence and change boundary

The roster is exactly206 unique historical runtime names plus10 disjoint committed sqlx tests, cross-checked against the approved test manifest. Require216 exact case lines, one216 discovery, zero ignored/measured/filtered, one exact command/invocation/timing/wrapper roster/rollup, and matching exit. The historical full206 run at0007132535578f7abdafeb5192cd07c38376f06d remains183PASS23FAIL. Later selected results cannot recalculate that historical result. Static lexical inventory is separate from runtime accounting.

The driver differs from full206 in two places only: label prefix and fourth historical SQL fixture snapshot. Its actual full test command, whole map, prebuild dispatch, image, storage, all Docker custody and cleanup behavior are byte-identical after normalizing those two edits. Tracked backend Rust/Cargo.toml/BUCK snapshot discovery already includes the new root-transition module. Explicit manifests/toolchain/lock/harness/custody SQL and all four historical fixtures are captured before/after. Implementation bytes are captured at the exact runtime HEAD and are not frozen to a pre-fix version.

The probe retains the full206 validator, changing only206 to216, and requires the fourth historical fixture. It reuses the independently approved transition10 V2 prerequisite envelope: refuse optimized Python with126, guard missing/malformed roster and private files, Git/driver failures, retain prerequisite diagnostics, and use exclusive evidence writes. No selected-test semantic boundary map or test-source hash binding is imported into the full-suite classifier.

## Pre-mortem, recovery, and proof limits

- Missing/duplicate/foreign cases, stale206 output, or hidden filters could falsely imply full coverage. Strict roster/count/argv checks reject them. Complete failures remain exit1, never green.
- Missing prerequisites, disabled assertions, changed private/source bytes, missing receipt artifacts, or absent historical input could invalidate attribution. Return126; preserve raw diagnostics and snapshots. Import-stage errors appear on stderr; later errors also retain `prerequisite-error.txt` where writable.
- A failed launch could collide with a foreign container. Every removal retains exact recorded-name and successful current-run ownership-label inspection. A bounded successful final listing must independently prove absence. No broad cleanup is authorized.
- Blast radius is one owned labeled temporary PostgreSQL container, the existing Cargo cache, and a new private evidence directory. There are no product writes or durability/production-exposure claims.
- Detection: 74/74 synthetic controls (parser38, roster_import2, pinned_input_prerequisites2, optimized_python1, fake_docker9, classification22); all original61 named controls are retained. Python2/Bash1 syntax checks and exact driver/validator normalization pass. Synthetic mixed216 counts are fixtures only, not actual runtime evidence. Real Docker/Cargo/database/Rust test executions remain zero.
- Rollback: stop using this candidate and retain all artifacts. Root performs any owned-container recovery using only its exact recorded name and verified current-run label. No destructive Git or unscoped cleanup.
- Stop: absent independent review, changed hashes, unclean source, argv drift, source/receipt mismatch, unexpected roster/count/filter, prerequisites, or unverifiable cleanup. Preserve evidence; do not weaken any guard.

Lenses: Cartesian doubt, Essentialism / YAGNI, Chesterton's Fence, Red Team, Operability / Day-2, Blast-radius / cell-based, Zero-trust / defense-in-depth.

Review identities: candidate author /root/inventory_repair; independent reviewer requested /root/capture_review or /root/fast_gate_review; root writer/runtime /root. Remaining HOLDs: independent frozen candidate review, integrated clean-HEAD runtime and cleanup proof, independent failure-causality review, plus all durable Account/draft/production/payment/legal HOLDs. This packet clears none of them.
