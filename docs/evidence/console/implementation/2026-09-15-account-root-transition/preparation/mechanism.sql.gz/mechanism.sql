\set ON_ERROR_STOP on
-- Disposable PostgreSQL mechanism experiment only; not Console migration proof.
CREATE TABLE roots(id integer PRIMARY KEY, created_at integer NOT NULL);
CREATE TABLE profiles(id integer PRIMARY KEY, created_at integer NOT NULL);
CREATE FUNCTION bridge_root() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO roots(id,created_at) VALUES(NEW.id,NEW.created_at);
  RETURN NEW;
END $$;
CREATE TRIGGER "00_account_legacy_user_root_v1" AFTER INSERT ON profiles
  FOR EACH ROW EXECUTE FUNCTION bridge_root();
ALTER TABLE profiles ENABLE ALWAYS TRIGGER "00_account_legacy_user_root_v1";
ALTER TABLE profiles ADD CONSTRAINT profiles_root FOREIGN KEY(id)
  REFERENCES roots(id) ON DELETE RESTRICT ON UPDATE RESTRICT
  DEFERRABLE INITIALLY DEFERRED;
BEGIN;
INSERT INTO profiles VALUES(1,10);
COMMIT;
BEGIN;
SET CONSTRAINTS ALL IMMEDIATE;
INSERT INTO profiles VALUES(2,20);
COMMIT;
BEGIN;
INSERT INTO profiles VALUES(3,30);
SET CONSTRAINTS ALL IMMEDIATE;
COMMIT;
INSERT INTO profiles VALUES(1,99) ON CONFLICT(id) DO NOTHING;
INSERT INTO roots VALUES(4,40);
DO $$ BEGIN
  BEGIN
    INSERT INTO profiles VALUES(4,99);
    RAISE EXCEPTION 'collision wrongly accepted';
  EXCEPTION WHEN unique_violation THEN NULL;
  END;
  IF (SELECT count(*) FROM profiles)<>3 OR (SELECT count(*) FROM roots)<>4
     OR (SELECT created_at FROM roots WHERE id=1)<>10
     OR (SELECT created_at FROM roots WHERE id=4)<>40 THEN
    RAISE EXCEPTION 'row preservation failed';
  END IF;
END $$;
-- Prove the alphabetical trigger-order control is material in immediate mode.
ALTER TRIGGER "00_account_legacy_user_root_v1" ON profiles RENAME TO "zz_bridge_root";
BEGIN;
SET CONSTRAINTS ALL IMMEDIATE;
DO $$ BEGIN
  BEGIN
    INSERT INTO profiles VALUES(5,50);
    RAISE EXCEPTION 'late trigger unexpectedly passed immediate FK';
  EXCEPTION WHEN foreign_key_violation THEN NULL;
  END;
  IF EXISTS(SELECT 1 FROM profiles WHERE id=5) OR EXISTS(SELECT 1 FROM roots WHERE id=5) THEN
    RAISE EXCEPTION 'immediate refusal failed atomicity';
  END IF;
END $$;
COMMIT;
ALTER TRIGGER "zz_bridge_root" ON profiles RENAME TO "00_account_legacy_user_root_v1";
-- A privileged fault disabling the bridge must still fail FK validation.
ALTER TABLE profiles DISABLE TRIGGER "00_account_legacy_user_root_v1";
DO $$ BEGIN
  BEGIN
    INSERT INTO profiles VALUES(6,60);
    SET CONSTRAINTS ALL IMMEDIATE;
    RAISE EXCEPTION 'missing bridge wrongly accepted';
  EXCEPTION WHEN foreign_key_violation THEN NULL;
  END;
  IF EXISTS(SELECT 1 FROM profiles WHERE id=6) OR EXISTS(SELECT 1 FROM roots WHERE id=6) THEN
    RAISE EXCEPTION 'missing bridge refusal failed atomicity';
  END IF;
END $$;
ALTER TABLE profiles ENABLE ALWAYS TRIGGER "00_account_legacy_user_root_v1";
SELECT json_build_object('server_version',current_setting('server_version'),'profiles',
  (SELECT count(*) FROM profiles),'roots',(SELECT count(*) FROM roots),'deferred_and_immediate_cases_passed',3,
  'noop_preserved',true,'collision_refused',true,'late_trigger_control_refused',true,'missing_bridge_control_refused',true);
