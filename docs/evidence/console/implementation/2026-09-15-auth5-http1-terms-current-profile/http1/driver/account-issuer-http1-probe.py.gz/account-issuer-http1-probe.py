import pathlib,subprocess,uuid
root=pathlib.Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
evidence='/private/tmp/account-issuer-http1-'+uuid.uuid4().hex
print(evidence,flush=True)
raise SystemExit(subprocess.run(['bash','/private/tmp/account-issuer-http1-driver.sh',str(root),head,evidence],cwd=root).returncode)
