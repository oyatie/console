async fn assert_terms_receipt_guard_profile(pool: &PgPool) {
    use sha2::Digest as _;
    // Fixed test expectation, not a digest learned from the target database.
    // Reviewed body: BEGIN; unconditional fixed P0001 refusal; END.
    let expected_body = "BEGIN\n    RAISE EXCEPTION USING MESSAGE='account_terms_receipts.immutable', ERRCODE='P0001';\nEND;";
    let expected_digest = hex::encode(sha2::Sha256::digest(expected_body.as_bytes()));
    let exact: bool = sqlx::query_scalar(
        r#"SELECT
          (SELECT count(*)=1 FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
             WHERE n.nspname='public' AND p.proname='account_terms_receipts_immutable_v1')
          AND EXISTS(SELECT 1 FROM pg_catalog.pg_proc p
            JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
            JOIN pg_catalog.pg_roles r ON r.oid=p.proowner
            JOIN pg_catalog.pg_language l ON l.oid=p.prolang
            WHERE n.nspname='public' AND p.proname='account_terms_receipts_immutable_v1'
              AND r.rolname='console_terms_owner' AND l.lanname='plpgsql'
              AND p.prokind='f' AND NOT p.prosecdef AND NOT p.proisstrict AND NOT p.proretset
              AND NOT p.proleakproof AND p.provolatile='v' AND p.proparallel='u' AND p.prosupport=0
              AND p.pronargs=0 AND p.proargtypes=''::oidvector AND p.proargnames IS NULL
              AND p.proallargtypes IS NULL AND p.proargmodes IS NULL AND p.provariadic=0
              AND p.pronargdefaults=0 AND p.proargdefaults IS NULL
              AND p.prorettype='pg_catalog.trigger'::regtype AND p.probin IS NULL
              AND p.prosqlbody IS NULL AND p.protrftypes IS NULL
              AND encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')=$1
              AND p.proconfig=ARRAY['search_path=pg_catalog, pg_temp']::text[]
              AND p.proacl IS NOT NULL AND cardinality(p.proacl)=0)
          AND (SELECT count(*)=1 FROM pg_catalog.pg_trigger t
            WHERE t.tgrelid='public.account_terms_release_receipts'::regclass AND NOT t.tgisinternal)
          AND EXISTS(SELECT 1 FROM pg_catalog.pg_trigger t
            JOIN pg_catalog.pg_proc p ON p.oid=t.tgfoid
            JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
            WHERE t.tgrelid='public.account_terms_release_receipts'::regclass
              AND t.tgname='account_terms_receipts_immutable_v1'
              AND NOT t.tgisinternal AND t.tgenabled='A' AND t.tgtype=58
              AND t.tgnargs=0 AND octet_length(t.tgargs)=0 AND t.tgattr=''::int2vector
              AND t.tgqual IS NULL AND t.tgconstraint=0
              AND NOT t.tgdeferrable AND NOT t.tginitdeferred
              AND t.tgoldtable IS NULL AND t.tgnewtable IS NULL
              AND n.nspname='public' AND p.proname='account_terms_receipts_immutable_v1')"#,
    )
    .bind(expected_digest)
    .fetch_one(pool)
    .await
    .expect("exact receipt guard metadata readback");
    assert!(
        exact,
        "current finalized profile requires the complete immutable receipt guard"
    );
}
