"""Pure evidence classifier. No subprocesses, database calls or source edits."""
import re

READERS = {
    'account_fence_pending_enrollment_rejects_legacy_sessions',
    'account_fence_active_rejects_legacy_sessions',
    'account_fence_security_suspended_rejects_legacy_sessions',
    'account_fence_recovery_required_rejects_legacy_sessions',
    'account_fence_recovery_to_active_does_not_restore_legacy_sessions',
}
PREFIX = 'account_fence_transport::verifier_only_api_'
MARKERS = {
    PREFIX+'requires_auth_configuration':
        'VERIFIER_AUTH_CONFIG: missing Auth was accepted for public-key-only API',
    PREFIX+'startup_refuses_removed_auth_binding':
        'VERIFIER_AUTH_STARTUP: actual startup accepted a removed required Auth binding',
    PREFIX+'retains_genuine_auth_transport':
        'VERIFIER_AUTH_RETAINED: public-key-only startup must retain a genuinely authenticated Auth backend',
    PREFIX+'readiness_tracks_auth_outage_and_no_jwt_stays_ready':
        'VERIFIER_AUTH_READINESS: public-key-only readiness ignored actual Auth outage',
    'account_fence_projection::account_fence_projection_missing_auth_grantee_refuses_wrong_execute_acl':
        'MISSING_AUTH_GRANTEE: absent required grantee cannot make bool_and(true,NULL) certify wrong EXECUTE ACL',
}

def classify_failed_cases(log, statuses):
    log = re.sub(r'\x1b\[[0-9;]*m', '', log)
    headers = list(re.finditer(r'^---- ([A-Za-z_][A-Za-z0-9_:]*) stdout ----\s*$', log, re.M))
    blocks = {}
    errors = []
    for index, header in enumerate(headers):
        name = header.group(1)
        end = headers[index+1].start() if index+1 < len(headers) else len(log)
        block = log[header.end():end]
        block = re.split(r'^failures:\s*$|^test result:', block, maxsplit=1, flags=re.M)[0]
        if name in blocks:
            errors.append(name+':duplicate_stdout_section')
        blocks[name] = block
    failed = {name for name,status in statuses.items() if status == 'FAILED'}
    if set(blocks) != failed:
        errors.append('stdout_sections_do_not_equal_failed_names')
    accepted = {}
    for name in sorted(failed):
        block = blocks.get(name, '')
        if len(re.findall(r"^thread .* panicked at ", block, re.M)) != 1:
            errors.append(name+':must_have_exactly_one_panic')
            continue
        if re.search(r'PREREQUISITE|CLEANUP|VERIFIER_AUTH_(?:CONFIG|STARTUP)_MESSAGE', block):
            errors.append(name+':prerequisite_cleanup_or_wrong_message')
            continue
        if name in READERS:
            marker = r'^legacy refusal must be401 with v1 error JSON, no credential cookie/token fields or known secret echoes; response [1-4] returned HTTP 200$'
            if len(re.findall(marker, block, re.M)) != 1:
                errors.append(name+':not_observed_legacy_200_instead_of_401')
                continue
            accepted[name] = 'legacy_HTTP200_instead_of_required401'
            continue
        marker = MARKERS.get(name)
        if marker is None or block.count(marker) != 1:
            errors.append(name+':unrecognized_behavioral_marker')
            continue
        if name.endswith('readiness_tracks_auth_outage_and_no_jwt_stays_ready'):
            if not re.search(r'^\s*left: 200\s*$',block,re.M) or not re.search(r'^\s*right: 503\s*$',block,re.M):
                errors.append(name+':not_observed_ready200_instead_of503')
                continue
        if name.endswith('missing_auth_grantee_refuses_wrong_execute_acl'):
            if not re.search(r'^\s*left: "account_custody.finalized"\s*$',block,re.M) or not re.search(r'^\s*right: "account_fence_projection.definition_mismatch"\s*$',block,re.M):
                errors.append(name+':not_observed_NULL_grantee_acceptance')
                continue
        accepted[name] = marker.split(':',1)[0]
    return {'failed_names':sorted(failed),'accepted_behavioral_failures':accepted,
            'errors':errors,'all_failed_cases_are_behavioral':not errors and set(accepted)==failed}
