import hashlib,json,pathlib,subprocess,sys,uuid

DRIVER = pathlib.Path('/private/tmp/account-session-reader10-driver-candidate/grantee1-driver.sh')
DRIVER_SHA256 = '0df7a809da25744be035ed02a5bbd262e8fd864e085b922ec908250a2376e592'
EXPECTED = ['account_fence_projection::account_fence_projection_missing_auth_grantee_refuses_wrong_execute_acl']
POSITIVE_CONTROL = None
EVIDENCE_PREFIX = 'account-grantee1-'

def prerequisite(message):
    print('PROBE_PREREQUISITE: '+message, file=sys.stderr, flush=True)
    raise SystemExit(126)

try:
    if hashlib.sha256(DRIVER.read_bytes()).hexdigest() != DRIVER_SHA256:
        prerequisite('immutable driver hash differs')
    root = pathlib.Path.cwd()
    head = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
    evidence = pathlib.Path('/private/tmp') / (EVIDENCE_PREFIX + uuid.uuid4().hex)
    print(str(evidence), flush=True)
    result = subprocess.run(['bash',str(DRIVER),str(root),head,str(evidence)],cwd=root)
    receipt = json.loads((evidence/'driver-receipt.json').read_text())
    selected = json.loads((evidence/'selected-test-results.json').read_text())
    before = json.loads((evidence/'source-before.json').read_text())
    after = json.loads((evidence/'source-after.json').read_text())
    if receipt['driver_sha256'] != DRIVER_SHA256:
        prerequisite('run driver differs from reviewed driver')
    for name,digest in receipt['artifacts'].items():
        if pathlib.PurePath(name).name != name or hashlib.sha256((evidence/name).read_bytes()).hexdigest() != digest:
            prerequisite('run artifact hash/path mismatch')
    if before != after or before['head'] != head or before['status_porcelain']:
        prerequisite('source HEAD or clean before/after snapshots differ')
    if not before['files'] or receipt['source_pre_post'] != 'exactly equal':
        prerequisite('source snapshot accounting missing')
    if receipt['prebuild_interception_count'] != 1:
        prerequisite('exact seven-argument prebuild was not observed once')
    cleanup = 'confirmed owned container absent via successful bounded docker ps -a'
    if receipt['cleanup'] != cleanup or (evidence/'cleanup.txt').read_text().strip() != cleanup:
        prerequisite('owned container cleanup/readback incomplete')
    if not (evidence/'container-name.txt').read_text().strip():
        prerequisite('no owned container launch recorded')
    if not selected['selection_complete'] or selected['errors'] or selected['expected_names'] != EXPECTED:
        prerequisite('selected execution incomplete or wrong roster')
    observed = selected['observed_results']
    if len(observed) != len(EXPECTED) or len({r['name'] for r in observed}) != len(EXPECTED) or {r['name'] for r in observed} != set(EXPECTED):
        prerequisite('missing, duplicate or unexpected selected result')
    statuses = {r['name']:r['status'] for r in observed}
    if any(status not in ('ok','FAILED') for status in statuses.values()):
        prerequisite('ignored/unrecognized selected result')
    passed = sum(status == 'ok' for status in statuses.values())
    failed = sum(status == 'FAILED' for status in statuses.values())
    if selected['discovery_counts'] != [len(EXPECTED)] or selected['executed'] != len(EXPECTED) or (selected['passed'],selected['failed'],selected['ignored']) != (passed,failed,0):
        prerequisite('discovered/executed counts differ')
    probe_exit = int((evidence/'probe-exit.txt').read_text())
    if selected['probe_exit'] != probe_exit or receipt['probe_exit'] != probe_exit:
        prerequisite('inner exit accounting differs')
    if failed == 0 and result.returncode == 0 and probe_exit == 0:
        print('PROBE_GREEN: all '+str(len(EXPECTED))+' exact cases passed',flush=True)
        raise SystemExit(0)
    if failed and result.returncode == probe_exit and probe_exit > 0:
        if POSITIVE_CONTROL is not None and statuses[POSITIVE_CONTROL] != 'ok':
            prerequisite('required unchanged positive control did not pass')
        print('PROBE_SELECTED_FAILURE: '+str(passed)+' passed, '+str(failed)+' failed; inspect reached oracles before behavioral admission',flush=True)
        raise SystemExit(1)
    prerequisite('driver/selected result exits contradict each other')
except SystemExit:
    raise
except Exception:
    prerequisite('driver execution or evidence parsing did not complete')
