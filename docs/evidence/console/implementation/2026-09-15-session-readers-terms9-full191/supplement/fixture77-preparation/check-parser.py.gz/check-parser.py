import pathlib,json,runpy,tempfile,copy
root=pathlib.Path(__file__).parent;validate=runpy.run_path(str(root/'validate-results.py'))['validate'];roster=json.loads((root/'fixture-roster.json').read_text());expected={e['wrapper']:e for e in roster['selected']};rows=[json.loads(l) for l in (root/'selected.jsonl').read_text().splitlines()]
# Synthetic transport logs only; no Rust, SQLx, Cargo, Docker or DB process.
def log(fail=False):
 out=[];final=[]
 for i,row in enumerate(rows):
  names=expected[row['name']]['expected_cases'];bad=fail and i==0
  out.extend(['cargo-postgres: === '+row['name']+' ===','cargo-postgres: '+' '.join(row['argv']),f'running {len(names)} tests'])
  for j,n in enumerate(names):out.append('test '+n+' ... '+('FAILED' if bad and j==0 else 'ok'))
  p=len(names)-int(bad);f=int(bad)
  out.append(f'test result: {"FAILED" if bad else "ok"}. {p} passed; {f} failed; 0 ignored; 0 measured; 0 filtered out; finished in 1s')
  out.append('cargo-postgres-timing: '+json.dumps({'name':row['name'],'package':row['package'],'seconds':1,'status':'fail' if bad else 'pass'}))
  final.append(('FAIL' if bad else 'PASS',row['name']))
 out.append('cargo-postgres: summary')
 for status,n in final:out.append('  '+status+'  '+n)
 out.append(f'cargo-postgres: {76 if fail else 77} passed, {1 if fail else 0} failed')
 return '\n'.join(out)+'\n'
work=pathlib.Path(tempfile.mkdtemp(prefix='fixture77-parser-',dir='/private/tmp'))
for name in ['fixture-roster.json','selected.jsonl']:(work/name).write_bytes((root/name).read_bytes())
green=log();first_name=expected[rows[0]['name']]['expected_cases'][0];checks=[]
cases=[('complete_all_pass',green,0,True),('complete_real_failure',log(True),1,True),('prebuild_failure','cargo-postgres: building packages...\nerror: compilefailed\n',1,False),('missing_named_case',green.replace('test '+first_name+' ... ok\n','',1),0,False),('duplicate_named_case',green.replace('test '+first_name+' ... ok\n',('test '+first_name+' ... ok\n')*2,1),0,False),('ignored_case',green.replace('test '+first_name+' ... ok','test '+first_name+' ... ignored',1),0,False),('filtered_case',green.replace('0 filtered out','1 filtered out',1),0,False),('changed_command',green.replace('--test-threads=1','--test-threads=2',1),0,False),('unexpected_invocation',green.replace('cargo-postgres: === '+rows[0]['name']+' ===','cargo-postgres: === unexpected-fixture ===',1),0,False),('exit_mismatch',green,1,False)]
for name,text,exitcode,wanted in cases:
 (work/'probe.log').write_text(text);(work/'probe-exit.txt').write_text(str(exitcode)+'\n');r=validate(work);assert r['selection_complete']==wanted,(name,r['errors']);checks.append({'case':name,'expected_complete':wanted,'observed_complete':r['selection_complete']})
(root/'parser-check-receipt.json').write_text(json.dumps({'kind':'synthetic_log_parser_checks_only','checks':checks,'count':len(checks),'root_runtime_tests_executed':0,'cargo_sql_docker_commands':0},indent=2)+'\n');print(json.dumps({'synthetic_checks':len(checks),'all_pass':True}))
