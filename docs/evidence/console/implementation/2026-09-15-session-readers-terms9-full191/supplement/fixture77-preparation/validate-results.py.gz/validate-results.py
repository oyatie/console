#!/usr/bin/env python3
"""Validate complete unfiltered fixture77 execution; never convert missing tests to PASS."""
import collections
import json
import pathlib
import re
import sys


def validate(run):
    roster = json.loads((run / 'fixture-roster.json').read_text())
    selected = [json.loads(line) for line in (run / 'selected.jsonl').read_text().splitlines()]
    expected = {entry['wrapper']: entry for entry in roster['selected']}
    order = [entry['name'] for entry in selected]
    errors = []
    if len(order) != 77 or len(set(order)) != 77 or set(order) != set(expected):
        errors.append('expected invocation roster must contain exactly77 unique fixture targets')
    if len({entry['package'] for entry in selected}) != 18:
        errors.append('expected package roster must contain exactly18 packages')
    if sum(len(entry['expected_cases']) for entry in expected.values()) != 381:
        errors.append('frozen source roster must contain381 case declarations')
    for row in selected:
        entry = expected[row['name']]
        if row['argv'] != entry['argv'] or row['package'] != entry['package']:
            errors.append('frozen map and fixture target argv differ')
        if len(set(entry['expected_cases'])) != len(entry['expected_cases']):
            errors.append('frozen expected case names are not unique within their binary')
    log = re.sub(r'\x1b\[[0-9;]*m', '', (run / 'probe.log').read_text())
    headers = list(re.finditer(r'^cargo-postgres: === ([A-Za-z0-9_-]+) ===$', log, re.M))
    actual_order = [match[1] for match in headers]
    if actual_order != order:
        errors.append('actual invocation names/order differ from exact77 selected map rows')
    invocations = []
    for index, header in enumerate(headers):
        name = header[1]
        text = log[header.end():headers[index + 1].start() if index + 1 < len(headers) else len(log)]
        entry = expected.get(name)
        if entry is None:
            errors.append('unexpected runtime invocation name')
            continue
        local = []
        command_lines = re.findall(r'^cargo-postgres: (cargo test .*)$', text, re.M)
        if command_lines != [' '.join(entry['argv'])]:
            local.append('actual command is missing, duplicated, or differs from original unfiltered argv')
        found = re.findall(r'^test ([A-Za-z_][A-Za-z0-9_:]*) \.\.\. (ok|FAILED|ignored)(?: .*)?$', text, re.M)
        names = [case for case, status in found]
        counts = collections.Counter(status for case, status in found)
        discovery = [int(value) for value in re.findall(r'^running (\d+) tests?$', text, re.M)]
        summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
        if len(names) != len(set(names)) or sorted(names) != entry['expected_cases']:
            local.append('actual fully qualified case names differ from frozen complete source roster')
        if discovery != [len(entry['expected_cases'])]:
            local.append('actual discovery must equal the complete expected binary case count once')
        if counts['ignored']:
            local.append('ignored selected cases are forbidden')
        if len(summaries) != 1:
            local.append('exactly one Rust test result summary is required')
        else:
            outcome, passed, failed, ignored, measured, filtered = summaries[0]
            if (int(passed), int(failed), int(ignored), int(measured), int(filtered)) != (counts['ok'], counts['FAILED'], 0, 0, 0):
                local.append('Rust summary disagrees with actual case statuses or hides measured/filtered cases')
            if outcome != ('FAILED' if counts['FAILED'] else 'ok'):
                local.append('Rust summary outcome disagrees with named results')
        timing_lines = re.findall(r'^cargo-postgres-timing: (.+)$', text, re.M)
        timings = [json.loads(line) for line in timing_lines]
        if len(timings) != 1:
            local.append('exactly one actual timing/exit result is required')
        elif timings[0].get('name') != name or timings[0].get('package') != entry['package'] or timings[0].get('status') != ('fail' if counts['FAILED'] else 'pass'):
            local.append('invocation exit/timing result disagrees with expected target or named case outcomes')
        if local:
            errors.extend(name + ': ' + problem for problem in local)
        invocations.append({
            'name': name, 'package': entry['package'], 'test': entry['test'],
            'discovery_counts': discovery, 'executed': len(found), 'passed': counts['ok'],
            'failed': counts['FAILED'], 'ignored': counts['ignored'],
            'observed_results': [{'name': case, 'status': status} for case, status in found],
            'summary': summaries[0] if len(summaries) == 1 else None,
            'complete': not local, 'errors': local,
        })
    failed_invocations = sum(bool(row['failed']) for row in invocations)
    passed_invocations = len(invocations) - failed_invocations
    rollups = re.findall(r'^cargo-postgres: (\d+) passed, (\d+) failed$', log, re.M)
    if rollups != [(str(passed_invocations), str(failed_invocations))]:
        errors.append('exactly one consistent complete invocation rollup is required')
    final_rows = re.findall(r'^  (PASS|FAIL)  ([A-Za-z0-9_-]+)$', log, re.M)
    wanted_rows = [('FAIL' if row['failed'] else 'PASS', row['name']) for row in invocations]
    if final_rows != wanted_rows:
        errors.append('final invocation summary roster/status differs from actual selected binaries')
    probe_exit = int((run / 'probe-exit.txt').read_text())
    if probe_exit != (1 if failed_invocations else 0):
        errors.append('raw harness exit disagrees with complete selected invocation outcomes')
    if not headers:
        errors.append('no runtime invocation occurred; startup/prebuild failure is not behavioral test evidence')
    return {
        'classification': 'COMPLETE_SELECTED_EXECUTION' if not errors else 'INCOMPLETE_OR_PREREQUISITE_FAILURE',
        'selection_complete': not errors, 'expected_invocations': 77, 'observed_invocations': len(headers),
        'expected_source_cases': 381, 'executed': sum(row['executed'] for row in invocations),
        'passed': sum(row['passed'] for row in invocations), 'failed': sum(row['failed'] for row in invocations),
        'ignored': sum(row['ignored'] for row in invocations), 'probe_exit': probe_exit,
        'passed_invocations': passed_invocations, 'failed_invocations': failed_invocations,
        'invocations': invocations, 'errors': errors,
    }


def main():
    run = pathlib.Path(sys.argv[1])
    try:
        receipt = validate(run)
    except (OSError, ValueError, KeyError, TypeError) as error:
        receipt = {'classification': 'INCOMPLETE_OR_PREREQUISITE_FAILURE', 'selection_complete': False,
                   'errors': ['fixture execution evidence could not be parsed: ' + type(error).__name__]}
    (run / 'selected-test-results.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return 0 if receipt['selection_complete'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
