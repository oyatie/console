#!/usr/bin/env bash
# Evidence-only harness adapter. No product source is modified.
set -euo pipefail
[[ $# == 3 ]] || { echo 'usage: driver ROOT EXPECTED_SHA NEW_EVIDENCE_DIRECTORY' >&2; exit 2; }
export FENCE_ROOT="$(cd "$1" && pwd)"
expected_sha="$2"
evidence_dir="$3"
[[ "${evidence_dir}" == /private/tmp/* ]] || { echo 'evidence directory must be under /private/tmp' >&2; exit 2; }
mkdir "${evidence_dir}"
chmod 700 "${evidence_dir}"
export FENCE_CONTAINER_RECORD="${evidence_dir}/container-name.txt"
export FENCE_IMAGE='postgres:18.6@sha256:4ef4dbc939d61acea57712655ddb4b4ab27419c913f94cca0cd57cb3ea3c2280'
export FENCE_LABEL="account-session-fixture77-$(openssl rand -hex 16)"
export FIXTURE77_CANDIDATE_ROOT="/private/tmp/account-session-fixture77-candidate-f96eddd3"
map_path="${evidence_dir}/postgres-map.json"

snapshot() {
  python3 - "${FENCE_ROOT}" "$1" <<'PY'
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1])
files=['backend/Cargo.toml','backend/Cargo.lock','backend/rust-toolchain.toml',
 'backend/app/Cargo.toml','backend/app/tests/auth_rest.rs',
 'backend/app/tests/auth_rest/account_fence_projection.rs','backend/app/src/lib.rs',
 'backend/app/tests/auth_rest/account_fence_transport.rs',
 'backend/crates/platform/auth-rest/src/lib.rs',
 'backend/crates/platform/auth/src/refresh.rs',
 'backend/app/tests/auth_rest/fixtures/account-custody-dormant-v1-7af6dfd4.sql',
 'backend/app/tests/auth_rest/fixtures/account-custody-projection-v2-69e3ca9c.sql',
 'backend/app/src/account_custody_state.sql','ops/postgres-reconcile-topology.sh',
 'ops/generate-account-custody.py','ops/postgres-finalize-account-custody.sql',
 'ops/postgres-finalize-account-custody.sh','ops/account-custody-migrations.sha384',
 'tools/ci/cargo_needs_postgres.sh','tools/ci/cargo-test-runner.sh',
 'tools/ci/postgres-cargo-map.json','tools/ci/postgres-partition.mjs',
 'backend/crates/platform/test-support/src/lib.rs',
 'backend/crates/platform/test-support/Cargo.toml','backend/crates/platform/test-support/BUCK',
 'backend/crates/platform/auth-rest/Cargo.toml','backend/crates/platform/auth-rest/BUCK',
 'backend/crates/platform/auth-rest/tests/dev_auth_session.rs',
 'backend/crates/identity/adapter-postgres/Cargo.toml','backend/crates/identity/adapter-postgres/BUCK',
 'backend/crates/identity/adapter-postgres/src/lib.rs',
 'backend/crates/identity/adapter-postgres/tests/deactivate_revokes_credentials.rs',
 'backend/crates/platform/auth/Cargo.toml','backend/crates/platform/auth/BUCK',
 'backend/crates/platform/auth/tests/refresh_tokens.rs',
 'backend/ci/gates/writer-ownership/canonical-enforce.sh',
 'backend/ci/gates/writer-ownership/canonical-enforce-in-container.sh',
 'backend/app/BUCK','backend/app/tests/auth_rest/account_storage.rs',
 'backend/app/tests/auth_rest/publication_privileges.rs',
 'backend/app/tests/auth_rest/auth_target_parser.rs',
 'backend/app/tests/auth_rest/account_custody_startup.rs',
 'backend/app/tests/auth_rest/account_custody_lifecycle.rs',
 'backend/app/tests/auth_rest/actor-migration.csv']
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
# Reader integration spans existing states/fixtures and may add one auth source.
# Snapshot the actual tracked Rust/build-definition closure at each run's HEAD;
# never infer a new source file from a hard-coded future implementation name.
tracked=subprocess.check_output(['git','-C',str(root),'ls-files','-z','--','backend']).split(b'\0')
files=sorted(set(files)|{name.decode() for name in tracked if name and
    (name.endswith(b'.rs') or pathlib.PurePosixPath(name.decode()).name in ('Cargo.toml','BUCK'))})
candidate=pathlib.Path('/private/tmp/account-session-fixture77-candidate-f96eddd3')
private_files=['driver.sh','probe.py','validate-results.py','postgres-map.json','fixture-roster.json','only.txt','selected.jsonl']
data={'head':git('rev-parse','HEAD'),'status_porcelain':git('status','--porcelain'),
 'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},
 'private_files':{name:hashlib.sha256((candidate/name).read_bytes()).hexdigest() for name in private_files}}
pathlib.Path(sys.argv[2]).write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
PY
}
snapshot "${evidence_dir}/source-before.json"
python3 - "${evidence_dir}/source-before.json" "${expected_sha}" <<'PY'
import json,sys
s=json.load(open(sys.argv[1]))
assert s['head']==sys.argv[2], 'candidate HEAD differs'
assert not s['status_porcelain'], 'candidate tree is not clean'
PY
python3 - "${FENCE_ROOT}" "${FIXTURE77_CANDIDATE_ROOT}" "${evidence_dir}" <<'PY'
import json,pathlib,sys
root,candidate,out=map(pathlib.Path,sys.argv[1:])
original=json.loads((root/'tools/ci/postgres-cargo-map.json').read_text())
mapping=json.loads((candidate/'postgres-map.json').read_text())
roster=json.loads((candidate/'fixture-roster.json').read_text())
selected={e['wrapper']:e for e in roster['selected']}
assert len(selected)==77 and len({e['package'] for e in selected.values()})==18
assert sum(len(e['expected_cases']) for e in selected.values())==381
assert all(e['test']!='auth_rest' for e in selected.values())
promoted={'auth-rest-dev-auth-group-admin-postgres','company-conformance-postgres'}
assert len(original['entries'])==len(mapping['entries'])
for old,new in zip(original['entries'],mapping['entries']):
    expected=dict(old)
    if old['name'] in promoted:
        assert not old['in_workflow_postgres_job']
        expected['in_workflow_postgres_job']=True
    assert new==expected, 'private map changed an unapproved original entry or argv'
    if new['name'] in selected:
        e=selected[new['name']]
        expected_argv=['cargo','test','--locked','--manifest-path','backend/Cargo.toml','-p',e['package'],'--test',e['test'],'--','--test-threads=1']
        assert e['argv']==new['cargo_argv']==expected_argv
for name in ['schema_version','description','unmapped']:
    assert original.get(name)==mapping.get(name)
workflow=sum(e['in_workflow_postgres_job'] for e in mapping['entries'])
assert mapping['counts']==dict(mapped=len(mapping['entries']),unmapped=len(mapping.get('unmapped',[])),workflow_targets=workflow,workflow_mapped=workflow,workflow_missing=0)
only=(candidate/'only.txt').read_text().strip().split(',')
assert len(only)==77 and set(only)==set(selected)
for name in ['postgres-map.json','fixture-roster.json','only.txt','selected.jsonl']:
    (out/name).write_bytes((candidate/name).read_bytes())
PY
IFS= read -r fixture77_only < "${evidence_dir}/only.txt"

docker() {
  local name='' previous='' argument='' matched_image=0
  if [[ "${1:-}" == run ]]; then
    for argument in "$@"; do
      [[ "${previous}" != --name ]] || name="${argument}"
      [[ "${argument}" != "${FENCE_IMAGE}" ]] || matched_image=1
      previous="${argument}"
    done
  fi
  if [[ "${1:-}" == run && "${name}" == console-cargo-postgres-* && "${matched_image}" == 1 ]]; then
    [[ ! -e "${FENCE_CONTAINER_RECORD}" ]] || { echo 'unexpected second scoped container' >&2; return 2; }
    printf '%s\n' "${name}" > "${FENCE_CONTAINER_RECORD}"
    command docker run --label "console.evidence=${FENCE_LABEL}" "${@:2}"
  elif [[ "${1:-}" == rm && "${2:-}" == -f && "$#" == 3 && -f "${FENCE_CONTAINER_RECORD}" && "$3" == "$(cat "${FENCE_CONTAINER_RECORD}")" ]]; then
    # Only the exact container created above can take anonymous-volume cleanup.
    # --rm already owns its anonymous volumes; -v also covers forced removal.
    local actual_label
    actual_label="$(command docker inspect --format '{{index .Config.Labels "console.evidence"}}' "$3" 2>/dev/null)" || return 1
    [[ "${actual_label}" == "${FENCE_LABEL}" ]] || { echo 'owned container label mismatch; removal refused' >&2; return 2; }
    command docker rm -fv "$3"
  else
    command docker "$@"
  fi
}
export -f docker
export RUSTUP_TOOLCHAIN=1.98.1 RUSTC_WRAPPER= CARGO_INCREMENTAL=1
export CARGO_TARGET_DIR=/private/tmp/console-account30-cargo SQLX_OFFLINE=true
cd "${FENCE_ROOT}"
set +e
bash tools/ci/cargo_needs_postgres.sh --map "${map_path}" --only "${fixture77_only}" --num-threads 1 --keep-going > "${evidence_dir}/probe.log" 2>&1
probe_status=$?
set -e
printf '%s\n' "${probe_status}" > "${evidence_dir}/probe-exit.txt"

# Successful Docker listing plus no exact name is required. A daemon failure
# is not accepted as absence. If harness cleanup failed, remove only this run's
# exact name after independently matching our explicit ownership label.
docker_bounded() {
  python3 - "$@" <<'PYBOUND'
import subprocess,sys
try:
    result=subprocess.run(['docker',*sys.argv[1:]],capture_output=True,timeout=30)
    sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
    raise SystemExit(result.returncode)
except subprocess.TimeoutExpired as error:
    if error.stdout:sys.stdout.buffer.write(error.stdout)
    if error.stderr:sys.stderr.buffer.write(error.stderr)
    print('bounded Docker command timed out',file=sys.stderr)
    raise SystemExit(124)
PYBOUND
}
cleanup_status='no container launch recorded'
cleanup_failed=0
if [[ -f "${FENCE_CONTAINER_RECORD}" ]]; then
  name="$(cat "${FENCE_CONTAINER_RECORD}")"
  if docker_bounded ps -a --format '{{.Names}}' > "${evidence_dir}/containers-before-cleanup.txt" 2> "${evidence_dir}/cleanup-list-error.txt"; then
    if rg -Fxq "${name}" "${evidence_dir}/containers-before-cleanup.txt"; then
      if label="$(docker_bounded inspect --format '{{index .Config.Labels "console.evidence"}}' "${name}" 2> "${evidence_dir}/cleanup-inspect-error.txt")"; then
        printf '%s\n' "${label}" > "${evidence_dir}/cleanup-label.txt"
        if [[ "${label}" == "${FENCE_LABEL}" ]]; then
          # Removal failure/timeout never skips independent absence readback.
          set +e
          docker_bounded rm -fv "${name}" > "${evidence_dir}/fallback-cleanup.txt" 2> "${evidence_dir}/fallback-cleanup-error.txt"
          removal_status=$?
          set -e
          printf '%s\n' "${removal_status}" > "${evidence_dir}/fallback-cleanup-exit.txt"
        else
          cleanup_failed=1
        fi
      else
        cleanup_failed=1
      fi
    fi
  else
    cleanup_failed=1
  fi
  if docker_bounded ps -a --format '{{.Names}}' > "${evidence_dir}/containers-after.txt" 2> "${evidence_dir}/cleanup-final-list-error.txt"; then
    if rg -Fxq "${name}" "${evidence_dir}/containers-after.txt"; then
      cleanup_failed=1
    fi
  else
    cleanup_failed=1
  fi
  if [[ "${cleanup_failed}" == 0 ]]; then
    cleanup_status='confirmed owned container absent via successful bounded docker ps -a'
  else
    cleanup_status='owned container cleanup/identity/absence verification failed; see exact command artifacts'
  fi
fi
printf '%s\n' "${cleanup_status}" > "${evidence_dir}/cleanup.txt"
printf '%s\n' "${FENCE_LABEL}" > "${evidence_dir}/ownership-label.txt"
snapshot "${evidence_dir}/source-after.json"
cmp "${evidence_dir}/source-before.json" "${evidence_dir}/source-after.json"
validation_status=0
python3 "${FIXTURE77_CANDIDATE_ROOT}/validate-results.py" "${evidence_dir}" || validation_status=$?
python3 - "${evidence_dir}" "$0" <<'PY'
import hashlib,json,pathlib,sys
d=pathlib.Path(sys.argv[1]); driver=pathlib.Path(sys.argv[2])
paths=[p for p in d.iterdir() if p.is_file()]
data={'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),
 'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
 'prebuild_policy':'unmodified existing harness no-run18packages; no cargo wrapper/interception installed',
 'storage':'original Docker image/harness storage; no custom capacity cap; exact labeled container removal includes attached anonymous volumes; only container absence is independently read back',
 'source_pre_post':'exactly equal','probe_exit':int((d/'probe-exit.txt').read_text()),
 'cleanup':(d/'cleanup.txt').read_text().strip()}
(d/'driver-receipt.json').write_text(json.dumps(data,indent=2)+'\n')
PY
[[ "${cleanup_failed}" == 0 ]] || exit 2
[[ "${validation_status}" == 0 ]] || exit 2
exit "${probe_status}"
