#!/usr/bin/env python3
"""Draft private fixture candidates from the admitted immutable Git tree."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path('/private/tmp/console-production-tdd-preparation-20260913')
OUT = Path(__file__).resolve().parent
BASE = '4c7f49e8540271b20335afefc205119b8c04a0d9'
RECEIPT = Path('/private/tmp/account-issuer4-red-admission-receipt.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

receipt = json.loads(RECEIPT.read_text())
assert receipt['base_sha'] == BASE
assert receipt['executed'] == 4 and receipt['passed'] == 1 and receipt['failed'] == 3
assert not (OUT / 'manifest.json').exists(), 'retain existing immutable candidates'

paths = [
    'backend/app/tests/auth_rest/account_fence_transport.rs',
    'backend/crates/platform/auth/tests/refresh_tokens.rs',
    'backend/crates/platform/auth-rest/tests/dev_auth_session.rs',
    'backend/crates/identity/adapter-postgres/tests/deactivate_revokes_credentials.rs',
    'backend/crates/platform/provisioning/tests/self_enroll_handoff_as_runtime_role.rs',
    'backend/crates/platform/provisioning/tests/rls_auth_chain_as_runtime_role.rs',
]
files = []
patches = []
original_calls = 0
candidate_calls = 0
new_preparations = 0

for path in paths:
    original_bytes = subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)
    original = original_bytes.decode()
    candidate = original
    transformations = []

    def replace(before, after, count=1):
        global candidate
        assert candidate.count(before) == count, (path, before, candidate.count(before), count)
        candidate = candidate.replace(before, after)
        transformations.append({'before': before, 'after': after, 'count': count})

    def prepare(name, pool='pool', migration='../db/migrations'):
        global new_preparations
        replace(
            f'#[sqlx::test(migrations = "{migration}")]\nasync fn {name}({pool}: PgPool) {{\n',
            f'#[sqlx::test(migrations = false)]\nasync fn {name}({pool}: PgPool) {{\n    prepare_account_test_database(&{pool}).await;\n',
        )
        new_preparations += 1

    def import_preparation():
        replace(
            'use console_platform_test_support::{TestDatabaseLogin, login_test_pool};',
            'use console_platform_test_support::{\n    TestDatabaseLogin, login_test_pool, prepare_account_test_database,\n};',
        )

    if path.endswith('/account_fence_transport.rs'):
        replace(
            '    let business =\n        console_platform_test_support::login_test_pool(pool, TestDatabaseLogin::Business).await;\n    let issued = RefreshTokenStore',
            '    let business =\n        console_platform_test_support::login_test_pool(pool, TestDatabaseLogin::Business).await;\n    let auth = console_platform_test_support::login_test_pool(pool, TestDatabaseLogin::Auth).await;\n    let issued = RefreshTokenStore',
        )
        replace('        .issue_family(\n            &business,\n', '        .issue_family(\n            &business,\n            &auth,\n')
        replace(
            '        .expect("real control-subject token issuance prerequisite");\n    business.close().await;',
            '        .expect("real control-subject token issuance prerequisite");\n    auth.close().await;\n    business.close().await;',
        )
        replace(
            '    // Baseline bridge calls the existing canonical owner without deciding access.\n    // The post-signature variant adds only `auth,` after `business,` below.\n',
            '',
        )
        replace('        let _ = auth;\n', '')
        replace(
            '.issue_family(business, *subject.as_uuid(), OrgId::knl(), now, ttl)',
            '.issue_family(business, auth, *subject.as_uuid(), OrgId::knl(), now, ttl)',
        )
    elif path.endswith('/refresh_tokens.rs'):
        import_preparation()
        for name in [
            'rotate_audit_row_is_visible_to_tenant_scoped_read_as_runtime_role',
            'refresh_token_reuse_revokes_the_whole_family',
            'rotation_past_family_absolute_ttl_revokes_the_family',
        ]:
            prepare(name)
        replace('.issue_family(&auth, user_id, OrgId::knl(), now, ttl)', '.issue_family(&auth, &auth, user_id, OrgId::knl(), now, ttl)', 3)
    elif path.endswith('/dev_auth_session.rs'):
        prepare('mints_a_real_session_and_backs_it_with_a_real_user')
        replace(
            'async fn mints_a_real_session_and_backs_it_with_a_real_user(pool: PgPool) {\n    prepare_account_test_database(&pool).await;\n    let (org_id, branch_id) = seed_org_and_branch(&pool).await;\n    let rt_pool = runtime_role_pool(&pool).await;\n    let app = router(test_state(rt_pool));',
            'async fn mints_a_real_session_and_backs_it_with_a_real_user(pool: PgPool) {\n    prepare_account_test_database(&pool).await;\n    let (org_id, branch_id) = seed_org_and_branch(&pool).await;\n    let rt_pool = runtime_role_pool(&pool).await;\n    let auth_pool = login_test_pool(&pool, TestDatabaseLogin::Auth).await;\n    let app = router(test_state(rt_pool).with_auth_database(auth_pool));',
        )
        replace('        .issue_family(\n            &rt_pool,\n', '        .issue_family(\n            &rt_pool,\n            &auth_pool,\n')
    elif path.endswith('/deactivate_revokes_credentials.rs'):
        import_preparation()
        prepare('deactivate_revokes_passkeys_and_sessions_as_runtime_role', 'owner_pool', '../../platform/db/migrations')
        replace(
            '        .issue_family(&rt_pool, user_id, knl, now, Duration::days(30))',
            '        .issue_family(&rt_pool, &auth_pool, user_id, knl, now, Duration::days(30))',
        )
    elif path.endswith('/self_enroll_handoff_as_runtime_role.rs'):
        replace(
            'use console_platform_provisioning::{BootstrapCredentialStore, ProvisioningError};',
            'use console_platform_provisioning::{BootstrapCredentialStore, ProvisioningError};\nuse console_platform_test_support::{\n    TestDatabaseLogin, login_test_pool, prepare_account_test_database,\n};',
        )
        prepare('handoff_redeems_then_enroll_consumes_it_single_use', 'owner_pool')
        replace(
            'async fn handoff_redeems_then_enroll_consumes_it_single_use(owner_pool: PgPool) {\n    prepare_account_test_database(&owner_pool).await;\n    let rt_pool = runtime_role_pool(&owner_pool).await;',
            'async fn handoff_redeems_then_enroll_consumes_it_single_use(owner_pool: PgPool) {\n    prepare_account_test_database(&owner_pool).await;\n    let rt_pool = runtime_role_pool(&owner_pool).await;\n    let auth_pool = login_test_pool(&owner_pool, TestDatabaseLogin::Auth).await;',
        )
        replace('        .issue_family(\n            &rt_pool,\n', '        .issue_family(\n            &rt_pool,\n            &auth_pool,\n')
    elif path.endswith('/rls_auth_chain_as_runtime_role.rs'):
        import_preparation()
        for name in [
            'knl_auth_chain_works_as_runtime_role',
            'non_knl_admin_otp_and_redeem_work_as_runtime_role',
            'open_signup_creates_member_and_redeems_as_runtime_role',
        ]:
            prepare(name, 'owner_pool')
        replace('        .issue_family(\n            &rt_pool,\n', '        .issue_family(\n            &rt_pool,\n            &rt_pool,\n', 2)
        replace('        .issue_family(\n            &auth_pool,\n', '        .issue_family(\n            &auth_pool,\n            &auth_pool,\n')
    else:
        raise AssertionError(path)

    # Reverse exactly the declared substitutions; no assertions or unrelated source change.
    reconstructed = candidate
    for change in reversed(transformations):
        if change['after']:
            assert reconstructed.count(change['after']) == change['count'], (path, change)
            reconstructed = reconstructed.replace(change['after'], change['before'])
        else:
            # Two intentional bridge-only removals, restored at unique anchors.
            if change['before'] == '        let _ = auth;\n':
                anchor = '    ) -> Result<RefreshTokenIssue, AuthError> {\n'
                assert reconstructed.count(anchor) == 1
                reconstructed = reconstructed.replace(anchor, anchor + change['before'])
            else:
                anchor = '    async fn issue(\n'
                assert reconstructed.count(anchor) == 1
                reconstructed = reconstructed.replace(anchor, change['before'] + anchor)
    assert reconstructed == original, path
    original_names = re.findall(r'(?m)^async fn ([a-zA-Z0-9_]+)\(', original)
    candidate_names = re.findall(r'(?m)^async fn ([a-zA-Z0-9_]+)\(', candidate)
    assert original_names == candidate_names, path
    original_calls += original.count('.issue_family(')
    candidate_calls += candidate.count('.issue_family(')
    data = candidate.encode()
    target = OUT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    patch = ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True), fromfile=f'a/{path}', tofile=f'b/{path}'))
    patches.append(patch)
    files.append({
        'path': path,
        'candidate_path': str(target),
        'base_blob_oid': subprocess.check_output(['git', 'rev-parse', f'{BASE}:{path}'], cwd=ROOT, text=True).strip(),
        'base_sha256': sha(original_bytes),
        'candidate_sha256': sha(data),
        'base_bytes': len(original_bytes),
        'candidate_bytes': len(data),
        'direct_call_count': candidate.count('.issue_family('),
        'reversal_exact': True,
        'transformations': transformations,
    })

assert original_calls == candidate_calls == 11
assert new_preparations == 9
patch_path = OUT / 'fixtures.patch'
patch_bytes = ''.join(patches).encode()
patch_path.write_bytes(patch_bytes)
manifest = {
    'kind': 'private_admitted_issuer_fixture_candidates',
    'author': '/root/fast_gate_review',
    'integration_writer_and_runtime_executor': '/root',
    'base_sha': BASE,
    'admission_receipt': str(RECEIPT),
    'admission_receipt_sha256': sha(RECEIPT.read_bytes()),
    'mechanical_guide': '/private/tmp/account-issue-family-prewrite-design-guide.json',
    'mechanical_guide_sha256': sha(Path('/private/tmp/account-issue-family-prewrite-design-guide.json').read_bytes()),
    'immutable_target': 'six existing issuer test files; ten existing direct calls and one bridge used by three additive tests',
    'lenses': ['Red Team', 'Operability / Day-2', 'Blast-radius / cell-based', 'Zero-trust / defense-in-depth', 'Essentialism / YAGNI'],
    'patch': str(patch_path),
    'patch_sha256': sha(patch_bytes),
    'file_count': len(files),
    'existing_direct_calls_adapted': 10,
    'shared_bridge_calls_adapted': 1,
    'newly_prepared_tests': new_preparations,
    'files': files,
    'preservation': [
        'All changes reverse exactly to each immutable base blob.',
        'All original writer expressions and assertions remain intact.',
        'Only the nine affected automatic-migration tests become migrations=false and prepare real Account state first.',
        'Actual Auth projection identities use existing login_test_pool helper; SET ROLE writer pools are preserved as writer fixtures only.',
        'Original control_refresh_token closes both new Auth and existing Business pools.',
        'New issuer bridge forwards auth with no unused let binding or stale baseline comments.',
        'No changes to migrations, grants, dependencies, lockfiles, production sources, generated files, or authority records.',
    ],
    'pre_mortem': 'Missing projection setup masks issuer behavior; swapping Auth writers would conceal existing credential privilege failures.',
    'blast_radius': 'Private candidates only; six test files are the proposed integration surface.',
    'detection': 'Root reviews exact transformations and candidates, then runs admitted issuer4 and relevant compilation/fixture checks.',
    'rollback': 'Discard private candidates before integration; root retains immutable base for isolated source reversion.',
    'stop_conditions': ['Source hash mismatch', 'Assertions or writer changes required', 'Grant widening', 'Setup or compile error presented as behavioral proof'],
    'review_identities': ['Author /root/fast_gate_review; independent integration review pending root assignment'],
    'remaining_holds': ['Runtime and compilation proof by root', 'Existing Auth credential-DML failures', 'Account activation/drain', 'Bearer reader migration', 'Production/HA/legal claims'],
    'execution': {'repository_writes': 0, 'git_mutations': 0, 'cargo_commands': 0, 'postgresql_commands': 0, 'docker_commands': 0, 'tests_executed': 0},
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest': str(OUT / 'manifest.json'), 'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()), 'patch_sha256': sha(patch_bytes), 'files': len(files), 'calls': candidate_calls, 'newly_prepared': new_preparations}, indent=2))
