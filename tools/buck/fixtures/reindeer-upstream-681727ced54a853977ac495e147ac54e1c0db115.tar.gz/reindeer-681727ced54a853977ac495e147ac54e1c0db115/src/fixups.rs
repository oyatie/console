/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

//! Per-package configuration information

use std::collections::BTreeMap;
use std::collections::BTreeSet;
use std::collections::HashMap;
use std::collections::btree_map;
use std::fmt;
use std::path::Path;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::MutexGuard;
use std::sync::PoisonError;
use std::sync::atomic::Ordering;

use anyhow::bail;
use foldhash::HashSet;

use crate::Paths;
use crate::buck::Alias;
use crate::buck::BuckPath;
use crate::buck::BuildscriptGenrule;
use crate::buck::BuildscriptGenruleManifestDir;
use crate::buck::Common;
use crate::buck::CxxLibrary;
use crate::buck::Filegroup;
use crate::buck::FilegroupSources;
use crate::buck::Name;
use crate::buck::PackageVersion;
use crate::buck::PlatformBuildscriptGenrule;
use crate::buck::PrebuiltCxxLibrary;
use crate::buck::Rule;
use crate::buck::RuleRef;
use crate::buck::RustBinary;
use crate::buck::Sources;
use crate::buck::StringOrPath;
use crate::buck::SubtargetOrPath;
use crate::buck::Visibility;
use crate::buckify::evaluate_for_platforms;
use crate::buckify::short_name_for_git_repo;
use crate::buckify::split_srcs;
use crate::buckify::vendor_crate_visibility;
use crate::cargo::Manifest;
use crate::cargo::ManifestTarget;
use crate::cargo::NodeDepKind;
use crate::cargo::Source;
use crate::cargo::TargetKind;
use crate::collection::Select;
use crate::collection::SetOrMap;
use crate::config::Config;
use crate::config::VendorConfig;
use crate::fixups::buildscript::CxxLibraryFixup;
use crate::fixups::buildscript::ExportedHeaders;
use crate::fixups::buildscript::PrebuiltCxxLibraryFixup;
use crate::fixups::config::CargoEnv;
use crate::fixups::config::CargoEnvPurpose;
pub use crate::fixups::config::CargoEnvs;
pub use crate::fixups::config::ExportSources;
use crate::fixups::config::FixupConfig;
use crate::fixups::config::FixupConfigFile;
use crate::glob::GlobSetKind;
use crate::glob::Globs;
use crate::glob::NO_EXCLUDE;
use crate::glob::TrackedGlobSet;
use crate::index::Index;
use crate::index::ResolvedDep;
use crate::path::normalize_path;
use crate::path::normalized_extend_path;
use crate::path::relative_path;
use crate::platform::PlatformName;
use crate::subtarget::Subtarget;
use crate::version_naming::CollisionInfo;

mod buildscript;
mod config;

/// Fixups for a specific package & target
pub struct Fixups<'meta> {
    config: &'meta Config,
    paths: &'meta Paths,
    third_party_dir: &'meta Path,
    package: &'meta Manifest,
    fixup_config: Arc<FixupConfigFile>,
    manifest_dir: &'meta Path,
}

impl<'meta> fmt::Debug for Fixups<'meta> {
    fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
        fmt.debug_struct("Fixups")
            .field("package", &self.package.to_string())
            .field("third_party_dir", &self.third_party_dir)
            .field("manifest_dir", &self.manifest_dir)
            .field("fixup_config", &self.fixup_config)
            .finish()
    }
}

#[derive(Debug)]
pub struct FixupsCache<'meta> {
    config: &'meta Config,
    paths: &'meta Paths,
    fixups: Mutex<BTreeMap<&'meta str, Arc<FixupConfigFile>>>,
}

impl<'meta> FixupsCache<'meta> {
    pub fn new(config: &'meta Config, paths: &'meta Paths) -> Self {
        FixupsCache {
            config,
            paths,
            fixups: Mutex::new(BTreeMap::new()),
        }
    }

    /// Get fixups.toml for a specific package.
    pub fn get(&self, package: &'meta Manifest) -> anyhow::Result<Fixups<'meta>> {
        let mut fixups_map = self.fixups.lock().unwrap_or_else(PoisonError::into_inner);
        let fixup_config = if let Some(arc) = fixups_map.get(package.name.as_str()) {
            Arc::clone(arc)
        } else {
            let fixup_dir = self
                .paths
                .third_party_dir
                .join("fixups")
                .join(&package.name);
            let fixup_config = FixupConfigFile::load(fixup_dir)?;
            let arc = Arc::new(fixup_config);
            fixups_map.insert(&package.name, Arc::clone(&arc));
            arc
        };

        Ok(Fixups {
            third_party_dir: &self.paths.third_party_dir,
            manifest_dir: package.manifest_dir(),
            package,
            fixup_config,
            config: self.config,
            paths: self.paths,
        })
    }

    pub fn lock(&self) -> MutexGuard<'_, BTreeMap<&'meta str, Arc<FixupConfigFile>>> {
        self.fixups.lock().unwrap_or_else(PoisonError::into_inner)
    }
}

impl<'meta> Fixups<'meta> {
    fn configs(&self, platform_name: &PlatformName) -> Vec<&FixupConfig> {
        let mut configs = Vec::with_capacity(1 + self.fixup_config.platform_fixup.len());

        self.fixup_config.base.used.store(true, Ordering::Relaxed);
        configs.push(&self.fixup_config.base);

        for fixup in &self.fixup_config.platform_fixup {
            if fixup.platform.eval(
                &self.config.platform[platform_name],
                Some(&self.package.version),
                &HashMap::default(),
            ) {
                fixup.used.store(true, Ordering::Relaxed);
                configs.push(fixup);
            }
        }

        configs
    }

    fn platform_independent_configs(&self) -> Vec<&FixupConfig> {
        let mut configs = Vec::with_capacity(1 + self.fixup_config.platform_fixup.len());

        self.fixup_config.base.used.store(true, Ordering::Relaxed);
        configs.push(&self.fixup_config.base);

        for fixup in &self.fixup_config.platform_fixup {
            if let Some(true) = fixup.platform.eval_only_version(&self.package.version) {
                fixup.used.store(true, Ordering::Relaxed);
                configs.push(fixup);
            }
        }

        configs
    }

    // Return true if the script applies to this target.
    // There's a few cases:
    // - if the script doesn't specify a target, then it applies to the main "lib" target of the package
    // - otherwise it applies to the matching kind and (optionally) name (all names if not specified)
    fn target_match(
        &self,
        target: &ManifestTarget,
        applies_to_targets: &[(TargetKind, Option<String>)],
    ) -> bool {
        if applies_to_targets.is_empty() {
            // Applies to default target (the main "lib" target)
            let default_target = self.package.dependency_target();
            return Some(target) == default_target;
        }

        // Applies to the targets specified by the fixup
        applies_to_targets.iter().any(|(kind, name)| {
            target.kind.contains(kind) && name.as_ref().is_none_or(|name| &target.name == name)
        })
    }

    fn subtarget_or_path(
        &self,
        relative_to_manifest_dir: &Path,
    ) -> anyhow::Result<SubtargetOrPath> {
        if matches!(self.config.vendor, VendorConfig::Source(_))
            || matches!(self.package.source, Source::Local)
        {
            // Path to vendored file looks like "vendor/foo-1.0.0/src/lib.rs"
            let manifest_dir = relative_path(self.third_party_dir, self.manifest_dir);
            let path = manifest_dir.join(relative_to_manifest_dir);
            Ok(SubtargetOrPath::Path(BuckPath(path)))
        } else if let Source::Git { repo, .. } = &self.package.source {
            // Subtarget inside a git_fetch: ":serde-643d78919f35d883.git[src/lib.rs]"
            let short_name = short_name_for_git_repo(repo)?;
            Ok(SubtargetOrPath::Subtarget(Subtarget {
                target: Name(format!("{short_name}.git")),
                relative: BuckPath(relative_to_manifest_dir.to_owned()),
            }))
        } else {
            // Subtarget inside an http_archive: ":foo-1.0.0.crate[src/lib.rs]"
            Ok(SubtargetOrPath::Subtarget(Subtarget {
                target: Name(format!(
                    "{}-{}.crate",
                    self.package.name, self.package.version
                )),
                relative: BuckPath(relative_to_manifest_dir.to_owned()),
            }))
        }
    }

    pub fn visibility(&self, index: &Index) -> Visibility {
        let mut visibility = &Visibility::Public;

        for config in self.platform_independent_configs() {
            if let Some(custom_visibility) = &config.visibility {
                visibility = custom_visibility.get_ref();
            }
        }

        let mut visibility = visibility.clone();
        if self.config.buck.split
            && index.is_public_package(self.package)
            && !index.is_root_package(self.package)
            && let Visibility::Custom(visibility) = &mut visibility
            && let Some(root_pkg) = index.root_pkg
        {
            visibility.push(format!(
                "//{}{}{}:{}",
                self.paths.buck_package,
                if self.paths.buck_package.is_empty() {
                    ""
                } else {
                    "/"
                },
                relative_path(
                    self.third_party_dir,
                    root_pkg.targets[0].src_path.parent().unwrap()
                )
                .to_str()
                .unwrap(),
                root_pkg.name,
            ));
        }
        visibility
    }

    pub fn python_ext(&self) -> Option<&str> {
        let mut python_ext = None;

        for config in self.platform_independent_configs() {
            if config.python_ext.is_some() {
                python_ext = config.python_ext.as_deref();
            }
        }

        python_ext
    }

    pub fn omit_target(&self, target: &ManifestTarget) -> bool {
        for config in self.platform_independent_configs() {
            if let Some(omit_targets) = &config.omit_targets {
                if omit_targets.contains(&target.name) {
                    return true;
                }
            }
        }
        false
    }

    pub fn export_sources(&self) -> Vec<&ExportSources> {
        let mut export_sources = Vec::new();

        for config in self.platform_independent_configs() {
            export_sources.extend(&config.export_sources);
        }

        export_sources
    }

    pub fn compatible_with(&self) -> &Vec<RuleRef> {
        let mut compatible_with = None;

        for config in self.platform_independent_configs() {
            if config.compatible_with.is_some() {
                compatible_with = config.compatible_with.as_ref();
            }
        }

        compatible_with.unwrap_or(const { &Vec::new() })
    }

    pub fn target_compatible_with(&self) -> &Vec<RuleRef> {
        let mut target_compatible_with = None;

        for config in self.platform_independent_configs() {
            if config.target_compatible_with.is_some() {
                target_compatible_with = config.target_compatible_with.as_ref();
            }
        }

        target_compatible_with.unwrap_or(const { &Vec::new() })
    }

    pub fn compute_target_compatible_with_select(&self) -> Vec<BTreeMap<String, Vec<RuleRef>>> {
        let mut target_compatible_with_select = Vec::new();

        for config in self.platform_independent_configs() {
            if let Some(select) = &config.target_compatible_with_select {
                target_compatible_with_select.extend_from_slice(select);
            }
        }

        target_compatible_with_select
    }

    pub fn precise_srcs(&self) -> bool {
        let mut precise_srcs = None;

        for config in self.platform_independent_configs() {
            if config.precise_srcs.is_some() {
                precise_srcs = config.precise_srcs;
            }
        }

        precise_srcs.unwrap_or(self.config.precise_srcs)
    }

    fn buildscript_target(&self) -> Option<&ManifestTarget> {
        self.package
            .targets
            .iter()
            .find(|tgt| tgt.kind_custom_build())
    }

    pub fn buildscript_genrule_name(&self, collision_info: &CollisionInfo) -> Name {
        let mut name = self
            .buildscript_rule_name(collision_info)
            .expect("no buildscript");
        // Cargo names the build script target after the filename of the build
        // script's crate root. In the overwhelmingly common case of a build
        // script located in build.rs, this is build-script-build, and we name
        // the genrule build-script-run. Some crates such as typenum have a
        // build/main.rs such that the build script target ends up being named
        // build-script-main, and in this case we use build-script-main-run for
        // the genrule.
        if name.0.ends_with("-build-script-build") {
            name.0.truncate(name.0.len() - 6);
        }
        name.0.push_str("-run");
        name
    }

    fn buildscript_rule_name(&self, collision_info: &CollisionInfo) -> Option<Name> {
        let buildscript_target = self.buildscript_target()?;
        Some(Name(if self.config.buck.split {
            format!(
                "{}-{}",
                collision_info.target_version(self.package),
                buildscript_target.name,
            )
        } else {
            format!(
                "{}-{}",
                collision_info.target_display(self.package),
                buildscript_target.name,
            )
        }))
    }

    /// Return buildscript-related rules
    /// The rules may be platform specific, but they're emitted unconditionally. (The
    /// dependencies referencing them are conditional).
    pub fn emit_buildscript_rules(
        &self,
        mut buildscript_build: RustBinary,
        config: &'meta Config,
        manifest_dir: Option<SubtargetOrPath>,
        index: &Index,
        target: &ManifestTarget,
        compatible_platforms: &BTreeSet<&PlatformName>,
        collision_info: &CollisionInfo,
    ) -> anyhow::Result<Vec<Rule>> {
        let mut res = Vec::new();

        let rel_fixup = relative_path(self.third_party_dir, &self.fixup_config.fixup_dir);

        let buildscript_rule_name = match self.buildscript_rule_name(collision_info) {
            None => {
                log::warn!(
                    "Package {} doesn't have a build script to fix up",
                    self.package
                );
                return Ok(res);
            }
            Some(name) => name,
        };

        for platform_name in compatible_platforms {
            let mut has_explicit_buildscript_fixup = false;
            for fixup in self.configs(platform_name) {
                if fixup.buildscript.span.is_some() {
                    has_explicit_buildscript_fixup = true;
                    fixup.buildscript.used.store(true, Ordering::Relaxed);
                }
            }
            if !has_explicit_buildscript_fixup {
                let unresolved_package_msg = format!(
                    "{} v{} has a build script, but {} does not say what to do with it. Add `buildscript.run = false` or `buildscript.run = true`",
                    self.package.name,
                    self.package.version,
                    Path::new("fixups")
                        .join(&self.package.name)
                        .join("fixups.toml")
                        .display(),
                );
                if config.unresolved_fixup_error {
                    log::error!("{}", unresolved_package_msg);
                    bail!("Unresolved fixup errors, fix them and rerun buckify.");
                } else {
                    log::warn!("{}", unresolved_package_msg);
                    break;
                }
            }
        }

        let mut cxx_library = Vec::new();
        let mut prebuilt_cxx_library = Vec::new();
        let mut library_fixups = BTreeSet::new();
        let mut buildscript_platforms = BTreeSet::new();
        for &platform_name in compatible_platforms {
            for fixup in self.configs(platform_name) {
                if library_fixups.insert(&raw const *fixup) {
                    cxx_library.extend(&fixup.cxx_library);
                    prebuilt_cxx_library.extend(&fixup.prebuilt_cxx_library);
                }
            }

            if self.has_buildscript_for_platform(platform_name) {
                buildscript_platforms.insert(platform_name);
            }
        }

        // Emit a C++ library build rule (elsewhere - add a dependency to it)
        for CxxLibraryFixup {
            name,
            srcs,
            headers,
            exported_headers,
            public,
            include_paths,
            fixup_include_paths,
            exclude,
            compiler_flags,
            preprocessor_flags,
            header_namespace,
            deps,
            compatible_with,
            target_compatible_with,
            preferred_linkage,
            undefined_symbols,
            ..
        } in cxx_library
        {
            let cxx_library_target = if self.config.buck.split {
                res.push(Rule::CxxLibrary(CxxLibrary {
                    owner: PackageVersion {
                        name: self.package.name.clone(),
                        version: self.package.version.clone(),
                    },
                    common: Common {
                        name: Name(name.clone()),
                        visibility: Visibility::Custom(vec![
                            format!("//{}:", self.paths.buck_package),
                            format!(
                                "//{}{}vendor/...",
                                self.paths.buck_package,
                                if self.paths.buck_package.is_empty() {
                                    ""
                                } else {
                                    "/"
                                },
                            ),
                        ]),
                        licenses: Default::default(),
                        metadata: buildscript_build.common.common.metadata.clone(),
                        compatible_with: compatible_with.clone(),
                        target_compatible_with: Select {
                            common: target_compatible_with.clone(),
                            selects: vec![],
                        },
                    },
                    srcs: Globs::new(srcs, exclude)
                        .walk(self.manifest_dir)?
                        .into_iter()
                        .map(|path| SubtargetOrPath::Path(BuckPath(path)))
                        .collect(),
                    headers: Globs::new(headers, exclude)
                        .walk(self.manifest_dir)?
                        .into_iter()
                        .map(|path| SubtargetOrPath::Path(BuckPath(path)))
                        .collect(),
                    exported_headers: match exported_headers {
                        ExportedHeaders::Set(exported_headers) => {
                            let exported_header_globs = Globs::new(exported_headers, exclude);
                            let exported_headers = exported_header_globs
                                .walk(self.manifest_dir)?
                                .into_iter()
                                .map(|path| SubtargetOrPath::Path(BuckPath(path)))
                                .collect();
                            SetOrMap::Set(exported_headers)
                        }
                        ExportedHeaders::Map(exported_headers) => SetOrMap::Map(
                            exported_headers
                                .iter()
                                .map(|(name, path)| {
                                    (
                                        name.clone(),
                                        SubtargetOrPath::Path(BuckPath(PathBuf::from(
                                            path.clone(),
                                        ))),
                                    )
                                })
                                .collect(),
                        ),
                    },
                    include_directories: fixup_include_paths
                        .iter()
                        .map(|path| {
                            SubtargetOrPath::Path(BuckPath(PathBuf::from(format!(
                                "//{}{}fixups/{}/{}:include",
                                self.paths.buck_package,
                                if self.paths.buck_package.is_empty() {
                                    ""
                                } else {
                                    "/"
                                },
                                self.package.name,
                                path.to_str().unwrap(),
                            ))))
                        })
                        .chain(
                            include_paths
                                .iter()
                                .map(|path| SubtargetOrPath::Path(BuckPath(path.clone()))),
                        )
                        .collect(),
                    compiler_flags: compiler_flags.clone(),
                    preprocessor_flags: preprocessor_flags.clone(),
                    header_namespace: header_namespace.clone(),
                    deps: deps.iter().cloned().map(RuleRef::new).collect(),
                    preferred_linkage: preferred_linkage.clone(),
                    undefined_symbols: *undefined_symbols,
                }));
                RuleRef::new(format!(
                    "//{}{}vendor/{}:{}",
                    self.paths.buck_package,
                    if self.paths.buck_package.is_empty() {
                        ""
                    } else {
                        "/"
                    },
                    self.package,
                    name,
                ))
            } else {
                let disp = collision_info.target_display(self.package);
                let target_name = Name(format!("{}-{}", disp, name));
                res.push(Rule::CxxLibrary(CxxLibrary {
                    owner: PackageVersion {
                        name: self.package.name.clone(),
                        version: self.package.version.clone(),
                    },
                    common: Common {
                        name: target_name.clone(),
                        visibility: Visibility::Private,
                        licenses: Default::default(),
                        metadata: buildscript_build.common.common.metadata.clone(),
                        compatible_with: compatible_with.clone(),
                        target_compatible_with: Select {
                            common: target_compatible_with.clone(),
                            selects: vec![],
                        },
                    },
                    // Just collect the sources, excluding things in the exclude list
                    srcs: Globs::new(srcs, exclude)
                        .walk(self.manifest_dir)?
                        .into_iter()
                        .map(|path| self.subtarget_or_path(&path))
                        .collect::<anyhow::Result<_>>()?,
                    // Collect the nominated headers, plus everything in the fixup include
                    // path(s).
                    headers: {
                        let globs = Globs::new(headers, exclude);
                        let mut headers = BTreeSet::new();
                        for path in globs.walk(self.manifest_dir)? {
                            headers.insert(self.subtarget_or_path(&path)?);
                        }

                        let globs = Globs::new(
                            GlobSetKind::from_iter(["**/*.asm", "**/*.h"]).unwrap(),
                            NO_EXCLUDE,
                        );
                        for fixup_include_path in fixup_include_paths {
                            for path in
                                globs.walk(self.fixup_config.fixup_dir.join(fixup_include_path))?
                            {
                                headers.insert(SubtargetOrPath::Path(BuckPath(
                                    rel_fixup.join(fixup_include_path).join(path),
                                )));
                            }
                        }

                        headers
                    },
                    exported_headers: match exported_headers {
                        ExportedHeaders::Set(exported_headers) => {
                            let exported_header_globs = Globs::new(exported_headers, exclude);
                            let exported_headers = exported_header_globs
                                .walk(self.manifest_dir)?
                                .into_iter()
                                .map(|path| self.subtarget_or_path(&path))
                                .collect::<anyhow::Result<_>>()?;
                            SetOrMap::Set(exported_headers)
                        }
                        ExportedHeaders::Map(exported_headers) => SetOrMap::Map(
                            exported_headers
                                .iter()
                                .map(|(name, path)| {
                                    Ok((name.clone(), self.subtarget_or_path(Path::new(path))?))
                                })
                                .collect::<anyhow::Result<_>>()?,
                        ),
                    },
                    include_directories: fixup_include_paths
                        .iter()
                        .map(|path| Ok(SubtargetOrPath::Path(BuckPath(rel_fixup.join(path)))))
                        .chain(
                            include_paths
                                .iter()
                                .map(|path| self.subtarget_or_path(path)),
                        )
                        .collect::<anyhow::Result<_>>()?,
                    compiler_flags: compiler_flags.clone(),
                    preprocessor_flags: preprocessor_flags.clone(),
                    header_namespace: header_namespace.clone(),
                    deps: deps.iter().cloned().map(RuleRef::new).collect(),
                    preferred_linkage: preferred_linkage.clone(),
                    undefined_symbols: *undefined_symbols,
                }));
                RuleRef::from(target_name)
            };

            if *public {
                res.push(Rule::Alias(Alias {
                    owner: PackageVersion {
                        name: self.package.name.clone(),
                        version: self.package.version.clone(),
                    },
                    name: Name(format!("{}-{}", index.public_rule_name(self.package), name)),
                    actual: cxx_library_target,
                    platforms: None,
                    visibility: self.visibility(index),
                    sort_key: Name(format!("{}-{}", self.package, name)),
                }));
            }
        }

        // Emit a prebuilt C++ library rule for each static library (elsewhere - add dependencies to them)
        for PrebuiltCxxLibraryFixup {
            name,
            static_libs,
            public,
            compatible_with,
            target_compatible_with,
            preferred_linkage,
            ..
        } in prebuilt_cxx_library
        {
            let static_lib_globs = Globs::new(static_libs, NO_EXCLUDE);
            for static_lib in static_lib_globs.walk(self.manifest_dir)? {
                let static_lib_file_name = static_lib.file_name().unwrap().to_string_lossy();
                let prebuilt_cxx_library_target = if self.config.buck.split {
                    let target_name = Name(format!("{}-{}", name, static_lib_file_name));
                    res.push(Rule::PrebuiltCxxLibrary(PrebuiltCxxLibrary {
                        owner: PackageVersion {
                            name: self.package.name.clone(),
                            version: self.package.version.clone(),
                        },
                        common: Common {
                            name: target_name.clone(),
                            visibility: Visibility::Custom(vec![
                                format!("//{}:", self.paths.buck_package),
                                format!(
                                    "//{}{}vendor/...",
                                    self.paths.buck_package,
                                    if self.paths.buck_package.is_empty() {
                                        ""
                                    } else {
                                        "/"
                                    },
                                ),
                            ]),
                            licenses: Default::default(),
                            metadata: buildscript_build.common.common.metadata.clone(),
                            compatible_with: compatible_with.clone(),
                            target_compatible_with: Select {
                                common: target_compatible_with.clone(),
                                selects: vec![],
                            },
                        },
                        static_lib: SubtargetOrPath::Path(BuckPath(static_lib.to_owned())),
                        preferred_linkage: preferred_linkage.clone(),
                    }));
                    RuleRef::new(format!(
                        "//{}{}vendor/{}:{}",
                        self.paths.buck_package,
                        if self.paths.buck_package.is_empty() {
                            ""
                        } else {
                            "/"
                        },
                        self.package,
                        target_name,
                    ))
                } else {
                    let disp = collision_info.target_display(self.package);
                    let target_name = Name(format!(
                        "{}-{}-{}",
                        disp,
                        name,
                        static_lib.file_name().unwrap().to_string_lossy(),
                    ));
                    res.push(Rule::PrebuiltCxxLibrary(PrebuiltCxxLibrary {
                        owner: PackageVersion {
                            name: self.package.name.clone(),
                            version: self.package.version.clone(),
                        },
                        common: Common {
                            name: target_name.clone(),
                            visibility: Visibility::Private,
                            licenses: Default::default(),
                            metadata: buildscript_build.common.common.metadata.clone(),
                            compatible_with: compatible_with.clone(),
                            target_compatible_with: Select {
                                common: target_compatible_with.clone(),
                                selects: vec![],
                            },
                        },
                        static_lib: self.subtarget_or_path(&static_lib)?,
                        preferred_linkage: preferred_linkage.clone(),
                    }));
                    RuleRef::from(target_name)
                };

                if *public {
                    res.push(Rule::Alias(Alias {
                        owner: PackageVersion {
                            name: self.package.name.clone(),
                            version: self.package.version.clone(),
                        },
                        name: Name(format!(
                            "{}-{}-{}",
                            index.public_rule_name(self.package),
                            name,
                            static_lib_file_name,
                        )),
                        actual: prebuilt_cxx_library_target,
                        platforms: None,
                        visibility: self.visibility(index),
                        sort_key: Name(format!(
                            "{}-{}-{}",
                            self.package, name, static_lib_file_name,
                        )),
                    }));
                }
            }
        }

        if !buildscript_platforms.is_empty() {
            buildscript_build.common.base.env.extend(
                self.fixup_config
                    .base
                    .buildscript
                    .build
                    .env
                    .iter()
                    .map(|(k, v)| (k.clone(), StringOrPath::String(v.clone()))),
            );
            buildscript_build.common.base.link_style =
                self.fixup_config.base.buildscript.build.link_style.clone();

            let manifest_dir = match manifest_dir {
                None => {
                    if config.buck.split {
                        let manifest_dir_name = Name(format!(
                            "{}-{}.crate",
                            self.package.name, self.package.version,
                        ));
                        res.push(Rule::Filegroup(Filegroup {
                            owner: PackageVersion {
                                name: self.package.name.clone(),
                                version: self.package.version.clone(),
                            },
                            name: manifest_dir_name.clone(),
                            srcs: FilegroupSources::Glob {
                                include: vec!["**".to_owned()],
                                exclude: vec![config.buck.file_name.to_string()],
                            },
                            visibility: vendor_crate_visibility(self.paths, &self.package.name),
                        }));
                        BuildscriptGenruleManifestDir::Target(RuleRef::new(format!(
                            "//{}{}vendor/{}-{}:{}",
                            self.paths.buck_package,
                            if self.paths.buck_package.is_empty() {
                                ""
                            } else {
                                "/"
                            },
                            self.package.name,
                            self.package.version,
                            manifest_dir_name,
                        )))
                    } else {
                        BuildscriptGenruleManifestDir::None
                    }
                }
                Some(SubtargetOrPath::Path(path)) => BuildscriptGenruleManifestDir::Path(path),
                Some(SubtargetOrPath::Subtarget(subtarget)) => {
                    BuildscriptGenruleManifestDir::Subtarget(subtarget)
                }
            };

            let mut buildscript_run = BuildscriptGenrule {
                owner: PackageVersion {
                    name: self.package.name.clone(),
                    version: self.package.version.clone(),
                },
                name: self.buildscript_genrule_name(collision_info),
                buildscript_rule: buildscript_rule_name.clone(),
                manifest_dir,
                base: PlatformBuildscriptGenrule {
                    features: buildscript_build.common.base.features.clone(),
                    env: BTreeMap::new(),
                    rustc_link_lib: false,
                    rustc_link_search: false,
                },
                platform: BTreeMap::new(),
            };

            for &platform_name in &buildscript_platforms {
                if let Some(buildscript_build_common) =
                    buildscript_build.common.platform.get(platform_name)
                {
                    buildscript_run.platform.insert(
                        platform_name.clone(),
                        PlatformBuildscriptGenrule {
                            features: buildscript_build_common.features.clone(),
                            env: BTreeMap::new(),
                            rustc_link_lib: false,
                            rustc_link_search: false,
                        },
                    );
                }
            }

            evaluate_for_platforms(
                &mut buildscript_build.common.base,
                &mut buildscript_build.common.platform,
                &buildscript_platforms,
                |platform_name| {
                    let mut build_cargo_env = BTreeMap::new();
                    for (cargo_env, required) in self.cargo_env(platform_name) {
                        match cargo_env.purpose() {
                            CargoEnvPurpose::BuildOnly | CargoEnvPurpose::BuildAndRun => {}
                            CargoEnvPurpose::RunOnly => continue,
                        }
                        let value = if cargo_env == CargoEnv::CARGO_CRATE_NAME {
                            Some(StringOrPath::String("build_script_build".to_owned()))
                        } else {
                            self.cargo_env_value(cargo_env, required, target)?
                        };
                        if let Some(value) = value {
                            build_cargo_env.insert(cargo_env, value);
                        }
                    }
                    Ok(build_cargo_env)
                },
                |rule, (cargo_env, value)| rule.env.insert(cargo_env.to_string(), value),
            )?;

            evaluate_for_platforms(
                &mut buildscript_run.base,
                &mut buildscript_run.platform,
                &buildscript_platforms,
                |platform_name| {
                    let mut run_cargo_env = BTreeMap::new();
                    for (cargo_env, required) in self.cargo_env(platform_name) {
                        match cargo_env.purpose() {
                            CargoEnvPurpose::RunOnly | CargoEnvPurpose::BuildAndRun => {}
                            CargoEnvPurpose::BuildOnly => continue,
                        }
                        let value = self.cargo_env_value(cargo_env, required, target)?;
                        if let Some(value) = value {
                            run_cargo_env.insert(cargo_env, value);
                        }
                    }
                    Ok(run_cargo_env)
                },
                |rule, (cargo_env, value)| rule.env.insert(cargo_env.to_string(), value),
            )?;

            evaluate_for_platforms(
                &mut buildscript_run.base,
                &mut buildscript_run.platform,
                &buildscript_platforms,
                |platform_name| {
                    let mut buildscript_run_env = BTreeMap::new();
                    for fixup in self.configs(platform_name) {
                        if let Some(fixup_buildscript_run) = &fixup.buildscript.run {
                            buildscript_run_env.extend(&fixup_buildscript_run.env);
                        }
                    }
                    Ok(buildscript_run_env)
                },
                |rule, (key, value)| {
                    rule.env
                        .insert(key.clone(), StringOrPath::String(value.clone()));
                },
            )?;

            evaluate_for_platforms(
                &mut buildscript_run.base,
                &mut buildscript_run.platform,
                &buildscript_platforms,
                |platform_name| {
                    let mut rustc_link_lib = false;
                    for fixup in self.configs(platform_name) {
                        if let Some(fixup_buildscript_run) = &fixup.buildscript.run {
                            if let Some(fixup_rustc_link_lib) = fixup_buildscript_run.rustc_link_lib
                            {
                                rustc_link_lib = fixup_rustc_link_lib;
                            }
                        }
                    }
                    Ok([rustc_link_lib])
                },
                |rule, rustc_link_lib| rule.rustc_link_lib = rustc_link_lib,
            )?;

            evaluate_for_platforms(
                &mut buildscript_run.base,
                &mut buildscript_run.platform,
                &buildscript_platforms,
                |platform_name| {
                    let mut rustc_link_search = false;
                    for fixup in self.configs(platform_name) {
                        if let Some(fixup_buildscript_run) = &fixup.buildscript.run {
                            if let Some(fixup_rustc_link_search) =
                                fixup_buildscript_run.rustc_link_search
                            {
                                rustc_link_search = fixup_rustc_link_search;
                            }
                        }
                    }
                    Ok([rustc_link_search])
                },
                |rule, rustc_link_search| rule.rustc_link_search = rustc_link_search,
            )?;

            if config.buck.split {
                let srcs_name = Name("build-script".to_owned());
                let (base, platform) = split_srcs(
                    self.paths,
                    &mut buildscript_build.common,
                    &buildscript_build.owner,
                    &srcs_name,
                );
                res.push(Rule::Sources(Sources {
                    owner: buildscript_build.owner.clone(),
                    name: srcs_name,
                    base,
                    platform,
                    visibility: vendor_crate_visibility(self.paths, &buildscript_build.owner.name),
                }));
            }

            // Emit the build script itself
            res.push(Rule::BuildscriptBinary(buildscript_build));

            // Emit rule to get its stdout and filter it into args
            res.push(Rule::BuildscriptGenrule(buildscript_run));
        }

        Ok(res)
    }

    /// Return the set of features to enable, which is the union of the cargo-resolved ones
    /// and additional ones defined in the fixup.
    pub fn compute_features(
        &self,
        platform_name: &PlatformName,
        index: &'meta Index<'meta>,
    ) -> BTreeSet<&str> {
        // Get features according to Cargo.
        let mut features = index.resolved_features(self.package, platform_name);

        // Apply extra feature fixups.
        for fixup in self.configs(platform_name) {
            for feature in &fixup.features {
                features.insert(feature);
            }
        }

        features
    }

    pub fn omit_feature(&self, platform_name: &PlatformName, feature: &str) -> bool {
        for fixup in self.configs(platform_name) {
            if fixup.omit_features.contains(feature) {
                return true;
            }
        }

        false
    }

    pub fn compute_rustc_cfg(&self, platform_name: &PlatformName) -> BTreeSet<String> {
        let mut cfgs = BTreeSet::new();

        for config in self.configs(platform_name) {
            for cfg in &config.cfgs {
                cfgs.insert(cfg.clone());
            }
        }

        cfgs
    }

    pub fn compute_rustc_flags(&self, platform_name: &PlatformName) -> Vec<String> {
        let mut rustc_flags = Vec::new();

        for config in self.configs(platform_name) {
            rustc_flags.extend_from_slice(&config.rustc_flags);
        }

        rustc_flags
    }

    pub fn compute_rustc_flags_select(
        &self,
        platform_name: &PlatformName,
    ) -> Vec<BTreeMap<String, Vec<String>>> {
        let mut rustc_flags_select = Vec::new();

        for config in self.configs(platform_name) {
            rustc_flags_select.extend_from_slice(&config.rustc_flags_select);
        }

        rustc_flags_select
    }

    /// Generate the set of deps for the target. This could just return the unmodified
    /// depenedencies, or it could add/remove them. This returns the Buck rule reference
    /// and the corresponding package if there is one (so the caller can limit its enumeration
    /// to only targets which were actually used).
    pub fn compute_deps(
        &self,
        platform_name: &PlatformName,
        index: &'meta Index<'meta>,
        target: &'meta ManifestTarget,
        collision_info: &CollisionInfo,
    ) -> anyhow::Result<
        HashMap<(RuleRef, Option<&'meta str>, &'meta NodeDepKind), Option<&'meta Manifest>>,
    > {
        let mut ret = HashMap::new();

        // Get dependencies according to Cargo.
        let deps = index.resolved_deps_for_target(self.package, target, platform_name);

        // Collect fixups.
        let mut omit_deps = HashSet::default();
        for fixup in self.configs(platform_name) {
            let fixup_omit_deps;
            let fixup_extra_deps;
            if target.crate_bin() && target.kind_custom_build() {
                fixup_omit_deps = &fixup.buildscript.build.omit_deps;
                fixup_extra_deps = &fixup.buildscript.build.extra_deps;
            } else {
                fixup_omit_deps = &fixup.omit_deps;
                fixup_extra_deps = &fixup.extra_deps;
            }

            omit_deps.extend(fixup_omit_deps.iter().map(String::as_str));

            for dep in fixup_extra_deps {
                ret.insert(
                    (RuleRef::new(dep.to_string()), None, &NodeDepKind::ORDINARY),
                    None,
                );
            }

            for CxxLibraryFixup {
                name,
                targets,
                add_dep,
                ..
            } in &fixup.cxx_library
            {
                if !add_dep || !self.target_match(target, targets) {
                    continue;
                }
                ret.insert(
                    (
                        RuleRef::new(if self.config.buck.split {
                            format!(
                                "//{}{}vendor/{}:{}",
                                self.paths.buck_package,
                                if self.paths.buck_package.is_empty() {
                                    ""
                                } else {
                                    "/"
                                },
                                self.package,
                                name,
                            )
                        } else {
                            let disp = collision_info.target_display(self.package);
                            format!(":{}-{}", disp, name)
                        }),
                        None,
                        &NodeDepKind::ORDINARY,
                    ),
                    None,
                );
            }

            for PrebuiltCxxLibraryFixup {
                name,
                targets,
                add_dep,
                static_libs,
                ..
            } in &fixup.prebuilt_cxx_library
            {
                if !add_dep || !self.target_match(target, targets) {
                    continue;
                }
                let static_lib_globs = Globs::new(static_libs, NO_EXCLUDE);
                for static_lib in static_lib_globs.walk(self.manifest_dir)? {
                    ret.insert(
                        (
                            RuleRef::new(if self.config.buck.split {
                                format!(
                                    "//{}{}vendor/{}:{}-{}",
                                    self.paths.buck_package,
                                    if self.paths.buck_package.is_empty() {
                                        ""
                                    } else {
                                        "/"
                                    },
                                    self.package,
                                    name,
                                    static_lib.file_name().unwrap().to_string_lossy(),
                                )
                            } else {
                                let disp = collision_info.target_display(self.package);
                                format!(
                                    ":{}-{}-{}",
                                    disp,
                                    name,
                                    static_lib.file_name().unwrap().to_string_lossy(),
                                )
                            }),
                            None,
                            &NodeDepKind::ORDINARY,
                        ),
                        None,
                    );
                }
            }
        }

        for ResolvedDep {
            package,
            rename,
            dep_kind,
        } in deps
        {
            log::debug!(
                "Resolved deps for {}/{} ({:?}) - {} as {} ({:?})",
                self.package,
                target.name,
                target.kind(),
                package,
                rename,
                target.kind()
            );

            ret.insert(
                (
                    RuleRef::new(if self.config.buck.split {
                        if index.is_root_package(self.package) {
                            format!(
                                "//{}:{}",
                                self.paths.buck_package,
                                index.public_rule_name(package),
                            )
                        } else {
                            format!(
                                "//{}{}vendor/{}:{}",
                                self.paths.buck_package,
                                if self.paths.buck_package.is_empty() {
                                    ""
                                } else {
                                    "/"
                                },
                                package.name,
                                collision_info.target_version(package),
                            )
                        }
                    } else {
                        format!(":{}", collision_info.target_display(package),)
                    }),
                    // Only use the rename if it isn't the same as the target anyway.
                    match package.dependency_target() {
                        Some(tgt) if tgt.name.replace('-', "_") == rename => None,
                        Some(_) | None => Some(rename),
                    },
                    dep_kind,
                ),
                Some(package),
            );
        }

        Ok(ret)
    }

    pub fn omit_dep(&self, platform_name: &PlatformName, dep: &str) -> bool {
        for fixup in self.configs(platform_name) {
            if fixup.omit_deps.contains(dep) {
                return true;
            }
        }

        false
    }

    /// Additional environment
    pub fn compute_env(
        &self,
        target: &ManifestTarget,
        platform_name: &PlatformName,
    ) -> anyhow::Result<BTreeMap<String, StringOrPath>> {
        let mut ret = BTreeMap::new();

        for config in self.configs(platform_name) {
            ret.extend(
                config
                    .env
                    .iter()
                    .map(|(k, v)| (k.clone(), StringOrPath::String(v.clone()))),
            );
        }

        for (cargo_env, required) in self.cargo_env(platform_name) {
            match cargo_env {
                // Not set for builds, only build script execution
                CargoEnv::CARGO_MANIFEST_LINKS => continue,
                CargoEnv::CARGO_BIN_NAME
                | CargoEnv::CARGO_CRATE_NAME
                | CargoEnv::CARGO_MANIFEST_DIR
                | CargoEnv::CARGO_PKG_AUTHORS
                | CargoEnv::CARGO_PKG_DESCRIPTION
                | CargoEnv::CARGO_PKG_HOMEPAGE
                | CargoEnv::CARGO_PKG_NAME
                | CargoEnv::CARGO_PKG_README
                | CargoEnv::CARGO_PKG_REPOSITORY
                | CargoEnv::CARGO_PKG_RUST_VERSION
                | CargoEnv::CARGO_PKG_VERSION
                | CargoEnv::CARGO_PKG_VERSION_MAJOR
                | CargoEnv::CARGO_PKG_VERSION_MINOR
                | CargoEnv::CARGO_PKG_VERSION_PATCH
                | CargoEnv::CARGO_PKG_VERSION_PRE => {}
            }
            if let btree_map::Entry::Vacant(entry) = ret.entry(cargo_env.to_string()) {
                if let Some(value) = self.cargo_env_value(cargo_env, required, target)? {
                    entry.insert(value);
                }
            }
        }

        Ok(ret)
    }

    fn cargo_env(&self, platform_name: &PlatformName) -> BTreeMap<CargoEnv, bool> {
        let mut cargo_env_required = None;

        for config in self.configs(platform_name) {
            if let Some(fixup_cargo_env) = &config.cargo_env {
                let required = !matches!(fixup_cargo_env, CargoEnvs::All);
                let cargo_env_required = cargo_env_required.get_or_insert_with(BTreeMap::new);
                for cargo_env in fixup_cargo_env.iter() {
                    *cargo_env_required.entry(cargo_env).or_insert(false) |= required;
                }
            }
        }

        let apply_default_cargo_env = cargo_env_required.is_none();
        let mut cargo_env_required = cargo_env_required.unwrap_or_else(BTreeMap::new);
        if apply_default_cargo_env {
            for cargo_env in self.config.cargo_env.iter() {
                cargo_env_required.entry(cargo_env).or_insert(false);
            }
        }

        cargo_env_required
    }

    fn cargo_env_value(
        &self,
        cargo_env: CargoEnv,
        required: bool,
        target: &ManifestTarget,
    ) -> anyhow::Result<Option<StringOrPath>> {
        let value = match cargo_env {
            CargoEnv::CARGO_BIN_NAME => StringOrPath::String(target.name.clone()),
            CargoEnv::CARGO_CRATE_NAME => StringOrPath::String(target.name.replace('-', "_")),
            CargoEnv::CARGO_MANIFEST_DIR => {
                if matches!(self.config.vendor, VendorConfig::Source(_))
                    || matches!(self.package.source, Source::Local)
                {
                    if self.config.buck.split {
                        StringOrPath::String(".".to_owned())
                    } else {
                        StringOrPath::Path(BuckPath(relative_path(
                            self.third_party_dir,
                            self.manifest_dir,
                        )))
                    }
                } else if let VendorConfig::LocalRegistry = self.config.vendor {
                    StringOrPath::String(format!(
                        "{}-{}.crate",
                        self.package.name, self.package.version,
                    ))
                } else if let Source::Git { repo, .. } = &self.package.source {
                    let short_name = short_name_for_git_repo(repo)?;
                    StringOrPath::String(short_name.to_owned())
                } else {
                    StringOrPath::String(format!(
                        "{}-{}.crate",
                        self.package.name, self.package.version,
                    ))
                }
            }
            CargoEnv::CARGO_MANIFEST_LINKS => {
                if let Some(links) = &self.package.links {
                    StringOrPath::String(links.clone())
                } else if required {
                    bail!(
                        "cannot use CARGO_MANIFEST_LINKS in `cargo_env` if there is no `links` in the crate's manifest",
                    );
                } else {
                    // When using `cargo_env = true`, we just omit CARGO_MANIFEST_LINKS
                    // on a crate that has no `links`.
                    return Ok(None);
                }
            }
            CargoEnv::CARGO_PKG_AUTHORS => StringOrPath::String(self.package.authors.join(":")),
            CargoEnv::CARGO_PKG_DESCRIPTION => {
                // Cargo provides "" if there is no `description` in Cargo.toml
                StringOrPath::String(self.package.description.clone().unwrap_or_default())
            }
            CargoEnv::CARGO_PKG_HOMEPAGE => {
                // Cargo provides "" if there is no `homepage` in Cargo.toml
                StringOrPath::String(self.package.homepage.clone().unwrap_or_default())
            }
            CargoEnv::CARGO_PKG_README => StringOrPath::String(resolve_readme(
                self.package.readme.as_deref(),
                self.manifest_dir,
            )),
            CargoEnv::CARGO_PKG_REPOSITORY => {
                // Cargo provides "" if there is no `repository` in Cargo.toml
                StringOrPath::String(self.package.repository.clone().unwrap_or_default())
            }
            CargoEnv::CARGO_PKG_RUST_VERSION => {
                // Cargo provides "" if there is no `rust_version` in Cargo.toml
                StringOrPath::String(self.package.rust_version.clone().unwrap_or_default())
            }
            CargoEnv::CARGO_PKG_VERSION => StringOrPath::String(self.package.version.to_string()),
            CargoEnv::CARGO_PKG_VERSION_MAJOR => {
                StringOrPath::String(self.package.version.major.to_string())
            }
            CargoEnv::CARGO_PKG_VERSION_MINOR => {
                StringOrPath::String(self.package.version.minor.to_string())
            }
            CargoEnv::CARGO_PKG_VERSION_PATCH => {
                StringOrPath::String(self.package.version.patch.to_string())
            }
            CargoEnv::CARGO_PKG_VERSION_PRE => {
                StringOrPath::String(self.package.version.pre.to_string())
            }
            CargoEnv::CARGO_PKG_NAME => StringOrPath::String(self.package.name.clone()),
        };
        Ok(Some(value))
    }

    /// Given a glob for the srcs, walk the filesystem to get the full set.
    /// `srcs` is the normal source glob rooted at the package's manifest dir.
    pub fn compute_srcs(
        &self,
        target: &ManifestTarget,
        platform_name: &PlatformName,
        naive_srcs: &[PathBuf],
    ) -> anyhow::Result<BTreeSet<PathBuf>> {
        // This function is only used in vendoring mode, so it's guaranteed that
        // manifest_dir is a subdirectory of third_party_dir.
        assert!(
            matches!(self.config.vendor, VendorConfig::Source(_))
                || matches!(self.package.source, Source::Local)
        );
        let manifest_rel = relative_path(self.third_party_dir, self.manifest_dir);

        let mut ret = BTreeSet::new();
        for path in naive_srcs {
            let mut src = manifest_rel.clone();
            normalized_extend_path(&mut src, path);
            ret.insert(src);
        }

        let buildscript = target.crate_bin() && target.kind_custom_build();

        for fixup in self.configs(platform_name) {
            let extra_srcs = if buildscript {
                &fixup.buildscript.build.extra_srcs
            } else {
                &fixup.extra_srcs
            };
            ret.extend(self.compute_extra_srcs(extra_srcs)?);
        }

        for fixup in self.configs(platform_name) {
            let mapped_files =
                fixup.overlay_and_mapped_files(&self.fixup_config.fixup_dir, &self.config.buck);
            ret.retain(|path| {
                let path_in_crate = relative_path(&manifest_rel, path);
                !mapped_files.contains(&path_in_crate) && !fixup.omit_srcs.is_match(&path_in_crate)
            });
        }

        log::debug!(
            "pkg {}, naive_srcs {:?}, manifest_rel {} => {:#?}",
            self.package,
            naive_srcs,
            manifest_rel.display(),
            ret
        );

        Ok(ret)
    }

    fn compute_extra_srcs(&self, globs: &TrackedGlobSet) -> anyhow::Result<HashSet<PathBuf>> {
        let mut extra_srcs = HashSet::default();

        for glob in globs {
            // The extra_srcs are allowed to be located outside this crate's
            // manifest dir, i.e. starting with "../". For example libstd refers
            // to files from portable-simd and stdarch, which are located in
            // sibling directories. Thus doing a WalkDir over manifest_dir is
            // not sufficient; here we pick the right directory to walk for this
            // glob.
            let mut dir_containing_extra_srcs = self.manifest_dir.to_owned();
            let mut rest_of_glob = glob.components();
            while let Some(component) = rest_of_glob.as_path().components().next() {
                if component.as_os_str().to_string_lossy().contains('*') {
                    // Ready to do globby stuff.
                    break;
                } else {
                    rest_of_glob.next().unwrap();
                    dir_containing_extra_srcs.push(component);
                }
            }

            let mut insert = |absolute_path: &Path| {
                let tp_rel_path = relative_path(self.third_party_dir, absolute_path);
                extra_srcs.insert(normalize_path(&tp_rel_path));
                glob.mark_used();
            };

            let rest_of_glob = rest_of_glob.as_path();
            if rest_of_glob.as_os_str().is_empty() {
                // None of the components contained glob so this extra_src
                // refers to a specific file.
                if dir_containing_extra_srcs.is_file() {
                    insert(&dir_containing_extra_srcs);
                }
            } else {
                let globs = Globs::new(GlobSetKind::from_iter([rest_of_glob])?, NO_EXCLUDE);
                for path in globs.walk(&dir_containing_extra_srcs)? {
                    insert(&dir_containing_extra_srcs.join(path));
                }
            }
        }

        Ok(extra_srcs)
    }

    pub fn validate_srcs_fixups(
        &self,
        target: &ManifestTarget,
        platform_name: &PlatformName,
    ) -> anyhow::Result<()> {
        let buildscript = target.crate_bin() && target.kind_custom_build();

        for fixup in self.configs(platform_name) {
            let extra_srcs = if buildscript {
                &fixup.buildscript.build.extra_srcs
            } else {
                &fixup.extra_srcs
            };
            Globs::new(extra_srcs, NO_EXCLUDE).walk(self.manifest_dir)?;
            Globs::new(&fixup.omit_srcs, NO_EXCLUDE).walk(self.manifest_dir)?;
        }
        Ok(())
    }

    pub fn compute_mapped_srcs(
        &self,
        mapped_manifest_dir: &Path,
        target: &ManifestTarget,
        platform_name: &PlatformName,
    ) -> anyhow::Result<BTreeMap<SubtargetOrPath, BuckPath>> {
        let mut ret = BTreeMap::new();

        let buildscript = target.crate_bin() && target.kind_custom_build();

        for config in self.configs(platform_name) {
            let extra_mapped_srcs = if buildscript {
                &config.buildscript.build.extra_mapped_srcs
            } else {
                &config.extra_mapped_srcs
            };

            for (k, v) in extra_mapped_srcs {
                ret.insert(
                    // If the mapped source is target-like, take it as-is since
                    // we have nothing to resolve or find.
                    if k.starts_with(':') || k.contains("//") {
                        SubtargetOrPath::Path(BuckPath(PathBuf::from(k)))
                    } else {
                        self.subtarget_or_path(Path::new(k))?
                    },
                    BuckPath(mapped_manifest_dir.join(v)),
                );
            }

            if let Some(overlay) = &config.overlay {
                let overlay_dir = self.fixup_config.fixup_dir.join(overlay);
                let relative_overlay_dir = relative_path(self.third_party_dir, &overlay_dir);
                let overlay_files =
                    config.overlay_files(&self.fixup_config.fixup_dir, &self.config.buck);

                log::debug!(
                    "pkg {} target {} overlay_dir {} overlay_files {:?}",
                    self.package,
                    target.name,
                    overlay_dir.display(),
                    overlay_files
                );

                for file in overlay_files {
                    ret.insert(
                        SubtargetOrPath::Path(BuckPath(relative_overlay_dir.join(&file))),
                        BuckPath(mapped_manifest_dir.join(&file)),
                    );
                }
            }
        }

        Ok(ret)
    }

    pub fn has_buildscript_for_platform(&self, platform_name: &PlatformName) -> bool {
        if self.buildscript_target().is_some() {
            for config in self.configs(platform_name) {
                if config.buildscript.run.is_some() {
                    return true;
                }
            }
        }
        false
    }

    /// Compute link_style (how dependencies should be linked)
    pub fn compute_link_style(&self, platform_name: &PlatformName) -> Option<String> {
        let mut link_style = None;

        for config in self.configs(platform_name) {
            if config.link_style.is_some() {
                link_style = config.link_style.as_ref();
            }
        }

        link_style.cloned()
    }

    /// Compute preferred_linkage (how dependents should link you)
    pub fn compute_preferred_linkage(&self, platform_name: &PlatformName) -> Option<String> {
        let mut preferred_linkage = None;

        for config in self.configs(platform_name) {
            if config.preferred_linkage.is_some() {
                preferred_linkage = config.preferred_linkage.as_ref();
            }
        }

        preferred_linkage.cloned()
    }

    /// Compute linker_flags (extra flags for the linker)
    pub fn compute_linker_flags(&self, platform_name: &PlatformName) -> Vec<String> {
        let mut linker_flags = Vec::new();

        for config in self.configs(platform_name) {
            linker_flags.extend_from_slice(&config.linker_flags);
        }

        linker_flags
    }
}

/// Resolve the CARGO_PKG_README value for a crate.
///
/// When `readme` is provided (from cargo metadata), absolute paths are made
/// relative to `manifest_dir`. When absent, auto-infer `README.md` if it
/// exists in the crate root, matching Cargo's default behavior.
fn resolve_readme(readme: Option<&str>, manifest_dir: &Path) -> String {
    match readme {
        Some(readme_path) => {
            // cargo metadata may provide an absolute path; make it
            // relative to the crate root to match Cargo's behavior.
            let p = Path::new(readme_path);
            p.strip_prefix(manifest_dir)
                .map(|r| r.to_string_lossy().into_owned())
                .unwrap_or_else(|_| readme_path.to_owned())
        }
        None => {
            // Auto-infer README.md if present in the crate root.
            if manifest_dir.join("README.md").exists() {
                "README.md".to_owned()
            } else {
                String::new()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use std::fs;

    use super::resolve_readme;

    #[test]
    fn readme_absolute_path_made_relative() {
        let dir = tempfile::tempdir().unwrap();
        let abs = dir.path().join("README.md");
        let result = resolve_readme(Some(&abs.to_string_lossy()), dir.path());
        assert_eq!(result, "README.md");
    }

    #[test]
    fn readme_relative_path_kept() {
        let dir = tempfile::tempdir().unwrap();
        let result = resolve_readme(Some("docs/README.md"), dir.path());
        assert_eq!(result, "docs/README.md");
    }

    #[test]
    fn readme_none_auto_infers_when_present() {
        let dir = tempfile::tempdir().unwrap();
        fs::write(dir.path().join("README.md"), "# hello").unwrap();
        let result = resolve_readme(None, dir.path());
        assert_eq!(result, "README.md");
    }

    #[test]
    fn readme_none_returns_empty_when_absent() {
        let dir = tempfile::tempdir().unwrap();
        let result = resolve_readme(None, dir.path());
        assert_eq!(result, "");
    }
}
